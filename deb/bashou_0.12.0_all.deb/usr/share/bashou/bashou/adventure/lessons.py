"""Lessons: the Sage Owl teaches a tool on the road, before any fight or chest asks for it."""

# Each page: (text, example). A lesson counts as "met" for the tool (see fight.learned).
LESSONS = [
    {"id": "files_editing", "tool": "mv", "topics": ("bash", "linux"), "title": "Files and editing", "pages": [
        ("mkdir creates a folder, and takes several names at once. A folder is just a place for files: "
         "ls shows what's inside, ls -R shows the folders inside folders too.", "mkdir photos docs"),
        ("mv moves files: the last name is where they go. Give it a folder and the files keep their names; "
         "give it a new name and the file is renamed. cp does the same but keeps the original.",
         "mv beach.jpg cat.jpg photos/"),
        ("To change what's inside a text file, open it in an editor. nano shows its keys at the bottom: "
         "Ctrl+O saves, Ctrl+X quits. In vi, press i to type, Esc to stop, then :wq to save and quit.",
         "nano recipe.txt"),
        ("For one word to replace, sed can do it without opening the file: s/old/new/ replaces, -i writes "
         "the change into the file itself (on a Mac: sed -i '').", "sed -i 's/suger/sugar/' recipe.txt"),
    ]},
    {"id": "help_wildcards", "tool": "*", "topics": ("bash", "linux"), "title": "Help and wildcards", "pages": [
        ("Every tool explains itself: --help lists its options, one per line, short form (-f), long form "
         "(--ignore-case) and what it does. Too long? Add | less, and q quits.", "sort --help | less"),
        ("A * in a name stands for any characters. Bash turns the pattern into the list of matching names "
         "before the command even starts, so the command just sees the names.", "ls *.jpg"),
        ("rm has no undo, no recycle bin. So first look at what a pattern catches with ls, and only then "
         "remove: the same pattern gives the same list.", "ls report-2025-*.csv"),
        ("A pattern matches the whole name, from the first letter: report-* doesn't catch old-report-1.csv. "
         "? stands for exactly one character, [12] for one of the characters inside.", "rm report-2025-*.csv"),
    ]},
    {"id": "failing_well", "tool": "||", "topics": ("script",), "title": "Scripts that fail well", "pages": [
        ("A script runs alone, later. When a command fails, nothing stops it: the next lines work on a broken "
         "state. So a script checks the steps that matter, in the code.", "cp -- \"$1\" backup/ || die \"cannot copy $1\""),
        ("die writes the error on stderr and stops with status 1, so whoever ran the script knows. The template "
         "of every script fight has it.", "die() { printf '%s: %s\\n' \"${0##*/}\" \"$*\" >&2; exit 1; }"),
        ("set -e stops at a failed command, but not inside if, while, && or ||, and ((n++)) with n at 0 counts "
         "as a failure. A net with holes: check what matters yourself.", "count=$((count + 1))"),
        ("A temp file gets a private random name from mktemp, and a trap removes it however the script ends, "
         "an error half way included.", "tmp=$(mktemp) || exit 1; trap 'rm -f -- \"$tmp\"' EXIT"),
    ]},
    {"id": "names_that_bite", "tool": "printf", "topics": ("script",), "title": "Names that bite", "pages": [
        ("At the prompt you see the names you work on. A script meets any name: with spaces, with a line break "
         "inside, starting with a dash. Let the shell hand them over: a pattern, never ls.", "for f in ./*.txt; do"),
        ("A name like -rf looks like options to a command. -- ends the options: whatever comes after is a name.",
         "mv -- \"$f\" trash/"),
        ("A pattern that matches nothing stays the pattern, and the loop turns once on it. nullglob turns it "
         "into an empty list; then check it isn't empty, or cat ./*.txt reads the keyboard.", "shopt -s nullglob"),
        ("echo takes data like -n for its option. printf prints any value exactly: the format first, the "
         "values after.", "printf '%s\\n' \"$name\""),
    ]},
    {"id": "streams_scripts", "tool": "2>", "topics": ("bash", "linux"), "title": "Streams and scripts", "pages": [
        ("A program has two outputs. stdout (number 1) gets the normal results, stderr (number 2) the error "
         "messages. Both show on the screen, so they look the same until you split them.", "ls notes.txt nowhere"),
        ("> sends stdout into a file, 2> sends stderr. So you can keep the errors and let the rest scroll by, "
         "or the opposite. /dev/null is a bin that swallows whatever you send it.",
         "./check.sh 2> errors.txt"),
        ("Bash cuts every line at its spaces before running it. A name with a space becomes two names, unless "
         "quotes keep it together. Quote every \"$variable\" too, for the same reason.", "cp \"my notes.txt\" backup/"),
        ("A script is a file of commands. Its first line, the shebang, names the program that reads it: "
         "#!/usr/bin/env bash. chmod +x gives the right to run it, then ./ runs it from here.",
         "chmod +x report.sh; ./report.sh"),
        ("A for loop runs the same commands once per item: $f holds one file name each turn. Put echo in front "
         "first to see what it would do, then remove it. A script adds shopt -s nullglob and mv --.", "for f in *.JPG; do echo mv \"$f\" \"${f%.JPG}.jpg\"; done"),
    ]},
    {"id": "sort", "tool": "sort", "topics": ("bash", "linux"), "title": "sort, the organizer", "pages": [
        ("sort prints the lines of a file in alphabetical order. The file itself doesn't change.",
         "sort names.txt"),
        ("Numbers sorted as text go wrong: 10 comes before 9, because the character 1 comes before 9. "
         "-n compares them as numbers.", "sort -n scores.txt"),
        ("-r reverses the order, biggest first. Together, -rn and then head keep the top of the list.",
         "sort -rn scores.txt | head -3"),
        ("sort puts identical lines side by side. That's what uniq needs, since it only merges lines that "
         "follow each other: uniq -c then counts each group. sort -u keeps one of each.",
         "sort visitors.txt | uniq -c"),
    ]},
    {"id": "pipes", "tool": "|", "topics": ("bash", "linux"), "title": "Pipes", "pages": [
        ("A pipe | sends what one command prints into the next command, as if it were a file.",
         "ls | wc -l     # how many files here?"),
        ("Chain small tools, one step each: grep keeps the lines with error, sort puts identical lines "
         "side by side, uniq -c counts each group.", "grep error app.log | sort | uniq -c"),
        ("uniq only merges identical lines that follow each other. Without sort, a city that appears on "
         "lines 1 and 3 is counted twice. So sort always comes before uniq.",
         "cut -d' ' -f3 people.txt | sort | uniq -c"),
        ("Read a pipe left to right: take a column, keep each value once (sort -u = sort then uniq), "
         "then count the lines.", "cut -d' ' -f1 access.log | sort -u | wc -l"),
    ]},
    {"id": "awk", "tool": "awk", "topics": ("bash", "linux"), "title": "awk, the column reader", "pages": [
        ("awk reads a file line by line and cuts each line into fields: $1 is the first word, "
         "$2 the second, $NF the last.", "awk '{print $1}' people.txt"),
        ("-F sets the separator, for CSV and friends.", "awk -F, '{print $2}' sales.csv"),
        ("A condition before the braces picks lines; END runs after the last one. n+0 prints 0 when no line matched.",
         "awk '$2 > 30 {n++} END {print n+0}' people.txt"),
    ]},
    {"id": "rights_disk_archives", "tool": "chmod", "topics": ("linux",), "title": "Rights, disk and archives", "pages": [
        ("ls -l shows each file's rights in three groups: you (user), your group, everyone else (others). "
         "r reads, w writes, x runs. id tells you who you are and which groups you belong to.", "ls -l; id"),
        ("chmod changes the rights. In numbers, r = 4, w = 2, x = 1, added up per group: 600 is rw for you "
         "and nothing for the others, 755 lets everyone read and run but only you write.",
         "chmod 600 diary.txt; chmod 755 backup.sh"),
        ("df shows how full each disk is, du how much space a folder takes with everything inside. -h prints "
         "sizes people can read, -s one total per folder.", "du -sh * | sort -h"),
        ("tar packs many files into one, gzip squeezes it: a .tar.gz. -c creates, -t lists, -x unpacks, z for "
         "gzip, f for the archive's name, and -C picks the folder to unpack into.", "tar -xzf backup.tar.gz -C restore/"),
    ]},
    {"id": "services", "tool": "systemctl", "topics": ("linux",), "title": "Services and unit files", "pages": [
        ("A service is a program that runs in the background, started by systemd. systemctl status NAME says "
         "if it runs, since when, and its last log lines.", "systemctl status systemd-journald"),
        ("Each service is described by a unit file, in sections: [Unit] says what it is, [Service] how to run it "
         "(ExecStart is the command), [Install] when to start it at boot (WantedBy).", "systemctl cat systemd-journald"),
        ("After you change a unit file, systemctl daemon-reload makes systemd read it again. enable starts it "
         "at every boot, --now also starts it right away.", "sudo systemctl daemon-reload; sudo systemctl enable --now app"),
    ]},
    {"id": "git_basics", "tool": "git", "topics": ("bash", "linux"), "title": "git: commits, branches, merges", "pages": [
        ("git keeps the history of a folder. git status shows what changed, git add picks what goes into the "
         "next commit, git commit -m saves it with a message. Only what you added is saved.",
         "git add notes.txt; git commit -m 'Add milk'"),
        ("A branch is a separate line of commits, to try something without touching main. git switch -c NAME "
         "creates one and moves onto it; git switch main comes back.", "git switch -c try-ideas"),
        ("git merge brings a branch's commits into the one you're on. When both changed the same line, git stops "
         "and writes both versions between <<<<<<<, ======= and >>>>>>> markers. Edit the file, then git add and "
         "git commit.", "git merge chef; git status"),
    ]},
    {"id": "pipelines", "tool": "yaml", "topics": ("cicd",), "title": "Pipeline files", "pages": [
        ("GitHub Actions reads .github/workflows/*.yml, GitLab reads .gitlab-ci.yml. Names that start with "
         "a dot are hidden: ls -a shows them.", "ls -a; cat .gitlab-ci.yml"),
        ("These files are YAML, written like an outline: a line pushed further right belongs to the line "
         "above it. Each level is usually 2 spaces further right. Only spaces, never tabs.",
         "cat .github/workflows/ci.yml"),
        ("Jobs run side by side unless you set an order: needs: on GitHub, stages: on GitLab. A deploy "
         "should wait for the tests, and be skipped when they fail.", "grep -n 'needs:\\|stage' .gitlab-ci.yml"),
        ("Conditions decide when a job runs: if: on GitHub, rules: on GitLab. when: manual makes "
         "the job wait for a click on its play button, handy for a production deploy.", "grep -n 'if:\\|rules:\\|when:' .gitlab-ci.yml"),
        ("Never write a password or a token in the file: everyone who reads the repository gets it. The "
         "CI keeps secrets for you: ${{ secrets.NAME }} on GitHub, a CI/CD variable on GitLab.",
         "grep -rni 'token\\|password' .github .gitlab-ci.yml"),
    ]},
    {"id": "conditions", "tool": "if", "topics": ("logic",), "title": "Conditions: if, !, && and ||", "pages": [
        ("Every command answers yes or no when it ends: its exit status. 0 means it worked (yes), anything else "
         "means it didn't (no). if runs its block only when the command after it says yes.",
         "if grep -qx alice guests.txt; then echo welcome; fi"),
        ("[ ] is a command too, made to test things: -f name is a file, -d name is a folder, \"$a\" = \"$b\" "
         "compares two texts. Keep a space after [ and before ], or bash can't read it.",
         "if [ -d backup ]; then echo 'the backup folder is here'; fi"),
        ("! turns the answer around: yes becomes no. Read it aloud as NOT. One ! too many or too few, and a "
         "script lets in exactly the people it should keep out.", "if ! grep -qx eve guests.txt; then echo 'not invited'; fi"),
        ("&& means AND: true only when both sides are true. || means OR: true as soon as one side is. Before "
         "copying a file into a folder, you need the file AND the folder.",
         "if [ -f notes.txt ] && [ -d backup ]; then cp notes.txt backup/; fi"),
    ]},
    {"id": "sql", "tool": "sqlite3", "topics": ("sql",), "title": "SQL with SQLite", "pages": [
        ("A database keeps data in tables: rows and columns, like a spreadsheet the computer can search fast. "
         "SQLite keeps a whole database in one file: sqlite3 opens it, and creates it if it doesn't exist yet. "
         "Delete the file and the database is gone, nothing else to clean up.", "sqlite3 shop.db"),
        ("Words that start with a dot are sqlite3's own commands: .tables lists the tables, .schema shows how "
         "one is built (its columns and their types), .quit leaves. You can also give them right after the file.",
         "sqlite3 shop.db .schema products"),
        ("SQL itself reads almost like English. SELECT picks columns, FROM names the table, WHERE keeps only the "
         "rows that match. A statement ends with a ;, and text goes between single quotes.",
         "sqlite3 shop.db \"SELECT name, price FROM products WHERE price > 20;\""),
        ("COUNT(*) counts the rows, SUM(col) adds up a column, ORDER BY sorts. They answer questions like "
         "\"how many\" and \"how much\" without reading every row yourself.",
         "sqlite3 shop.db \"SELECT COUNT(*) FROM products WHERE stock = 0;\""),
        ("Tables point at each other with numbers: an order keeps the id of its customer, not the name, so a "
         "name is written only once. JOIN … ON puts the matching rows side by side again.",
         "sqlite3 shop.db \"SELECT customers.name, orders.total FROM orders JOIN customers ON orders.customer_id = customers.id;\""),
        ("CREATE TABLE makes a table and gives each column a type: TEXT for words, INTEGER for whole numbers. "
         "INSERT INTO adds a row: the columns, then the values in the same order.",
         "sqlite3 shop.db \"INSERT INTO products (name, price, stock) VALUES ('lamp', 25, 12);\""),
        ("UPDATE changes rows, and WHERE picks which ones. Forget the WHERE and every row changes! Run a SELECT "
         "with the same WHERE first: it shows exactly what the UPDATE (or a DELETE) will touch.",
         "sqlite3 shop.db \"UPDATE products SET price = 30 WHERE name = 'lamp';\""),
        ("Add a row, or change it if it's already there? INSERT … ON CONFLICT DO UPDATE (an \"upsert\") does both "
         "in one statement. INSERT OR REPLACE looks similar but deletes the old row first: its other columns are lost.",
         "sqlite3 stock.db \"INSERT INTO stock (item, qty) VALUES ('mug', 5) ON CONFLICT(item) DO UPDATE SET qty = qty + excluded.qty;\""),
    ]},
    {"id": "secrets", "tool": "gpg", "topics": ("linux",), "title": "gpg and pass, for secrets", "pages": [
        ("A file in clear can be read by anyone who gets the disk, a backup or your repository. gpg (GnuPG) locks "
         "files. -c locks one with a passphrase, and the same passphrase opens it.", "gpg -c notes.txt   # writes notes.txt.gpg"),
        ("gpg -d opens a locked file and prints it; -o writes it to a file instead. gpg keeps the clear original "
         "when it locks one: delete it yourself once the .gpg is made.", "gpg -d notes.txt.gpg"),
        ("A key pair has two halves: the public key you give to anyone, and the private key only you keep. What "
         "is encrypted for your public key opens only with your private key.", "gpg --full-generate-key"),
        ("It works the other way for signatures: a project signs its downloads with its private key, and you "
         "check them with its public key. \"Good signature\": that key signed it, and nothing changed since. It's "
         "from them only if the key is theirs: check its fingerprint on their HTTPS site or docs.",
         "gpgv --keyring ./vendor.gpg tool.tar.gz.sig tool.tar.gz"),
        ("pass is the Unix password store: each password in its own file under ~/.password-store, encrypted with "
         "your gpg key. pass init <your key> starts it; pass generate makes a strong password; pass show prints one.",
         "pass generate web/forum 24"),
        ("A script should never hold a password: it ends up in backups, screenshots and git history. $( ) lets it "
         "fetch the password when it runs, so the file stays safe to share. || exit 1 stops it when pass fails.",
         "db_password=$(pass show db/prod) || exit 1"),
        ("Not installed yet? On Debian and Ubuntu: sudo apt install gnupg pass. On Rocky and Alma: sudo dnf install "
         "gnupg2, then pass from EPEL (sudo dnf config-manager --set-enabled crb, then sudo dnf install epel-release; on RHEL, see the EPEL docs).", "sudo apt install gnupg pass"),
    ]},
    {"id": "gdb", "tool": "gdb", "topics": ("c",), "title": "gdb, the debugger", "pages": [
        ("A debugger runs your program and lets you stop it and look inside. Build with -g first: it keeps the "
         "line numbers, so gdb can say where you are.", "gcc -g crash.c -o crash"),
        ("gdb -q ./crash opens it, run starts it. When it crashes, gdb stops right there instead of just printing "
         "'Segmentation fault'.", "gdb -q ./crash"),
        ("bt (backtrace) lists the calls that led there, the one that crashed first, each with its file and line. "
         "That's where to look.", "(gdb) bt"),
        ("break sets a stop: break main, or break loan.c:12. next runs one line, step goes into a call, print x "
         "shows a variable, continue goes on to the next stop.", "(gdb) break month_end if month == 5"),
        ("One line, no typing inside gdb: -batch runs the -ex commands in order, then quits. Not installed yet? "
         "sudo apt install gdb, or sudo dnf install gdb.", "gdb -q -batch -ex run -ex bt ./crash"),
    ]},
    {"id": "ss", "tool": "ss", "topics": ("network",), "title": "ss: who listens, who is connected", "pages": [
        ("Programs talk over the network through sockets. A server opens one and listens on a port; each client "
         "that connects gets a connection of its own. ss lists them all.", "ss -tln"),
        ("-t keeps TCP, -l only the listening ones, -n prints numbers instead of names. The Local Address column says "
         "where it listens: 127.0.0.1 or ::1 is this machine only, 0.0.0.0 or * is every network.", "ss -tln"),
        ("-p adds the program and its PID (sudo shows other users' programs too). The fastest way to check a server "
         "really started, and where.", "ss -tlnp"),
        ("Without -l, ss shows connections: ESTAB is open, TIME-WAIT just closed. -6 keeps IPv6 only, and filters pick "
         "a port: state established '( dport = :443 )'.", "ss -tn state established"),
    ]},
    {"id": "ssh", "tool": "ssh-keygen", "topics": ("network",), "title": "ssh: keys and fingerprints", "pages": [
        ("ssh opens a shell on another machine, encrypted. Log in with a key rather than a password: ssh-keygen makes "
         "the pair, and a passphrase protects the private half if your laptop is stolen.",
         "ssh-keygen -t ed25519"),
        ("The public half goes on the server, into ~/.ssh/authorized_keys. ssh-copy-id puts it there for you, "
         "asking your password one last time.", "ssh-copy-id you@backup.internal"),
        ("ssh guards your keys: it ignores a private key anyone but you can read or write, and the server refuses "
         "authorized_keys if others can write it, ~/.ssh or your home. ~/.ssh is 700, the private key 600.", "chmod 700 ~/.ssh && chmod 600 ~/.ssh/id_ed25519"),
        ("The first time, ssh shows the server's fingerprint and asks. Paste the one the admin "
         "gave you instead of yes: ssh accepts only if it matches. ssh-keygen -l prints a key's fingerprint; ~/.ssh/known_hosts remembers it.",
         "ssh-keygen -lf host_key.pub"),
    ]},
    {"id": "firewall", "tool": "nft", "topics": ("network",), "title": "Firewalls: who may come in", "pages": [
        ("A firewall decides, packet by packet, what may come in or go out. Linux's own is nftables; Rocky drives it with "
         "firewalld, Debian has nft but filters nothing until you write rules, a Mac has pf and the application firewall.",
         "sudo nft list ruleset"),
        ("A chain is read from the top: the first rule that matches with a verdict decides, accept, drop or reject. "
         "When none matches, the chain's policy decides.", "tcp dport 22 accept"),
        ("drop says nothing: the client waits, then times out. reject answers at once: connection refused, or No route "
         "to host. So a timeout points to a firewall that drops, or a machine that's off on another network.", "ip saddr 203.0.113.0/24 drop"),
        ("On Rocky, firewalld keeps zones: --list-all shows what the active one lets in. --add-service changes only the "
         "running firewall, which a reload forgets; with --permanent it writes the saved setup, and --reload applies it.", "sudo firewall-cmd --list-all"),
    ]},
    {"id": "certs", "tool": "openssl", "topics": ("network",), "title": "openssl: read a certificate", "pages": [
        ("A certificate ties a public key to names, until a date, and a CA signs that promise. openssl x509 reads one: "
         "-noout skips the base64 block, and you name the fields you want.", "openssl x509 -in site.pem -noout -subject -enddate"),
        ("-issuer names who signed it. Each issuer is signed in turn, up to a root CA your system trusts: the chain. A "
         "self-signed certificate is its own issuer, and nobody vouches for it.", "openssl x509 -in site.pem -noout -issuer"),
        ("Browsers only check the names in the Subject Alternative Name (SAN), never the CN. A Mac's openssl is LibreSSL, "
         "without -ext: use -text there, and read the line under Subject Alternative Name.",
         "openssl x509 -in site.pem -noout -ext subjectAltName"),
        ("-checkend asks: still valid in that many seconds? Exit status 0 for yes, 1 for no, so a script or your "
         "monitoring can warn before the site goes down. 2592000 seconds is 30 days.",
         "openssl x509 -in site.pem -noout -checkend 2592000"),
    ]},
    {"id": "certs_ca", "tool": "openssl", "topics": ("network",), "title": "openssl: inside a CA", "pages": [
        ("A CA is a certificate whose basicConstraints says CA:TRUE: it may sign others. pathlen says how many CAs may "
         "come below it; pathlen:0, servers' certificates only. A Mac's LibreSSL has no -ext: use -text, and read "
         "Basic Constraints.", "openssl x509 -in inter.pem -noout -ext basicConstraints"),
        ("openssl verify checks a chain like a client: -CAfile the root you trust, -untrusted the intermediates. When it "
         "fails, the line above the error names the certificate, and depth 0 is the leaf.",
         "openssl verify -CAfile root.pem -untrusted chain.pem leaf.pem"),
        ("When a key leaks, its CA revokes the certificate and publishes a CRL, a signed list of serial numbers that "
         "must not be trusted any more. openssl crl reads one.", "openssl crl -in crl.pem -noout -text"),
        ("openssl reads its settings from openssl.cnf: openssl version -d prints its folder. -config uses another file, "
         "-extensions picks one of its sections.", "openssl version -d"),
    ]},
    {"id": "bash_zsh", "tool": "bash", "topics": ("bash",), "title": "bash and zsh", "pages": [
        ("Your terminal runs a shell: bash on most Linux systems, zsh on a Mac and for many developers. They read almost every line the same way. echo $0 tells you which one you're typing in.",
         "echo $0"),
        ("A script names its shell on its first line, #!/usr/bin/env bash. Run it as ./script.sh and bash reads it, even from zsh, so it behaves the same for everyone. bash script.sh does the same by hand.",
         "bash nothing.sh"),
        ("Where they differ: bash splits an unquoted $var at its spaces, zsh doesn't. Quotes, \"$var\", give one word in both, so they're the habit to keep.",
         "ls \"$f\""),
        ("When no file matches a pattern, bash hands the pattern itself to the command, while zsh stops with \"no matches found\". And arrays count from 0 in bash, from 1 in zsh.",
         "echo *.pdf"),
    ]},
]
BY_ID = {lesson["id"]: lesson for lesson in LESSONS}


def next_for(topic, seen):
    """The first lesson of this topic you haven't had yet, or None."""
    return next((le for le in LESSONS if topic in le["topics"] and le["id"] not in seen), None)
