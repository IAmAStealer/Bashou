# Bashou: the pet in every interactive bash or zsh (`bashou off` to hide it), from this package.
if [ -n "${BASH_VERSION:-}" ] && [ -r /usr/share/bashou/bashou/handover.bash ]; then
  case $- in *i*) . /usr/share/bashou/bashou/handover.bash ;; esac
elif [ -n "${ZSH_VERSION:-}" ] && [ -r /usr/share/bashou/bashou/handover.zsh ]; then
  case $- in *i*) . /usr/share/bashou/bashou/handover.zsh ;; esac
fi
