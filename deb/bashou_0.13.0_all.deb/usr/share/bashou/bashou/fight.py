"""The arena: a bash sub-shell in a sandbox folder where you beat a threat with a real tool.

`bashou fight` runs `run()`. Inside the arena, the shell functions `answer`, `hint` and
`task` call back into this module (`python3 launch.py bashou.fight answer <base> <value>`).
"""

import datetime
import json
import os
import random
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from . import achievements, challenges, duel, lesson, progress, skills, state, which
from .analyze import analyze, parse_log
from .lesson import reader
from .i18n import _, cap
from .render import BOLD, DIM, RESET, ACCENT, GOOD, BAD

WIN, FLEE, KO = 42, 3, 4   # exit codes of the arena shell (Ctrl-D is a flee, KO: no hearts left)
TIMEOUT = -1               # `bashou arena`'s clock ran out (not an exit code: Bashou stops the shell)
THREAT_HOURS = 2           # a threat waits until midnight, and at least this long (owner, 2026-10-20)

RC = r"""
[[ -f ~/.bash_aliases ]] && source ~/.bash_aliases
export BASHOU_ARENA_SHELL=bash
PS1='\[\e[38;2;240;110;110m\]⚔ arena\[\e[0m\] \W \$ '
export GPG_TTY=$(tty)                              # gpg asks for passphrases in this terminal
HISTFILE=$BASHOU_ARENA/history
_arena_log() {
  local s=$?
  if [[ -n $_arena_hc && $HISTCMD != "$_arena_hc" ]]; then
    printf '%s\t' "$s" >> "$BASHOU_ARENA/log"
    HISTTIMEFORMAT= history 1 >> "$BASHOU_ARENA/log"
    if [[ -n $BASHOU_DUEL ]]; then
      "${BASHOU_PYTHON:-python3}" "$BASHOU_SRC/launch.py" bashou.duel judge "$BASHOU_ARENA"
      (( $? == 4 )) && exit 4
    fi
  fi
  _arena_hc=$HISTCMD
  _arena_tip
  [[ -n $BASHOU_DUEL ]] && _bashou_make_room         # empty top rows for the fight panel
  return "$s"
}
_arena_tip() {
  local cmd
  cmd=$(HISTTIMEFORMAT= history 1)
  if [[ $cmd == *uniq* && $cmd != *sort*uniq* && -r $BASHOU_ARENA/tip_uniq ]]; then
    printf '%s\n' "$(< "$BASHOU_ARENA/tip_uniq")"
    rm -f "$BASHOU_ARENA/tip_uniq"
  fi
}
PROMPT_COMMAND=_arena_log
if [[ -n $BASHOU_DEADLINE ]]; then                 # `bashou arena`: the time left, in the prompt (no fork)
  _arena_clock() {
    local now left
    printf -v now '%(%s)T' -1
    left=$(( BASHOU_DEADLINE - now ))
    (( left < 0 )) && left=0
    printf -v _arena_left '⏱ %d:%02d' $(( left / 60 )) $(( left % 60 ))
  }
  PROMPT_COMMAND='_arena_log; _arena_clock'
  PS1='\[\e[38;2;240;200;100m\]${_arena_left}\[\e[0m\] '$PS1
fi
_arena() { "${BASHOU_PYTHON:-python3}" "$BASHOU_SRC/launch.py" bashou.fight "$@" "$BASHOU_ARENA"; }
answer() { _arena answer "$*" && exit 42; }
verify() { _arena verify && exit 42; }
hint() { _arena hint; }
check() { _arena check; }
lesson() { _arena lesson; }
task() { _arena task; }
flee() { exit 3; }
# The fight panel is drawn at the top, like the pet: the same room is made for it (bashou/room.bash).
_bashou_height=$BASHOU_ARENA/height _bashou_room=$BASHOU_ARENA/room _bashou_erase=$BASHOU_ARENA/erase
_arena_ps0() {
  _bashou_tty_back
  rm -f "$_bashou_room"                              # the panel waits for the next prompt's room
  _bashou_close_room && return
  [[ -r $_bashou_erase ]] && printf '%s' "$(< "$_bashou_erase")"
}
if [[ -n $BASHOU_DUEL ]]; then
  source "$BASHOU_SRC/bashou/room.bash"
  PS0='$(_arena_ps0)'
fi
cd "$BASHOU_ARENA/arena"
"""

# The arena for zsh players (0.9.0): the same commands and logs as RC, with zsh's hooks. preexec gets the
# command line as typed (no preexec for an empty line), precmd logs it in the layout of bash's `history 1`.
ZSH_RC = r"""
export BASHOU_ARENA_SHELL=zsh
PS1=$'%{\e[38;2;240;110;110m%}\u2694 arena%{\e[0m%} %1~ %(!.#.$) '
export GPG_TTY=$(tty)                              # gpg asks for passphrases in this terminal
HISTFILE=$BASHOU_ARENA/history
_arena_cmd=
_arena_preexec() {
  _arena_cmd=$1
  [[ -n $BASHOU_DUEL ]] && _arena_ps0
}
_arena_log() {
  local s=$? cmd=$_arena_cmd
  _arena_cmd=
  if [[ -n $cmd ]]; then
    printf '%s\t    1  %s\n' "$s" "$cmd" >> "$BASHOU_ARENA/log"
    if [[ -n $BASHOU_DUEL ]]; then
      "${BASHOU_PYTHON:-python3}" "$BASHOU_SRC/launch.py" bashou.duel judge "$BASHOU_ARENA"
      (( $? == 4 )) && exit 4
    fi
    _arena_tip "$cmd"
  fi
  [[ -n $BASHOU_DUEL ]] && _bashou_make_room       # empty top rows for the fight panel
  return $s
}
_arena_tip() {
  if [[ $1 == *uniq* && $1 != *sort*uniq* && -r $BASHOU_ARENA/tip_uniq ]]; then
    printf '%s\n' "$(<"$BASHOU_ARENA/tip_uniq")"
    rm -f "$BASHOU_ARENA/tip_uniq"
  fi
}
precmd_functions=(_arena_log)
preexec_functions=(_arena_preexec)
if [[ -n $BASHOU_DEADLINE ]]; then                 # `bashou arena`: the time left, in the prompt
  zmodload zsh/datetime
  _arena_clock() {
    local left=$(( BASHOU_DEADLINE - EPOCHSECONDS ))
    (( left < 0 )) && left=0
    printf -v _arena_left '\u23f1 %d:%02d' $(( left / 60 )) $(( left % 60 ))
  }
  precmd_functions+=(_arena_clock)
  setopt prompt_subst
  PS1=$'%{\e[38;2;240;200;100m%}${_arena_left}%{\e[0m%} '$PS1
fi
_arena() { "${BASHOU_PYTHON:-python3}" "$BASHOU_SRC/launch.py" bashou.fight "$@" "$BASHOU_ARENA"; }
answer() { _arena answer "$*" && exit 42; }
verify() { _arena verify && exit 42; }
hint() { _arena hint; }
check() { _arena check; }
lesson() { _arena lesson; }
task() { _arena task; }
flee() { exit 3; }
_bashou_height=$BASHOU_ARENA/height _bashou_room=$BASHOU_ARENA/room _bashou_erase=$BASHOU_ARENA/erase
_arena_ps0() {
  rm -f "$_bashou_room"
  _bashou_close_room && return
  [[ -r $_bashou_erase ]] && printf '%s' "$(<"$_bashou_erase")"
}
[[ -n $BASHOU_DUEL ]] && source "$BASHOU_SRC/bashou/room.zsh"
cd "$BASHOU_ARENA/arena"
"""


def player_shell():
    """The shell the player types in (the loaders export BASHOU_SHELL): the arena runs in it. bash otherwise."""
    shell = os.environ.get("BASHOU_SHELL", "")
    return shell if shell in ("bash", "zsh") and shutil.which(shell) else "bash"


def arena_shell(base, shell):
    """Write the arena's rc file for `shell` into `base`: (argv, extra environment) to start it."""
    if shell == "zsh":
        (base / ".zshrc").write_text(ZSH_RC)
        return ["zsh", "-i"], {"ZDOTDIR": str(base)}
    (base / "arena.rc").write_text(RC)
    return ["bash", "--rcfile", str(base / "arena.rc"), "-i"], {}


# --- threats ---------------------------------------------------------------

def level(s):
    return (len(s["pets"]) + sum(progress.reached(s, p) - 1 for p in s["pets"])
            + min(progress.starter_level(s), 9) - 1)            # the starter's first 9 levels


def remaining(s):
    return [c for c in challenges.ALL if c.id not in s["challenges"] and c.available()
            and skills.wanted(s, c.skill)]


def learned(s, tool):
    """You've met a tool: used it at least once, had its lesson in `bashou adventure`, or read a
    `bashou lesson` that teaches it (its "tools")."""
    lessons = (s.get("adventure") or {}).get("lessons", [])
    if tool == "|":
        return s["constructs"].get("pipe3", 0) > 0 or "pipes" in lessons
    read = set((s.get("lessons") or {}).get("read", []))
    library = any(tool in le.get("tools", ()) for le in lesson.english() if le["id"] in read)
    return s["tools"].get(tool, 0) > 0 or tool in lessons or library


def built_on(s, ch):
    """The fights `ch` builds on are beaten, or can't come on this machine (no leak detector on a Mac: no Leak
    Lurker, and the Overflow Ogre after it still comes)."""
    return all(a in s["challenges"] or not challenges.BY_ID[a].available() for a in ch.after)


def ready(s, ch):
    """Beginners first: level 1 fights come anytime; harder ones once you've met their tool and
    beaten the fights they build on (the Knot Eel needed pipes and uniq nobody had shown you)."""
    if not built_on(s, ch):
        return False
    return ch.level == 1 or any(learned(s, t) for t in ch.tools)


def to_discover(s):
    """Tools of the next fights you can't get yet only because you haven't met them."""
    return list(dict.fromkeys(ch.tool for ch in remaining(s)       # once each: the pets pick one at random
                              if not ready(s, ch) and built_on(s, ch)))


def threats_per_day(s, today=None):
    """About 3 a day at first, 2 later, fewer when the bank runs low, none when it's empty
    (reviews that are due count as fights left)."""
    left = len(remaining(s)) + len(due(s, today))
    return max(2, min(3, 3 - level(s) // 3)) * min(1, left / 5)


# --- reviews: a beaten fight comes back after 1, 7 and 30 days (owner: learning is repetition) ---------

INTERVALS = (1, 7, 30)          # days before each review; after the last one the tool is acquired
REVIEW_FIRST = 0.6              # when reviews and new fights are both waiting, reviews usually go first


def due(s, today=None):
    """Beaten fights whose review day has come."""
    today = today or datetime.date.today().isoformat()
    return [challenges.BY_ID[cid] for cid, r in s.get("reviews", {}).items()
            if r["due"] <= today and cid in challenges.BY_ID and challenges.BY_ID[cid].available()]


def after_fight(s, ch, won, today=None):
    """Move `ch` along its reviews after a fight. Returns what to tell the player, or None."""
    today = datetime.date.fromisoformat(today) if today else datetime.date.today()
    reviews = s.setdefault("reviews", {})
    r = reviews.get(ch.id)
    if not won:                                            # lost or fled
        if r and r["due"] <= today.isoformat():             # a review: the wins before it stay, one step back
            step = max(0, r["step"] - 1)
            r.update(step=step, due=(today + datetime.timedelta(days=INTERVALS[step])).isoformat())
            if INTERVALS[step] == 1:
                return _("It'll be back tomorrow for review {n}/{total}.").format(n=step + 1, total=len(INTERVALS))
            return _("It'll be back in {days} days for review {n}/{total}.").format(
                days=INTERVALS[step], n=step + 1, total=len(INTERVALS))
        return None
    if ch.id not in s["challenges"]:
        reviews[ch.id] = {"step": 0, "due": (today + datetime.timedelta(days=INTERVALS[0])).isoformat()}
        return _("It'll be back tomorrow: fighting it again is how `{tool}` sticks.").format(tool=ch.tool)
    if not r or r["due"] > today.isoformat():
        return None                                        # acquired already, or not due yet
    step = r["step"] + 1
    if step >= len(INTERVALS):
        del reviews[ch.id]
        return _("Last review won: `{tool}` is yours for good.").format(tool=ch.tool)
    r.update(step=step, due=(today + datetime.timedelta(days=INTERVALS[step])).isoformat())
    return _("Review {n}/{total} won. It'll be back in {days} days.").format(
        n=step, total=len(INTERVALS), days=INTERVALS[step])


def active_threat(s, now=None):
    t = s.get("threat")
    if t and t["until"] > (now or time.time()):
        return t
    return None


def threat_until(now):
    """The end of the day, THREAT_HOURS from now at least: a fight a day or two is easy to miss."""
    midnight = datetime.datetime.combine(datetime.date.fromtimestamp(now) + datetime.timedelta(days=1),
                                         datetime.time()).timestamp()
    return max(midnight, now + THREAT_HOURS * 3600)


def maybe_threat(s, rng=random, now=None):
    """Called under the lock from the companion. Returns a notification or None."""
    now = now or time.time()
    if s.get("threat") and s["threat"]["until"] <= now:
        s["threat"] = None                                 # it left
    if s.get("threat"):
        return None
    today = datetime.date.fromtimestamp(now).isoformat()
    if s["threat_day"]["date"] != today:
        s["threat_day"] = {"date": today, "count": 0}
    if s["threat_day"]["count"] >= threats_per_day(s, today) or now - s["last_threat"] < 2 * 3600:
        return None
    new, back = [ch for ch in remaining(s) if ready(s, ch)], due(s, today)
    if not (new or back) or rng.random() > 1 / 120:        # one chance in 120 per 30 s at the prompt
        return None
    review = bool(back) and (not new or rng.random() < REVIEW_FIRST)
    ch = rng.choice(back if review else new)
    s["threat"] = {"challenge": ch.id, "until": threat_until(now), "review": review}
    s["threat_day"]["count"] += 1
    s["last_threat"] = now
    return announcement(s, now)


# --- the Honey badger: it doesn't wait for threats (owner, 2026-10-04) --------------------------------
# When it's your pet and the terminal has been quiet for a while, it gets bored and picks a fight itself.
# The pet writes fight.<shell pid> in the cache; the loader sees it at the next prompt and opens the arena
# right after your next command (bashou.bash), with no `bashou fight` to type.
BADGER = "honey_badger"
BORED_MINUTES = 10
BADGER_PER_DAY = 2
BADGER_WAITS = 12 * 3600       # its fight waits for you to come back, longer than a normal threat


def next_fight(s, rng=random):
    """The announced threat, else a review that is due, else a new fight you're ready for, else None."""
    ch = pick(s)
    if ch:
        return ch
    back = due(s)
    if back:
        return rng.choice(back)
    new = [c for c in remaining(s) if ready(s, c)]
    return rng.choice(new) if new else None


def badger_fight(s, idle_ms, rng=random, now=None):
    """Called under the lock from the companion. When the Honey badger is your pet and you've left the
    terminal alone for BORED_MINUTES, it picks a fight (BADGER_PER_DAY at most). Returns True when it did."""
    if progress.who_of(s) != BADGER or idle_ms < BORED_MINUTES * 60_000:
        return False
    now = now or time.time()
    today = datetime.date.fromtimestamp(now).isoformat()
    if s["badger_day"]["date"] != today:
        s["badger_day"] = {"date": today, "count": 0}
    if s["badger_day"]["count"] >= BADGER_PER_DAY:
        return False
    ch = next_fight(s, rng)
    if not ch:
        return False
    review = ch.id in {c.id for c in due(s, today)}
    s["threat"] = {"challenge": ch.id, "until": now + BADGER_WAITS, "review": review, "badger": True}
    s["badger_day"]["count"] += 1
    return True


def announcement(s, now=None):
    """What the pet says about the waiting threat, or None."""
    t = active_threat(s, now)
    if not t or t["challenge"] not in challenges.BY_ID:
        return None
    ch = challenges.BY_ID[t["challenge"]]
    if t.get("badger"):
        return "🦡 " + _("Your Honey badger got bored and went to fight the {threat}! "
                        "The arena opens after your next command.").format(threat=_(ch.threat))
    if t.get("review"):
        return "⚠ " + cap(_("The {threat} is back! Still remember `{tool}`? → bashou fight").format(
            threat=_(ch.threat), tool=ch.tool))
    return "⚠ " + cap(_("A {threat} is coming! Use `{tool}` to fight it → bashou fight").format(
        threat=_(ch.threat), tool=ch.tool))


def gone(challenge_id):
    """What the pet says when a threat got tired of waiting."""
    ch = challenges.BY_ID.get(challenge_id)
    name = _(ch.threat) if ch else "?"
    return "💨 " + cap(_("The {threat} got tired of waiting and left. It'll be back!").format(threat=name))


# --- arena -----------------------------------------------------------------

def pick(s):
    """The challenge of the threat your pet announced, or None: no threat, no fight."""
    t = active_threat(s)
    if t and t["challenge"] in challenges.BY_ID:
        return challenges.BY_ID[t["challenge"]]
    return None


def load_meta(base):
    return json.loads((Path(base) / "meta.json").read_text())


def used_tool(base, ch):
    try:
        records = parse_log((Path(base) / "log").read_text())
    except FileNotFoundError:
        return False
    return any(status == 0 and not (found := analyze(cmd)).help_only and ch.used_by(found)
               for status, cmd in records)


def cmd_answer(base, value):
    meta = load_meta(base)
    ch = challenges.BY_ID[meta["challenge"]]
    if ch.fix and value.strip() not in ("done", ""):
        print(ACCENT + "✗ " + _("Nothing to answer here: run `{value}` at the prompt, and when it works type `verify`.")
              .format(value=value.strip()) + RESET)
        return 1
    if not ch.check(Path(base) / "arena", meta, value):
        if ch.fix:
            print(BAD + "✗ " + _("Not yet: Bashou checked your work and it isn't right yet. "
                                "Look again, try it at the prompt, then verify.") + f"{RESET} {DIM}(hint · lesson · task · flee){RESET}")
            why = ch.why and ch.why(Path(base) / "arena")
            if why:
                print(ACCENT + "  " + why + RESET)
        elif ch.kind == "trial":
            print(BAD + "✗ " + _("Not yet: the chest is still locked.") + f"{RESET} {DIM}(hint · lesson · task · flee){RESET}")
        elif ch.kind == "security":
            print(BAD + "✗ " + _("Not quite. Keep looking.") + f"{RESET} {DIM}(hint · lesson · task · flee){RESET}")
        else:
            print(BAD + "✗ " + _("Not quite. The {threat} shrugs it off.").format(threat=_(ch.threat))
                  + f"{RESET} {DIM}(hint · lesson · task · flee){RESET}")
        return 1 if ch.fix else duel.WRONG
    if ch.kind == "fight" and not used_tool(base, ch) and ch.needs:
        print(ACCENT + "✓ " + _("Right answer.") + " " + _(ch.needs) + RESET)
        return 1
    if ch.kind == "fight" and not used_tool(base, ch) and ch.fix:
        print(ACCENT + "✓ " + _("Right, but only `{tool}` can hurt the {threat}. "
                                "Run it with {tool} (a successful command), then verify again.")
              .format(tool=ch.tool, threat=_(ch.threat)) + RESET)
        return 1
    if ch.kind == "fight" and not used_tool(base, ch):   # investigations: any way you like
        print(ACCENT + "✓ " + _("Right answer, but only `{tool}` can hurt the {threat}. "
                                "Solve it with {tool} (a successful command), then answer again.")
              .format(tool=ch.tool, threat=_(ch.threat)) + RESET)
        return 1
    return 0


def cmd_verify(base):
    """`verify`: the same strike as `answer`, named for fights where you do the job (fix a file…)."""
    ch = challenges.BY_ID[load_meta(base)["challenge"]]
    if not ch.fix:
        print(ACCENT + _("This one asks a question: answer <value>") + RESET)
        return 1
    return cmd_answer(base, "done")


def cmd_hint(base):
    meta = load_meta(base)
    ch = challenges.BY_ID[meta["challenge"]]
    i = min(meta.get("hints", 0), len(ch.hint_list(meta)) - 1)
    print(f"{ACCENT}💡 {ch.hint_text(i, meta)}{RESET}")
    meta["hints"] = i + 1
    (Path(base) / "meta.json").write_text(json.dumps(meta))
    return 0


def lesson_progress(s):
    return lesson.progress_of(s)


def cmd_lesson(base):
    """`lesson` in the arena: the Sage Owl's lesson for this fight, in the library reader."""
    ch = challenges.BY_ID[load_meta(base)["challenge"]]
    found = lesson.for_fight(lesson.load(), ch.id)
    if not found:
        print(DIM + _("No lesson for this one yet: try hint.") + RESET)
        return 0
    return reader.main([found[0]["id"]])


YAMLLINT = ["yamllint", "-d", "relaxed"]      # relaxed: real mistakes, not the style of a long line


def cmd_check(base):
    """`check`: read the file the way verify will, without striking. Pipelines can't be tried at the
    prompt like a script, so this is how you test one before sending it; yamllint too when it's there."""
    ch = challenges.BY_ID[load_meta(base)["challenge"]]
    if not ch.file:
        print(DIM + _("Nothing to check for you here: try your work at the prompt, then verify.") + RESET)
        return 0
    arena = Path(base) / "arena"
    why = ch.why(arena) if ch.why else None
    if why:
        print(BAD + "✗ " + why + RESET)
    else:
        print(GOOD + "✓ " + _("{file} reads as valid YAML. That's the shape; verify then checks what it says "
                             "(the jobs, the steps, the values).").format(file=ch.file) + RESET)
    if shutil.which(YAMLLINT[0]):
        done = subprocess.run(YAMLLINT + [ch.file], cwd=arena, capture_output=True, text=True)
        print(DIM + "$ yamllint " + ch.file + RESET)
        print(done.stdout.rstrip() or _("yamllint has nothing to say: no mistake found."))
        print(DIM + _("yamllint is what real projects run before they push: errors break the file, "
                      "warnings are about style.") + RESET)
    else:
        print(DIM + _("In real projects, a linter checks YAML before you push it: yamllint "
                      "(sudo apt install yamllint, or sudo dnf install yamllint). Once it's installed, "
                      "check runs it too, and you can run it yourself: yamllint {file}").format(file=ch.file) + RESET)
    return 0


def cmd_task(base):
    meta = load_meta(base)
    print(challenges.BY_ID[meta["challenge"]].task_text(meta))
    return 0


def banner(ch, task, review=None):
    """`review`: the fight's entry in s["reviews"] when it comes back for a review."""
    back = ""
    if review:
        back = f"{ACCENT}🔁 " + _("Review {n}/{total}: it came back on purpose. Beating it again after a break "
                                "is what makes `{tool}` stay with you.").format(
            n=review["step"] + 1, total=len(INTERVALS), tool=ch.tool) + f"{RESET}\n"
    return (f"\n{BAD}{BOLD}⚔ " + cap(_("The {threat} attacks!").format(threat=_(ch.threat))) + f"{RESET}  "
            + _("Use {tool} to fight it.").format(tool=f"{BOLD}{ch.tool}{RESET}") + f"\n{back}\n{task}\n\n"
            f"{DIM}" + _("You're in a sandbox folder with a real shell, your own ({program}). Commands:").format(program=player_shell()) + f"{RESET}\n"
            + (strike_done(ch) if ch.fix else "  answer <value>   " + _("strike") + f"   {DIM}("
               + _("needs a successful {tool} command first").format(tool=ch.tool) + f"){RESET}\n")
            + "  hint             " + _("get a hint") + "\n"
            + "  lesson           " + _("read the Sage Owl's lesson about it") + "\n"
            "  task             " + _("show the task again") + "\n"
            "  flee             " + _("run away (the threat will come back)") + "\n")


def strike_done(ch):
    """Fights where you fix a file: `answer` takes no value, Bashou checks the result itself."""
    check = ("  check            " + _("read your file the way verify will, without striking") + "\n"
             if ch.file else "")
    return check + "  verify           " + _("strike when it works: Bashou checks your work") + "\n"


BEGINNER_WINS = 5          # until then, a fight's first hint teaches `tool --help` (owner)


def beginner(s):
    return s["fights_won"] < BEGINNER_WINS


def stop_shell(shell):
    """Time's up: hang up the arena shell (an interactive bash ignores TERM) and whatever it runs."""
    import signal
    try:
        shell.send_signal(signal.SIGHUP)
        shell.wait(timeout=3)
    except subprocess.TimeoutExpired:
        shell.kill()
        shell.wait()
    if sys.stdin.isatty():
        subprocess.run(["stty", "sane"], check=False)        # readline had the terminal
    return TIMEOUT


def arena(ch, intro, rng=None, fight=False, help_first=False, limit=None):
    """Run the sandbox bash for `ch`. `intro(task_text)` is printed first. Returns (exit code, notes).
    With `fight`, the duel is drawn at the top and wrong answers cost hearts (duel.py). With `limit`
    (seconds), Bashou stops the shell when the time is up and the code is TIMEOUT."""
    base = Path(tempfile.mkdtemp(prefix="bashou-arena-"))
    work = base / "arena"
    work.mkdir()
    meta = {"challenge": ch.id, "hints": 0, "help_first": help_first, "shell": player_shell(),
            "platform": which.platform()}
    try:
        meta.update(ch.setup(work, rng or random.Random()))
        challenges.with_editor(meta, state.setting(state.load(), "editor"))
        (base / "meta.json").write_text(json.dumps(meta))
        argv, extra = arena_shell(base, meta["shell"])
        (base / "tip_uniq").write_text(ACCENT + "💡 " + _(                # shown once, on uniq without sort
            "Tip: uniq only merges identical lines that are next to each other. "
            "Sort first: … | sort | uniq -c (or sort -u to keep one of each).") + RESET)
        top = duel.room(base) if fight else 0
        if top:                                            # the rows the arena's prompt empties for the duel
            (base / "height").write_text(f"{top}\n")
        print(intro(ch.task_text(meta)), flush=True)
        env = {**os.environ, "BASHOU_ARENA": str(base),
               "BASHOU_SRC": str(Path(__file__).resolve().parent.parent), "BASHOU_PYTHON": sys.executable}
        env.update(meta.get("env", {}))                   # a fight's own practice folders (GNUPGHOME…)
        env.update(extra)
        env.pop("BASHOU_DUEL", None)
        if top:
            env["BASHOU_DUEL"] = "1"
        env.pop("BASHOU_DEADLINE", None)
        if limit:
            env["BASHOU_DEADLINE"] = str(int(time.time() + limit))
        shell = subprocess.Popen(argv, env=env)
        scene = duel.start(base, shell.pid) if top else None
        try:
            code = shell.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            code = stop_shell(shell)
        finally:
            duel.stop(scene)
        try:
            records = parse_log((base / "log").read_text())
        except FileNotFoundError:
            records = []
    finally:
        if ch.cleanup:
            ch.cleanup(meta)
        shutil.rmtree(base, ignore_errors=True)

    notes = []
    now = datetime.datetime.now()
    with state.locked() as s:
        for status, cmd in records:                        # arena commands count too
            notes += progress.record(s, status, cmd, now.date().isoformat(), now.hour)
    return code, notes


def badger_clue(s):
    """Owner, 2026-10-10: a secret needs something to look for. Fearless (3 wins in 24 hours) brings the
    Honey badger, so a second win within 24 hours leaves a clue, until the badger is yours."""
    if len(achievements.recent_wins(s)) == 2 and BADGER not in s["pets"]:
        return "🐾 " + _("Two wins in a day… something wild is watching you. Will you win a third?")
    return None


def run(ch=None, limit=None, badger=False):
    """`bashou fight`: the threat your pet announced. `bashou arena` passes its own fight and a time
    limit in seconds. Returns the arena's code, or None when there was nothing to fight. `badger`: the
    loader opens the Honey badger's fight; when it's gone (fought already), it says nothing."""
    s = state.load()
    ch = ch or pick(s)
    if not ch and badger:
        return None
    if not ch:
        print(DIM + _("No threat around. Your pet will warn you when one comes.") + RESET)
        return None
    review = s.get("reviews", {}).get(ch.id) if (s.get("threat") or {}).get("review") else None
    with state.locked() as s:                              # meeting a fight opens its lesson
        met = lesson_progress(s)["met"]
        if ch.id not in met:
            met.append(ch.id)
    clock = ("\n" + ACCENT + "⏱ " + _("You have {n} minutes. The time left shows in the prompt.").format(
        n=limit // 60) + RESET) if limit else ""
    code, notes = arena(ch, lambda task: banner(ch, task, review) + clock, fight=True,
                        help_first=beginner(s), limit=limit)
    won = code == WIN
    with state.locked() as s:
        told = after_fight(s, ch, won)
        if not won:
            s["fights_lost"] = s.get("fights_lost", 0) + 1
            if s.get("threat") and s["threat"]["challenge"] == ch.id:
                s["threat"] = None                         # it leaves: no instant retry, it comes back later
            notes += progress.check(s)
        if won:
            s["fights_won"] += 1
            s["win_times"] = achievements.recent_wins(s) + [time.time()]
            clue = badger_clue(s)
            notes += [clue] if clue else []
            if ch.id not in s["challenges"]:
                s["challenges"].append(ch.id)
            if s.get("threat") and s["threat"]["challenge"] == ch.id:
                s["threat"] = None
            notes += progress.unlock(s, ch.pet, _("beat the {threat}").format(threat=_(ch.threat)))
            notes += progress.check(s)
    if won:
        print(f"\n{GOOD}{BOLD}✨ " + _("You beat the {threat}!").format(threat=_(ch.threat)) + RESET)
    elif code == TIMEOUT:
        print(f"\n{BAD}{BOLD}⏱ " + _("Time's up! The {threat} wins this time.").format(threat=_(ch.threat))
              + RESET)
    elif code == KO:
        print(f"\n{BAD}{BOLD}💫 " + _("Knocked out! The {threat} wins this time.").format(threat=_(ch.threat))
              + f"{RESET}\n{DIM}" + _("Only wrong answers cost hearts: try things at the prompt as much as you like before you answer. "
                                       "It'll be back.") + RESET)
    else:
        print(f"\n{DIM}" + _("You fled. The {threat} will be back.").format(threat=_(ch.threat)) + RESET)
    if told:
        print(f"{ACCENT}🔁 {told}{RESET}")
    for note in notes:
        print(f"  {note}")
    print()
    return code


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "run"
    if cmd == "answer":
        sys.exit(cmd_answer(sys.argv[3], sys.argv[2]))
    if cmd == "verify":
        sys.exit(cmd_verify(sys.argv[2]))
    if cmd == "hint":
        sys.exit(cmd_hint(sys.argv[2]))
    if cmd == "task":
        sys.exit(cmd_task(sys.argv[2]))
    if cmd == "check":
        sys.exit(cmd_check(sys.argv[2]))
    if cmd == "lesson":
        sys.exit(cmd_lesson(sys.argv[2]))
    run(badger=cmd == "badger")


if __name__ == "__main__":
    main()
