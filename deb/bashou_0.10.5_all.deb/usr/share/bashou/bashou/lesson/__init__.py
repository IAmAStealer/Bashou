"""`bashou lesson`: the Sage Owl's library (owner, 2026-09-25).

Hints say what to type; a lesson shows how things work, page by page, with a picture (a scheme) that
grows from one page to the next and the owl pointing at the part that matters. Lessons unlock as you
play, each one preparing the next step: the stack and the heap before the C memory fights, and so on.

Lessons are JSON files (see doc/contributing/lessons.md): en/<id>.json holds the lesson, its skill and
what unlocks it; <lang>/<id>.json only translates title, summary and pages (English fills the gaps).
"""

import functools
import json
from pathlib import Path

from .. import i18n, skills

HERE = Path(__file__).resolve().parent
SCHEME_WIDTH = 50               # the owl stands to the right of the scheme: 50 + owl fits 80 columns
SCHEME_LINES = 14
TEXT_LINES = 9
TEXT_WIDTH = 72


def load(lang=None):
    """Every lesson, in order, translated into `lang` where a translation exists."""
    lang = lang or i18n.language()
    found = []
    for path in sorted((HERE / "en").glob("*.json")):
        lesson = json.loads(path.read_text())
        local = HERE / lang / path.name
        if lang != "en" and local.exists():
            lesson.update({k: v for k, v in json.loads(local.read_text()).items()
                           if k in ("title", "summary", "pages")})
        found.append(lesson)
    return sorted(found, key=lambda le: le["order"])


@functools.lru_cache(maxsize=1)
def english():
    """The English lessons, read once: the achievements look at them after every command."""
    return tuple(load("en"))


def progress_of(s):
    """s["lessons"], with every field (a save from an older version may lack some)."""
    p = s.setdefault("lessons", {})
    for key, empty in (("read", []), ("opened", []), ("page", {}), ("met", []), ("right", [])):
        p.setdefault(key, empty)
    return p


def read(s):
    return (s.get("lessons") or {}).get("read", [])


def right(s):
    """Ids of the questions you answered right: in the adventure, a warm-up or a lesson's quiz."""
    return (s.get("lessons") or {}).get("right", [])


def record_right(s, qid):
    p = progress_of(s)
    if qid not in p["right"]:
        p["right"].append(qid)


def answered(s, lesson_id):
    """How many of a lesson's own questions (its "questions") you answered right."""
    return len(set(right(s)) & set(by_id()[lesson_id].get("questions", [])))


def met(s, cond):
    """Is one condition true? "commands N", "tool NAME N", "won ID", "fights N", "achievement ID",
    "answered LESSON N" (N of the lesson's own questions answered right)."""
    kind, *args = cond.split()
    if kind == "commands":
        return s["commands"] >= int(args[0])
    if kind == "tool":
        return s["tools"].get(args[0], 0) >= int(args[1])
    if kind == "won":
        return args[0] in s["challenges"]
    if kind == "fights":
        return s["fights_won"] >= int(args[0])
    if kind == "achievement":
        return args[0] in s["achievements"]
    if kind == "answered":
        return answered(s, args[0]) >= int(args[1])
    raise ValueError(cond)


def holds(s, conds):
    """Every condition of the list holds; an entry "a | b" holds when one of its sides does."""
    return all(any(met(s, c.strip()) for c in cond.split("|")) for cond in conds)


def met_fights(s):
    """Fights you've faced (won, lost or fled) or that wait for you right now."""
    threat = (s.get("threat") or {}).get("challenge")
    return set((s.get("lessons") or {}).get("met", [])) | set(s["challenges"]) | ({threat} if threat else set())


PER_DEPTH = 3       # achievements in all that pass a lesson, per step of depth (owner)


@functools.lru_cache(maxsize=1)
def depths():
    """{id: depth}: the longest path of `after` links from the first lesson (Command line = 1)."""
    after = {le["id"]: le.get("after", []) for le in english()}
    found = {}

    def depth(lid, seen=()):
        if lid not in found:
            if lid in seen:
                raise ValueError(f"lesson loop: {' -> '.join(seen + (lid,))}")
            found[lid] = 1 + max((depth(p, seen + (lid,)) for p in after.get(lid, [])), default=0)
        return found[lid]

    for lid in after:
        depth(lid)
    return found


def by_id():
    return {le["id"]: le for le in english()}


MANY_AFTER = 10     # a lesson that opens this many lessons (all the way down) passes with one good use of its tool


def opens(lesson_id):
    """How many lessons wait for this one, directly or further down the path."""
    after = {le["id"]: le.get("after", []) for le in english()}
    found, todo = set(), [lesson_id]
    while todo:
        lid = todo.pop()
        for child, before in after.items():
            if lid in before and child not in found:
                found.add(child)
                todo.append(child)
    return len(found)


def tool_uses(lesson):
    """How many times a command of the lesson (its "tool" masters) must work (exit status 0) to pass it:
    once when many lessons wait behind it, 3 times otherwise (owner)."""
    return 1 if opens(lesson["id"]) >= MANY_AFTER else 3


def to_pass(lesson):
    """How many achievements in all pass this lesson."""
    return PER_DEPTH * depths().get(lesson["id"], 1)


def own(lesson, kind):
    """The conditions of one kind ("achievement", "tool") among the lesson's masters, as split words."""
    return [c.split() for cond in lesson.get("masters", []) for c in cond.split("|") if c.split()[0] == kind]


def passed(s, lesson):
    """You're through this lesson, and the ones after it may open: one of its fights won, one of the
    achievements it prepares for earned, one of its commands used with success (see tool_uses), enough
    of its questions answered right, or enough achievements in all (3 per step of depth)."""
    earned = s["achievements"]
    return (bool(set(lesson.get("fights", [])) & set(s["challenges"]))
            or any(a in earned for _, a in own(lesson, "achievement"))
            or any(met(s, " ".join(t)) for t in own(lesson, "tool") + own(lesson, "answered"))
            or len(earned) >= to_pass(lesson))


def waiting_for(s, lesson):
    """The lessons of `after` still to pass. One of a skill you don't learn doesn't count."""
    lessons = by_id()
    return [lessons[p] for p in lesson.get("after", [])
            if not passed(s, lessons[p])
            and (not skills_of(lessons[p]) or any(skills.wanted(s, k) for k in skills_of(lessons[p])))]


def first_open(s, lesson):
    """The open lesson to practice first so this one opens: up the `after` chain, the nearest lesson
    that isn't locked itself. None if this one is open."""
    if unlocked(s, lesson):
        return None
    todo, seen = waiting_for(s, lesson), set()
    while todo:
        le = todo.pop(0)
        if le["id"] in seen:
            continue
        seen.add(le["id"])
        if unlocked(s, le):
            return le
        todo += waiting_for(s, le)
    return None


def unlocked(s, lesson):
    """A lesson opens once the lessons before it (`after`) are passed: a real path, cross-theme too
    (Python waits for shell scripts and loops). A fight never waits for its lesson: meeting one of the
    lesson's `fights` opens it too. A lesson you already opened stays open."""
    return (lesson["id"] in (s.get("lessons") or {}).get("opened", [])
            or bool(met_fights(s) & set(lesson.get("fights", []))) or not waiting_for(s, lesson))


def for_fight(lessons, fight_id):
    """The lessons that prepare a fight (its `fights` list), in library order."""
    return [le for le in lessons if fight_id in le.get("fights", [])]


def mastered(s, lesson):
    """You've shown you know it: the fights and achievements it prepares for are done."""
    return bool(lesson.get("masters")) and holds(s, lesson["masters"])


def status(s, lesson):
    """"locked", "next" (open, and it's what makes you progress now) or "mastered"."""
    if not unlocked(s, lesson):
        return "locked"
    return "mastered" if mastered(s, lesson) else "next"


def shown(s, lessons):
    """The lessons of the skills you learn (lessons with no skill are for everyone). A lesson you
    already opened stays, even if you untick its skill later."""
    opened = (s.get("lessons") or {}).get("opened", [])
    return [le for le in lessons if not skills_of(le) or any(skills.wanted(s, k) for k in skills_of(le))
            or le["id"] in opened]


def skills_of(lesson):
    """A lesson's skills: "skill" is one skill or a list (packages: Debian and Rocky alike)."""
    skill = lesson.get("skill")
    return [skill] if isinstance(skill, str) else list(skill or [])


def new(s, lessons=None):
    """Unlocked lessons you haven't opened yet (the pets mention them, `bashou level` too)."""
    lessons = shown(s, lessons if lessons is not None else load("en"))
    opened = (s.get("lessons") or {}).get("opened", [])
    return [le for le in lessons if le["id"] not in opened and unlocked(s, le)]
