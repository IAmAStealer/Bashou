"""Code fights (owner, 2026-09-23): fix a small Python or C file, or finish a small program.

Fix fights: the file starts with a comment saying what goes in, what should come out, how to run it
and where to find help (the fight's lesson). Bashou then runs hidden tests on your version: Python through a
small harness, C built with AddressSanitizer when the compiler has it (leaks and overflows count).
The first level only asks to fix what stops the code from compiling.
"""

import ast
import base64
import functools
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from . import Challenge
from ..i18n import _

PYTHON = ("python3", "python")
COMPILERS = ("gcc", "cc", "clang", "make")
NAMES = ("ada", "bo", "casey", "dara", "eli", "fern", "gil", "hana", "ines", "joss", "kim", "lior",
         "mira", "nils", "omar", "pia", "quinn", "remy", "sana", "tao")
HOSTS = ("web1", "web2", "db1", "db2", "cache", "mail", "proxy", "backup", "auth", "queue")


def header(style, lines):
    lines = lines + [_("When it works, type: verify")]
    if style == "#":
        return "\n".join("# " + line for line in lines) + "\n"
    return "/*\n" + "".join(" * " + line + "\n" for line in lines) + " */\n"


def write(work, name, style, lines, code):
    (work / name).write_text(header(style, lines) + code)


def starter(work, data, steps, code):
    """solve.py, for the fights you win by writing a small program (user, 2026-10-21): it already reads
    `data` and runs; `steps` say what's left to write."""
    lines = [_("A start for you: this program already reads {file}. Run it as it is: python3 solve.py").format(
        file=data)] + steps
    (work / "solve.py").write_text("\n".join("# " + line for line in lines) + "\n\n" + code)


# --- fights won by what your program prints -----------------------------------

def solve_output(work, meta, data, what, change, right):
    """What solve.py prints: "ok", or the reason it isn't right yet. It runs on the real file, then on a copy of
    the folder where `change` put another answer: a program that holds the answer hasn't read the file."""
    if not (work / "solve.py").is_file():
        return _("solve.py is gone: without it, Bashou has no program to run.")
    first = run([sys.executable, "solve.py"], work, timeout=5)
    if first is None:
        return _("Your code didn't finish within 5 seconds: a loop that never ends?")
    if first.returncode != 0:
        return _("Your file doesn't run: python3 {name} shows why.").format(name="solve.py")
    if not first.stdout.strip():
        return _("solve.py prints nothing: a program shows only what you print().")
    if not right(first.stdout.strip(), meta["answer"]):
        return _("solve.py must print {what} and nothing else. Right now it prints: {got}").format(
            what=what(), got=short(first.stdout.strip()))
    changed = _("{file} has changed: solve.py must read the file as it was given.").format(file=data)
    if not (work / data).is_file():                # a pipe would wait for ever, with no time limit
        return changed
    try:
        text, other = change((work / data).read_text(), meta)
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return changed
    with tempfile.TemporaryDirectory() as tmp:
        try:                                     # the whole folder: solve.py may import the player's other files
            shutil.copytree(work, tmp, symlinks=True, dirs_exist_ok=True)      # links stay links: a link to / stays small
        except OSError:                          # something that can't be copied: the rest is there
            pass
        os.chmod(tmp, 0o700)                     # copytree gave it the rights of the player's folder
        try:
            if not (Path(tmp) / "solve.py").exists():      # a folder that can't be listed
                shutil.copy2(work / "solve.py", tmp)
        except OSError:
            return _("solve.py is gone: without it, Bashou has no program to run.")
        (Path(tmp) / data).unlink(missing_ok=True)
        (Path(tmp) / data).write_text(text)
        second = run([sys.executable, "solve.py"], tmp, timeout=5)
    if second is None:
        return _("Your code didn't finish within 5 seconds: a loop that never ends?")
    if second.returncode != 0:
        return _("solve.py is right on your file but crashes on another {file}: {error}").format(
            file=data, error=short((second.stderr.strip().splitlines() or [""])[-1]))
    if not right(second.stdout.strip(), other):
        return _("The answer is right, but solve.py doesn't get it from {file}, or reaches it by a full path: "
                 "a program that holds the answer stops being right as soon as the file changes.").format(file=data)
    return "ok"


def solve_fight(data, what, change, right=lambda out, answer: out == str(answer)):
    """The verify and why of a fight won by solve.py. change(text, meta) gives the file with another answer,
    and that answer; what() names what the program must print."""
    last = {}                                      # a refused verify runs check then why: run the program once

    def told(work, meta):
        last[str(work)] = solve_output(work, meta, data, what, change, right)
        return last[str(work)]

    def why(work):
        reason = last.pop(str(work), None) or told(work, json.loads((Path(work).parent / "meta.json").read_text()))
        return None if reason == "ok" else reason
    return {"verify": lambda work, meta, value: told(work, meta) == "ok", "why": why}


# --- running your code --------------------------------------------------------

HARNESS = r"""
import contextlib, copy, importlib.util, json, sys
path, func, zeros = sys.argv[1], sys.argv[2], sys.argv[3] == "zeros"
cases = json.load(sys.stdin)
spec = importlib.util.spec_from_file_location("fixed", path)
mod = importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(sys.stderr):       # your own prints stay out of the results
    spec.loader.exec_module(mod)
if not callable(getattr(mod, func, None)):
    print(json.dumps({"missing": func}))
    sys.exit(1)
failed = []
for args, want in cases:
    given = copy.deepcopy(args)
    try:
        with contextlib.redirect_stdout(sys.stderr):
            result = getattr(mod, func)(*given)
    except (Exception, SystemExit) as err:
        failed.append({"args": args, "error": f"{type(err).__name__}: {err}"})
        continue
    try:
        got = json.loads(json.dumps(result))
    except (TypeError, ValueError):
        got = None
    if zeros and isinstance(got, dict):
        got = {k: v for k, v in got.items() if v != 0}
    if got != want or given != args:
        failed.append({"args": args, "want": want, "got": repr(result), "changed": given != args})
if failed:
    print(json.dumps(min(failed, key=lambda f: len(json.dumps(f)))))
    sys.exit(1)
print("ok")
"""


def run(cmd, cwd, stdin="", timeout=10, env=None):
    try:
        return subprocess.run(cmd, cwd=cwd, input=stdin, capture_output=True, text=True, errors="replace",
                              timeout=timeout, env=env)
    except (subprocess.TimeoutExpired, OSError):
        return None


def py_test_run(work, meta, name, func, zeros):
    """Run the hidden tests: "ok", the smallest failing case (a dict), or None when nothing came back."""
    r = run([sys.executable, "-c", HARNESS, str(work / name), func, "zeros" if zeros else "-"], work,
            json.dumps(meta["cases"]), 5)
    if r is None:
        return None
    if r.returncode == 0 and r.stdout.strip() == "ok":
        return "ok"
    try:
        return json.loads(r.stdout)
    except ValueError:
        return {"broken": True}


def py_tests(name, func, zeros=False):
    """verify(): call `func` from your file on the cases in meta["cases"] ([args, expected]).
    `zeros`: a dict of counts may also list what it counted 0 times."""
    def verify(work, meta, value):
        return py_test_run(work, meta, name, func, zeros) == "ok"
    return verify


def short(value, width=160):
    text = value if isinstance(value, str) else repr(value)
    return text if len(text) <= width else text[:width - 1] + "…"


def py_why(name, func, zeros=False):
    """why(): one hidden test your code fails, shown as a call, what it should give and what it gives
    (bug report: a right-looking output was refused with no example to compare)."""
    def why(work):
        meta = json.loads((Path(work).parent / "meta.json").read_text())
        fail = py_test_run(work, meta, name, func, zeros)
        if fail == "ok":
            return None
        if fail is None:
            return _("Your code didn't finish within 5 seconds: a loop that never ends?")
        if "missing" in fail:
            return _("{name} has no function {func}() any more: did you rename it?").format(name=name, func=func)
        if fail.get("broken"):
            return _("Your file doesn't run: python3 {name} shows why.").format(name=name)
        call = short(f"{func}({', '.join(repr(a) for a in fail['args'])})", 400)   # the input, in full if it can
        if "error" in fail:
            return _("One test fails: {call} raises {error}.").format(call=call, error=fail["error"])
        if fail["changed"]:
            return _("One test fails: {call} changes what it was given.").format(call=call)
        return _("One test fails: {call} should give {want}, yours gives {got}.").format(
            call=call, want=short(fail["want"]), got=short(fail["got"]))   # got: repr of what you returned
    return why


def py_output(name):
    """verify(): run your script, compare what it prints with meta["expected"]."""
    def verify(work, meta, value):
        r = run([sys.executable, name], work, timeout=5)
        return bool(r) and r.returncode == 0 and r.stdout == meta["expected"]
    return verify


PROBES = 10    # runs of a sanitized program before trusting it (one hang in 3 would pass 5 runs 17% of the time)


@functools.lru_cache(maxsize=None)
def sanitized():
    """(the -fsanitize flags this gcc can build and run, how to start the program), or ([], []).

    AddressSanitizer in gcc 12 (Debian 12) hangs at start about 1 time in 3 on kernels that randomize
    addresses more (WSL, recent kernels): a correct fix was then refused. Without address randomization
    (`setarch -R`) it can't hang. Where that isn't allowed (containers), and the program still hangs,
    C is built without sanitizers, and the fights that need them aren't offered."""
    with tempfile.TemporaryDirectory() as tmp:
        (Path(tmp) / "t.c").write_text("int main(void) { return 0; }\n")
        flags = ["-fsanitize=address,undefined"]
        r = run(["gcc", *flags, "t.c", "-o", "t"], tmp)
        if not r or r.returncode != 0:
            return [], []
        launchers = [["setarch", os.uname().machine, "-R"]] if shutil.which("setarch") else []
        for launcher in launchers + [[]]:
            runs = [run([*launcher, "./t"], tmp, timeout=3) for _ in range(PROBES)]
            if all(r and r.returncode == 0 for r in runs):
                return flags, launcher
        return [], []


@functools.lru_cache(maxsize=None)
def leaks():
    """True when AddressSanitizer here also finds memory leaks. Apple's clang (gcc on macOS) has no leak
    detector, and asking for one (detect_leaks=1) stops every program."""
    flags, launcher = sanitized()
    if not flags:
        return False
    with tempfile.TemporaryDirectory() as tmp:
        (Path(tmp) / "t.c").write_text("int main(void) { return 0; }\n")
        built = run(["gcc", *flags, "t.c", "-o", "t"], tmp)
        r = built and built.returncode == 0 and run([*launcher, "./t"], tmp, timeout=3,
                                                    env={**os.environ, "ASAN_OPTIONS": "detect_leaks=1"})
        return bool(r) and r.returncode == 0


def sanitizer():
    """The -fsanitize flags this gcc can build and run, or [] (no AddressSanitizer here)."""
    return sanitized()[0]


def c_tests(name):
    """verify(): build your file, run it on meta["runs"] ([args, stdin, expected stdout])."""
    def verify(work, meta, value):
        with tempfile.TemporaryDirectory() as tmp:
            flags, launcher = sanitized()
            built = run(["gcc", "-g", *flags, str(work / name), "-o", "prog"], tmp)
            if not built or built.returncode != 0:
                return False
            env = {**os.environ, "UBSAN_OPTIONS": "halt_on_error=1",
                   **({"ASAN_OPTIONS": "detect_leaks=1"} if leaks() else {})}
            for args, stdin, expected in meta["runs"]:
                r = run([*launcher, "./prog", *args], tmp, stdin, env=env)
                if not r or r.returncode != 0 or r.stdout != expected:
                    return False
        return True
    return verify


PROGRAMS = {"hello", "shout", "average", "sum", "greet"}     # what the C fights build (./hello is "hello")


def c_used(analysis):
    """Building counts, and so does running your program."""
    return bool(analysis.tools & (set(COMPILERS) | PROGRAMS))


# --- level 1: make it compile -------------------------------------------------

def colon_setup(work, rng):
    names = rng.sample(NAMES, 3)
    write(work, "greet.py", "#", [
        _("Fight: this script doesn't even start. Python says why, with the line number."),
        _("Input: the names in the list below."),
        _("Wanted: one line per name, like: hello ada"),
        _("Run it:") + " python3 greet.py",
        _("Help: type lesson in the arena, the Sage Owl explains it with a drawing."),
    ], "\n\ndef greet(names)\n    for name in names:\n        print(\"hello\", name)\n\n\n"
       f"greet({names!r})\n")
    return {"expected": "".join(f"hello {n}\n" for n in names)}


def semicolon_setup(work, rng):
    name = rng.choice(NAMES)
    write(work, "hello.c", "c", [
        _("Fight: gcc refuses to build this. Read its first error: file:line: what is missing."),
        _("Input: nothing."),
        _("Wanted: it prints one line, like: hello, ada"),
        _("Run it:") + " gcc hello.c -o hello && ./hello",
        _("Help: gcc's message names the line and the column where the ; is missing."),
    ], "\n#include <stdio.h>\n\nint main(void)\n{\n"
       f"    printf(\"hello, {name}\\n\")\n    return 0;\n}}\n")
    return {"runs": [[[], "", f"hello, {name}\n"]]}


# --- level 2: Python data and loops -------------------------------------------

LIST_CODE = '''

def unique(hosts):
    for i, host in enumerate(hosts):
        if host in hosts[:i]:
            hosts.remove(host)
    return hosts


if __name__ == "__main__":
    print(unique({demo!r}))
'''


def list_setup(work, rng):
    demo = [rng.choice(HOSTS[:4]) for _i in range(7)]
    write(work, "hosts.py", "#", [
        _("Fight: unique() should keep each host once, in the order they first appear."),
        _("Input: a list of host names, some repeated."),
        _("Wanted: a new list, each name once, first-seen order. Don't change the list you were given."),
        _("Run it:") + " python3 hosts.py",
        _("Help: type lesson in the arena, the Sage Owl explains it with a drawing."),
    ], LIST_CODE.format(demo=demo))
    cases = []
    for _i in range(8):
        xs = [rng.choice(HOSTS) for _i in range(rng.randint(0, 12))]
        cases.append([[xs], list(dict.fromkeys(xs))])
    return {"cases": cases}


DICT_CODE = '''

def count_levels(lines):
    counts = {}
    for line in lines:
        level = line.split()[1]
        counts[level] += 1
    return counts


if __name__ == "__main__":
    with open("app.log", encoding="utf-8") as fh:
        print(count_levels(fh))
'''

LEVELS = ("INFO", "WARN", "ERROR", "DEBUG")


def log_lines(rng, n):
    return [f"12:{rng.randint(0, 59):02d} {rng.choice(LEVELS)} {rng.choice(('login', 'retry', 'timeout', 'saved'))}"
            for _i in range(n)]


def dict_setup(work, rng):
    lines = log_lines(rng, rng.randint(20, 40))
    (work / "app.log").write_text("\n".join(lines) + "\n")
    write(work, "tally.py", "#", [
        _("Fight: count_levels() should count how many lines have each level."),
        _("Input: log lines like '12:04 ERROR timeout' (the level is the second word)."),
        _("Wanted: a dict like {'INFO': 12, 'ERROR': 3}."),
        _("Run it:") + " python3 tally.py",
        _("Help: type lesson in the arena, the Sage Owl explains it with a drawing."),
    ], DICT_CODE)
    cases = []
    for _i in range(6):
        ls = log_lines(rng, rng.randint(0, 15))
        want = {}
        for line in ls:
            want[line.split()[1]] = want.get(line.split()[1], 0) + 1
        cases.append([[ls], want])
    return {"cases": cases, "args": {"level": lines[0].split()[1]}}


EEL_CODE = '''import sys


def count_lines(path):
    with open(path, encoding="utf-8") as fh:
        return len(fh.readlines())


if __name__ == "__main__":
    try:
        print(count_lines(sys.argv[1]))
    except:
        print(0)
'''


def eel_setup(work, rng):
    write(work, "count.py", "#", [
        _("Fight: count.py counts the lines of a file. Given a file that isn't there, it prints 0 and says it worked."),
        _("Wanted: the count for a real file; for a missing one, a message on stderr and exit status 1."),
        _("And no bare except: name the error you expect."),
        _("Run it:") + " python3 count.py notes.txt; echo $?   " + _("then:") + " python3 count.py nope.txt; echo $?",
        _("Help: type lesson in the arena, the Sage Owl explains it with a drawing."),
    ], EEL_CODE)
    n = rng.randint(3, 9)
    (work / "notes.txt").write_text("".join(f"note {i}\n" for i in range(1, n + 1)), encoding="utf-8")
    return {"lines": n}


def eel_wrong(work, meta):
    """What's still wrong with count.py, or None. No bare except left. A real file: its count, status 0. A missing
    one: nothing on stdout, a message on stderr, status 1 (a script that fails must say so to cron or CI)."""
    try:
        tree = ast.parse((work / "count.py").read_text(encoding="utf-8"))
    except (OSError, SyntaxError, ValueError):
        return _("Your file doesn't run: python3 {name} shows why.").format(name="count.py")
    handlers = [h for h in ast.walk(tree) if isinstance(h, ast.ExceptHandler)]
    if any(h.type is None for h in handlers):           # the bare except is what the fight is about
        return _("The bare except: is still in count.py. Your script may look right, but it would also hide a typo "
                 "or Ctrl+C: name the error you expect, like except OSError as err:")
    if any(getattr(h.type, "id", "") == "BaseException" for h in handlers):
        return _("except BaseException: catches as much as a bare except, even Ctrl+C: "
                 "name the error you expect, like except OSError as err:")
    with tempfile.TemporaryDirectory() as tmp:
        shutil.copy(work / "count.py", tmp)
        n = meta["lines"] + 2
        (Path(tmp) / "list.txt").write_text("x\n" * n, encoding="utf-8")
        good = run([sys.executable, "count.py", "list.txt"], tmp, timeout=5)
        bad = run([sys.executable, "count.py", "missing.txt"], tmp, timeout=5)
    if not good or not bad:
        return _("Your code didn't finish within 5 seconds: a loop that never ends?")
    if good.returncode != 0 or good.stdout != f"{n}\n":
        return _("With a real file, count.py should print only the count and end with status 0: "
                 "python3 count.py notes.txt; echo $?")
    if bad.stdout != "":
        return _("With a missing file, nothing should go to stdout: the message goes to stderr.")
    if bad.returncode != 1:
        return _("With a missing file, the exit status should be 1: python3 count.py nope.txt; echo $?")
    if bad.stderr.strip() == "":
        return _("With a missing file, say what went wrong on stderr: print(err, file=sys.stderr)")
    return None


def eel_verify(work, meta, value):
    return eel_wrong(work, meta) is None


def eel_why(work):
    return eel_wrong(work, json.loads((Path(work).parent / "meta.json").read_text()))


LOOP_CODE = '''

def delays(tries):
    waits = []
    delay = 1
    i = 0
    while i < tries:
        waits.append(delay)
        delay = delay * 2
    return waits


if __name__ == "__main__":
    print(delays({n}))
'''


def loop_setup(work, rng):
    write(work, "retry.py", "#", [
        _("Fight: delays() should give the wait before each retry, doubling each time."),
        _("Input: how many tries, like 4."),
        _("Wanted: [1, 2, 4, 8] for 4 tries, [] for 0."),
        _("Run it:") + " python3 retry.py   (Ctrl+C stops it if it hangs)",
        _("Help: type lesson in the arena, the Sage Owl explains it with a drawing."),
    ], LOOP_CODE.format(n=rng.randint(3, 6)))
    return {"cases": [[[n], [2 ** i for i in range(n)]] for n in (0, 1, 4, rng.randint(5, 12))]}


TREE_CODE = '''

def total(tree):
    size = 0
    for name, item in tree.items():
        if isinstance(item, dict):
            total(item)
        else:
            size += item
    return size


if __name__ == "__main__":
    import json
    with open("tree.json", encoding="utf-8") as fh:
        print(total(json.load(fh)))
'''


def tree(rng, depth):
    t = {}
    for i in range(rng.randint(1, 4)):
        if depth and rng.random() < 0.5:
            t[f"dir{i}"] = tree(rng, depth - 1)
        else:
            t[f"file{i}.txt"] = rng.randint(1, 900)
    return t


def size(t):
    return sum(size(v) if isinstance(v, dict) else v for v in t.values())


def tree_setup(work, rng):
    demo = {"notes.txt": rng.randint(10, 99), "photos": tree(rng, 2), "src": tree(rng, 2)}
    (work / "tree.json").write_text(json.dumps(demo, indent=2) + "\n")
    write(work, "du.py", "#", [
        _("Fight: total() should add up every file of a folder tree, subfolders included."),
        _("Input: folders are dicts, files are sizes: {'a.txt': 10, 'src': {'b.c': 5}}."),
        _("Wanted: the sum of every size, at every depth (15 above)."),
        _("Run it:") + " python3 du.py",
        _("Help: type lesson in the arena, the Sage Owl explains it with a drawing."),
    ], TREE_CODE)
    cases = [[[t], size(t)] for t in (tree(rng, 3) for _i in range(6))]
    return {"cases": cases + [[[demo], size(demo)]]}


# --- level 2: small programs on a data file -------------------------------------

def json_setup(work, rng):
    ports = rng.sample(range(1024, 9999), 4)
    config = {"app": {"name": "shop", "port": ports[0]},
              "cache": {"host": "cache.internal", "port": ports[1]},
              "database": {"host": "db.internal", "port": ports[2], "user": rng.choice(NAMES)},
              "metrics": {"enabled": True, "port": ports[3]}}
    (work / "config.json").write_text(json.dumps(config, indent=2) + "\n")
    starter(work, "config.json", [
        _("json.load turns the file into dicts: sections inside sections, like in the file."),
        _("Your step: it prints the names at the top. Go down one level at a time, config[\"database\"] "
          "first, until you print the port."),
    ], 'import json\n\nwith open("config.json", encoding="utf-8") as f:\n    config = json.load(f)\n\nprint(config.keys())\n')
    return {"answer": ports[2]}


def json_change(text, meta):
    config = json.loads(text)
    config["database"]["port"] = meta["answer"] + 1
    return json.dumps(config, indent=2) + "\n", meta["answer"] + 1


def b64_setup(work, rng):
    word = rng.choice(("lantern", "harbor", "pebble", "thistle", "compass", "ember", "orchid", "falcon"))
    (work / "secret.txt").write_text(base64.b64encode(word.encode()).decode() + "\n")
    starter(work, "secret.txt", [
        _("Your step: it prints the text still encoded. base64.b64decode(text) undoes base64 and gives "
          "bytes; .decode() turns those bytes into text you can read."),
    ], 'import base64\n\nwith open("secret.txt", encoding="utf-8") as fh:\n    text = fh.read()\nprint(text)\n')
    return {"answer": word}


def b64_change(text, meta):
    return base64.b64encode(b"quartz").decode() + "\n", "quartz"


def url_right(out, answer):
    """shadow, /etc/shadow or etc/shadow."""
    return out in (answer, f"etc/{answer}", f"/etc/{answer}")


def percent(text):
    return "".join(f"%{b:02x}" for b in text.encode())


def url_change(text, meta):
    if percent(f"etc/{meta['answer']}") not in text:
        raise ValueError
    return text.replace(percent(f"etc/{meta['answer']}"), percent("etc/group")), "group"


def url_setup(work, rng):
    target = rng.choice(("passwd", "shadow", "sudoers", "hosts", "crontab", "fstab"))
    ips = [f"10.1.{rng.randint(0, 9)}.{rng.randint(1, 254)}" for _i in range(8)]
    queries = ("red%20shoes", "caf%C3%A9", "50%25%20off", "a%2Bb", "size%3D42")
    lines = [f"{rng.choice(ips)} GET /search?q={rng.choice(queries)} 200" for _i in range(rng.randint(30, 50))]
    attack = percent(f"../../../etc/{target}")
    lines.insert(rng.randint(5, len(lines) - 5), f"{rng.choice(ips)} GET /download?file={attack} 200")
    (work / "access.log").write_text("\n".join(lines) + "\n")
    starter(work, "access.log", [
        _("Your step: it prints each line as it is, %XX codes and all. urllib.parse.unquote(line) turns "
          "them back into characters. Then print only the file named after /etc/ on the line that has it."),
    ], 'import urllib.parse\n\nwith open("access.log", encoding="utf-8") as fh:\n    for line in fh:\n        print(line, end="")\n')
    return {"answer": target}


# --- level 3 ------------------------------------------------------------------

INJECT_CODE = '''
import os


def main():
    with open("hosts.txt", encoding="utf-8") as fh:
        for host in fh.read().split("\\n"):
            if host:
                os.system("echo checking " + host)


if __name__ == "__main__":
    main()
'''

EVIL = ("; touch pwned", "$(touch pwned)", "`touch pwned`", " && touch pwned", " | touch pwned")


def inject_setup(work, rng):
    hosts = rng.sample(HOSTS, 3) + [rng.choice(HOSTS) + rng.choice(EVIL)]
    (work / "hosts.txt").write_text("\n".join(hosts) + "\n")
    write(work, "check_hosts.py", "#", [
        _("Fight: hosts.txt comes from a web form. One line hides a command, and this script runs it."),
        _("Input: hosts.txt, one host per line."),
        _("Wanted: 'checking <line>' for each line, exactly as written, and nothing else run."),
        _("Run it:") + " python3 check_hosts.py   (then ls: a new file means the attack worked)",
        _("Help: type lesson in the arena, the Sage Owl explains it with a drawing."),
    ], INJECT_CODE)
    return {}


def inject_verify(work, meta, value):
    with tempfile.TemporaryDirectory() as tmp:
        shutil.copy(work / "check_hosts.py", tmp)
        hosts = list(HOSTS[:2]) + [h + e for h, e in zip(HOSTS[2:], EVIL)] + ["-n", "$HOME"]
        Path(tmp, "hosts.txt").write_text("\n".join(hosts) + "\n")
        r = run([sys.executable, "check_hosts.py"], tmp, timeout=10)
        clean = sorted(os.listdir(tmp)) == ["check_hosts.py", "hosts.txt"]
        return bool(r) and r.returncode == 0 and clean and r.stdout == "".join(f"checking {h}\n" for h in hosts)


def b64url(data):
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def jwt_setup(work, rng):
    user = rng.choice(NAMES) + rng.choice(("", "_ops", "-admin", "42"))
    head = b64url(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    body = b64url(json.dumps({"sub": user, "role": rng.choice(("admin", "viewer", "deploy")),
                              "exp": rng.randint(1_790_000_000, 1_800_000_000)}).encode())
    sig = b64url(bytes(rng.randrange(256) for _i in range(32)))
    (work / "token.txt").write_text(f"{head}.{body}.{sig}\n")
    starter(work, "token.txt", [
        _("It already splits the token at its dots: header, payload, signature."),
        _("Your step: decode the payload. It's base64url without its = padding: "
          "base64.urlsafe_b64decode(payload + \"==\") gives it enough padding (Python ignores any extra) and "
          "decodes it to JSON. json.loads reads that JSON: print only its \"sub\"."),
    ], 'import base64\nimport json\n\nwith open("token.txt", encoding="utf-8") as fh:\n    token = fh.read().strip()\n'
       'header, payload, signature = token.split(".")\nprint(payload)\n')
    return {"answer": user}


def jwt_change(text, meta):
    head, body, sig = text.strip().split(".")
    claims = json.loads(base64.urlsafe_b64decode(body + "=="))
    claims["sub"] = meta["answer"] + "2"
    return f"{head}.{b64url(json.dumps(claims).encode())}.{sig}\n", claims["sub"]


# --- C ------------------------------------------------------------------------

LEAK_CODE = r'''
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char *shout(const char *line)
{
    size_t len = strlen(line);
    char *loud = malloc(len + 1);
    if (!loud)
        return NULL;
    for (size_t i = 0; i < len; i++)
        loud[i] = toupper((unsigned char)line[i]);
    loud[len] = '\0';
    return loud;
}

int main(void)
{
    char line[256];
    while (fgets(line, sizeof line, stdin)) {
        char *loud = shout(line);
        if (!loud) {
            perror("malloc");
            return EXIT_FAILURE;
        }
        fputs(loud, stdout);
    }
    return 0;
}
'''


def leak_setup(work, rng):
    names = rng.sample(NAMES, 5)
    (work / "names.txt").write_text("\n".join(names) + "\n")
    write(work, "shout.c", "c", [
        _("Fight: the output is right, but memory leaks: AddressSanitizer reports it at the end."),
        _("Input: lines on stdin (names.txt)."),
        _("Wanted: each line in capitals, and every malloc freed."),
        _("Run it:") + " gcc -Wall -g -fsanitize=address,undefined shout.c -o shout && ./shout < names.txt",
        _("Help: type lesson in the arena, the Sage Owl explains it with a drawing."),
    ], LEAK_CODE)
    runs = []
    for _i in range(3):
        text = "".join(n + "\n" for n in rng.sample(NAMES, rng.randint(1, 8)))
        runs.append([[], text, text.upper()])
    return {"runs": runs}


FENCE_CODE = r'''
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    int count = argc - 1;
    if (count == 0) {
        fprintf(stderr, "usage: ./average N...\n");
        return 1;
    }
    int *values = malloc(count * sizeof *values);
    if (!values) {
        perror("malloc");
        return EXIT_FAILURE;
    }
    for (int i = 0; i < count; i++)
        values[i] = atoi(argv[i + 1]);
    long total = 0;
    for (int i = 0; i <= count; i++)
        total += values[i];
    printf("%ld\n", total / count);
    free(values);
    return 0;
}
'''


def fence_setup(work, rng):
    nums = [rng.randint(1, 99) for _i in range(4)]
    write(work, "average.c", "c", [
        _("Fight: the average is wrong, or AddressSanitizer stops it: a loop reads one box too far."),
        _("Input: whole numbers >= 0 as arguments."),
        _("Wanted: their average, rounded down: ./average 2 4 9 prints 5."),
        _("Run it:") + " gcc -Wall -g -fsanitize=address,undefined average.c -o average && ./average " + " ".join(map(str, nums)),
        _("Help: type lesson in the arena, the Sage Owl explains it with a drawing."),
    ], FENCE_CODE)
    runs = []
    for _i in range(4):
        xs = [rng.randint(0, 999) for _i in range(rng.randint(1, 9))]
        runs.append([[str(x) for x in xs], "", f"{sum(xs) // len(xs)}\n"])
    return {"runs": runs}


STACK_CODE = r'''
#include <stdio.h>
#include <stdlib.h>

static long sum_to(long n)
{
    return n + sum_to(n - 1);
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "usage: ./sum N\n");
        return 1;
    }
    printf("%ld\n", sum_to(atol(argv[1])));
    return 0;
}
'''


def stack_setup(work, rng):
    write(work, "sum.c", "c", [
        _("Fight: sum_to() calls itself forever, until the stack overflows (segfault)."),
        _("Input: a number N >= 0."),
        _("Wanted: 1 + 2 + ... + N: ./sum 4 prints 10, ./sum 0 prints 0."),
        _("Run it:") + " gcc -Wall -g sum.c -o sum && ./sum 4",
        _("Help: type lesson in the arena, the Sage Owl explains it with a drawing."),
    ], STACK_CODE)
    return {"runs": [[[str(n)], "", f"{n * (n + 1) // 2}\n"] for n in (0, 1, 4, rng.randint(50, 2000))]}


OVERFLOW_CODE = r'''
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{
    char name[8];
    if (argc != 2) {
        fprintf(stderr, "usage: ./greet NAME\n");
        return 1;
    }
    strcpy(name, argv[1]);
    printf("Hello, %s!\n", name);
    return 0;
}
'''


def overflow_setup(work, rng):
    write(work, "greet.c", "c", [
        _("Fight: a long name writes past the 8-byte buffer. In real code that is how attackers get in."),
        _("Input: a name as the only argument, of any length."),
        _("Wanted: Hello, <the whole name>! for any name, with no memory error."),
        _("Run it:") + " gcc -Wall -g -fsanitize=address,undefined greet.c -o greet && ./greet averyveryverylongname",
        _("Help: type lesson in the arena, the Sage Owl explains it with a drawing."),
    ], OVERFLOW_CODE)
    long = "".join(rng.choice("abcdefghij") for _i in range(rng.randint(300, 2000)))
    return {"runs": [[[n], "", f"Hello, {n}!\n"] for n in (rng.choice(NAMES), "averyveryverylongname", long)]}


# --- the fights -----------------------------------------------------------------

PY = dict(tools=PYTHON, requires=["python3"], skill="python")
C = dict(tools=COMPILERS, uses=c_used, requires=["gcc"], skill="c")

ALL = [
    Challenge(level=1, id="colon_cobra", fix=True, pet="snake", threat="Colon Cobra", **PY,
              task="The Colon Cobra swallowed a character in greet.py: Python stops at a SyntaxError.\n"
                   "Fix greet.py (its first lines say what it must do). Run it: python3 greet.py\n"
                   "When it works, type: verify",
              hints=["Read the error from the bottom: the last line names the problem, the lines above "
                     "point at where. A def or a for line ends with something.",
                     "Add the missing : at the end of the def line, then run python3 greet.py."],
              setup=colon_setup, verify=py_output("greet.py")),
    Challenge(level=1, id="semicolon_slug", fix=True, pet="beaver", threat="Semicolon Slug", **C,
              task="The Semicolon Slug ate a character in hello.c: gcc refuses to build it.\n"
                   "Fix hello.c (its first lines say what it must do). Run it: gcc hello.c -o hello && ./hello\n"
                   "When it works, type: verify",
              hints=["gcc prints file:line:column: error. In C every statement ends with the same character.",
                     "Add the missing ; after the printf(...) line, then build and run again."],
              setup=semicolon_setup, verify=c_tests("hello.c")),
    Challenge(level=2, id="list_leech", fix=True, pet="snake", threat="List Leech", **PY,
              task="The List Leech clings to hosts.py: unique() leaves duplicates and changes its input.\n"
                   "Fix hosts.py (its first lines say what it must do). Run it: python3 hosts.py\n"
                   "When it works, type: verify",
              hints=["Removing items from a list while a for loop walks over it makes the loop skip some. "
                     "Build a new list instead.",
                     "Try: seen = [] then for host in hosts: if host not in seen: seen.append(host), "
                     "and return seen."],
              setup=list_setup, verify=py_tests("hosts.py", "unique"), why=py_why("hosts.py", "unique")),
    Challenge(level=2, id="dict_djinn", fix=True, pet="snake", threat="Dict Djinn", **PY,
              task="The Dict Djinn hid a key: tally.py crashes with KeyError: '{level}'.\n"
                   "Fix tally.py (its first lines say what it must do). Run it: python3 tally.py\n"
                   "When it works, type: verify",
              hints=["counts[level] += 1 reads counts[level] first, and the first time it isn't there.",
                     "Try: counts[level] = counts.get(level, 0) + 1"],
              setup=dict_setup, verify=py_tests("tally.py", "count_levels", zeros=True),
              why=py_why("tally.py", "count_levels", zeros=True)),
    Challenge(level=2, id="except_eel", fix=True, pet="snake", threat="Except Eel", **PY,
              task="The Except Eel slipped a bare except into count.py: a missing file prints 0, and the script "
                   "says it worked.\nFix count.py (its first lines say what it must do). Run it: python3 count.py "
                   "nope.txt; echo $?\nWhen it works, type: verify",
              hints=["A bare except: catches every error, even typos and Ctrl+C, and here turns a failure into a "
                     "fake 0 with status 0: cron would never know. Catch only the error you expect, say what "
                     "went wrong on stderr, and end with status 1.",
                     "Write: except OSError as err: (OSError covers a missing file, a forbidden one and a folder), "
                     "then print(err, file=sys.stderr) and sys.exit(1)."],
              setup=eel_setup, verify=eel_verify, why=eel_why),
    Challenge(level=2, id="loop_lich", fix=True, pet="snake", threat="Loop Lich", **PY,
              task="The Loop Lich traps retry.py in a loop that never ends.\n"
                   "Fix retry.py (its first lines say what it must do). Run it: python3 retry.py\n"
                   "When it works, type: verify",
              hints=["A while loop stops when its condition turns false. What in the loop changes i?",
                     "Add i += 1 inside the loop (or write: for i in range(tries):)."],
              setup=loop_setup, verify=py_tests("retry.py", "delays"), why=py_why("retry.py", "delays")),
    Challenge(level=2, id="ouroboros", fix=True, pet="snake", threat="Ouroboros", **PY,
              task="The Ouroboros bites its own tail: du.py forgets the files in subfolders.\n"
                   "Fix du.py (its first lines say what it must do). Run it: python3 du.py\n"
                   "When it works, type: verify",
              hints=["total(item) is called for each subfolder, but where does its result go?",
                     "Write: size += total(item)"],
              setup=tree_setup, verify=py_tests("du.py", "total"), why=py_why("du.py", "total")),
    Challenge(level=2, id="json_jinn", fix=True, pet="snake", threat="JSON Jinn", **PY,
              task="The JSON Jinn guards config.json. Read it with python3, not by eye.\n"
                   "Which port does the database use? Finish solve.py so that it prints that port and nothing else.\n"
                   "Run it: python3 solve.py\n"
                   "When it works, type: verify",
              hints=["json.load turns the file into dicts: config[\"database\"] is one section, and it holds a port.",
                     "Change the last line of solve.py to: print(config[\"database\"][\"port\"])"],
              setup=json_setup, **solve_fight("config.json", lambda: _("the database port"), json_change)),
    Challenge(level=2, id="base64_banshee", fix=True, pet="snake", threat="Base64 Banshee", **PY,
              task="The Base64 Banshee wails in secret.txt: it's base64, not a secret code.\n"
                   "What is the vault word? Finish solve.py so that it prints that word and nothing else.\n"
                   "Run it: python3 solve.py\n"
                   "When it works, type: verify",
              hints=["base64 is an encoding, anyone can undo it.",
                     "Change the last line of solve.py to: print(base64.b64decode(text).decode())"],
              setup=b64_setup, **solve_fight("secret.txt", lambda: _("the vault word"), b64_change)),
    Challenge(level=2, id="percent_poltergeist", fix=True, pet="snake", threat="Percent Poltergeist", **PY,
              task="The Percent Poltergeist hides an attack in access.log behind %XX codes.\n"
                   "Which file under /etc was the attacker after? "
                   "Finish solve.py so that it prints that file's name and nothing else.\n"
                   "Run it: python3 solve.py\n"
                   "When it works, type: verify",
              hints=["urllib.parse.unquote turns the %XX codes back into characters: %2e%2e%2f becomes ../",
                     "Instead of printing each line: line = urllib.parse.unquote(line), then if \"/etc/\" is in it, "
                     "print(line.split(\"/etc/\")[1].split()[0])"],
              setup=url_setup, **solve_fight("access.log", lambda: _("the name of the file under /etc"), url_change,
                                             url_right)),
    Challenge(level=3, id="injection_imp", fix=True, pet="snake", threat="Injection Imp", after=("list_leech",), **PY,
              task="The Injection Imp slipped a command into hosts.txt, and check_hosts.py runs it.\n"
                   "Fix check_hosts.py (its first lines say what it must do). Run it: python3 check_hosts.py\n"
                   "When it works, type: verify",
              hints=["os.system hands the whole string to a shell, so ; $( ) | in the data become commands.",
                     "Try: subprocess.run(['echo', 'checking', host], check=True) (import subprocess), or just print."],
              setup=inject_setup, verify=inject_verify),
    Challenge(level=3, id="token_trickster", fix=True, pet="snake", threat="Token Trickster",
              after=("base64_banshee",), **PY,
              task="The Token Trickster flashes a JWT in token.txt. Signed is not secret: read it.\n"
                   "Which user (sub) is the token for? Finish solve.py so that it prints that user and nothing else.\n"
                   "Run it: python3 solve.py\n"
                   "When it works, type: verify",
              hints=["A JWT is header.payload.signature, each part base64url without padding.",
                     "Change the last line of solve.py to: "
                     "print(json.loads(base64.urlsafe_b64decode(payload + \"==\"))[\"sub\"])"],
              setup=jwt_setup, **solve_fight("token.txt", lambda: _("the token's user"), jwt_change)),
    Challenge(level=2, id="leak_lurker", fix=True, works=lambda: bool(sanitizer()) and leaks(), pet="beaver", threat="Leak Lurker", **C,
              task="The Leak Lurker feeds on memory nobody frees in shout.c.\n"
                   "Fix shout.c (its first lines say what it must do). "
                   "Run it: gcc -Wall -g -fsanitize=address,undefined shout.c -o shout && ./shout < names.txt\n"
                   "When it works, type: verify",
              hints=["AddressSanitizer names the line where the leaked memory was allocated. "
                     "Who should free it once it's printed?",
                     "Add free(loud); right after fputs(loud, stdout);"],
              setup=leak_setup, verify=c_tests("shout.c")),
    Challenge(level=2, id="fencepost_fiend", fix=True, works=lambda: bool(sanitizer()), pet="beaver", threat="Fencepost Fiend", **C,
              task="The Fencepost Fiend moved a fence post in average.c: a loop goes one step too far.\n"
                   "Fix average.c (its first lines say what it must do). "
                   "Run it: gcc -Wall -g -fsanitize=address,undefined average.c -o average && ./average 2 4 9\n"
                   "When it works, type: verify",
              hints=["An array of count items goes from 0 to count - 1. Compare the two loops.",
                     "In the second loop, write i < count instead of i <= count."],
              setup=fence_setup, verify=c_tests("average.c")),
    Challenge(level=2, id="stack_specter", fix=True, pet="beaver", threat="Stack Specter", **C,
              task="The Stack Specter haunts sum.c: sum_to() never stops calling itself.\n"
                   "Fix sum.c (its first lines say what it must do). Run it: gcc -Wall -g sum.c -o sum && ./sum 4\n"
                   "When it works, type: verify",
              hints=["Every recursion needs a case that returns without calling itself.",
                     "Add at the start of sum_to: if (n <= 0) return 0;"],
              setup=stack_setup, verify=c_tests("sum.c")),
    Challenge(level=3, id="overflow_ogre", fix=True, pet="beaver", threat="Overflow Ogre", after=("leak_lurker",), **C,
              task="The Overflow Ogre stuffs long names into an 8-byte box in greet.c.\n"
                   "Fix greet.c (its first lines say what it must do). "
                   "Run it: gcc -Wall -g -fsanitize=address,undefined greet.c -o greet && ./greet averyveryverylongname\n"
                   "When it works, type: verify",
              hints=["strcpy never checks the size of the target. Does the name need copying at all?",
                     "Simplest: delete name and strcpy, and print argv[1]: printf(\"Hello, %s!\\n\", argv[1]); Or malloc(strlen(argv[1]) + 1), check it isn't NULL, copy, print, free."],
              setup=overflow_setup, verify=c_tests("greet.c")),
]
