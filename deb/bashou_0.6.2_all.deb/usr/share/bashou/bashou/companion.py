"""Per-terminal background process: animates the pet, counts commands, shows speech bubbles.

Started by bashou.bash as `python3 launch.py bashou.companion <shell pid>` with stdout on the terminal.
"""

import datetime
import json
import os
import random
import re
import signal
import sys
import threading
import time
from pathlib import Path

from . import creatures, dialogue, fight, i18n, learn, progress, render, state, update
from .behavior import Behavior
from .analyze import parse_log
from .i18n import _

ESC = "\x1b"
TICK = 0.25
FIRST_TALK = (3, 8)         # minutes before the first spontaneous line
SOURCE = Path(__file__).resolve().parent


def code_version():
    """Newest mtime of our code and data (sprites, translations): it changes on an update or an edit."""
    return max(p.stat().st_mtime for pattern in ("*.py", "*.json") for p in SOURCE.rglob(pattern))


def now_ms():
    return int(time.time() * 1000)


BUBBLE_MS = 3 * 60_000     # a bubble never stays longer, however few commands you run


def answers(text, command):
    """The bubble says `→ bashou fight`, `bashou evolve`…: running that command is its answer."""
    words = command.split()
    return (len(words) > 1 and os.path.basename(words[0]) == "bashou"
            and re.search(rf"\bbashou {re.escape(words[1])}\b", text) is not None)


class Companion:
    def __init__(self, shell):
        self.shell = shell
        self.events = state.DATA / f"events.{shell}"
        self.erase_file = state.CACHE / f"erase.{shell}"
        self.resume_file = state.CACHE / f"resume.{shell}"
        self.height_file = state.CACHE / f"height.{shell}"     # lines the pet covers, for the loader
        self.offset = 0            # bytes of the events file already counted
        self.code = code_version()
        self.notes = []            # notifications waiting for the bubble
        self.bubble = None         # (text, commands run since shown, commands it stays)
        self.bubble_at = now_ms()  # when it was shown
        self.drawn = None          # (erase sequence of what is on screen)
        self.last_key = None
        self.tick = 0
        self.busy = True
        self.state_mtime = 0
        sprite, self.voice = progress.current(state.load())[::3]
        self.sprite, self.size = sprite, "small"
        self.pet = creatures.get(sprite)
        self.cells = render.mask(self.pet)
        self.stage = 1
        self.look = 1
        self.threat = False
        self.threat_text = self.threat_id = None     # the waiting threat's announcement
        self.threat_until = 0.0
        self.fights_won = 0
        self.behavior = Behavior(now=now_ms())
        self.last_command = now_ms()
        self.talk_at = now_ms() + random.randint(*FIRST_TALK) * 60_000
        self.warn_at = 0
        self.resume()

    # --- shell ------------------------------------------------------------

    def alive(self):
        try:
            os.kill(self.shell, 0)
            return True
        except OSError:
            return False

    def at_prompt(self):
        """True when the shell itself owns the terminal (no command running)."""
        try:
            with open(f"/proc/{self.shell}/stat") as f:
                fields = f.read().rsplit(")", 1)[1].split()
        except OSError:
            return False
        return fields[2] == fields[5]   # pgrp == tpgid

    # --- events -----------------------------------------------------------

    def read_events(self):
        try:
            with open(self.events, "rb") as f:
                f.seek(self.offset)
                data = f.read()
        except FileNotFoundError:
            return
        end = data.rfind(b"\n") + 1
        if not end:
            return
        self.offset += end
        records = parse_log(data[:end].decode(errors="replace"))
        if not records:
            return
        now = datetime.datetime.now()
        with state.locked() as s:
            for status, command in records:
                if self.bubble and answers(self.bubble[0], command):
                    self.bubble = None
                elif self.bubble:
                    self.bubble = (self.bubble[0], self.bubble[1] + 1, self.bubble[2])
                self.notes += progress.record(s, status, command, now.date().isoformat(), now.hour)
                if status == 127:
                    self.laugh_at_typo(s, command)
                self.warn_risky(command)

    def events_size(self):
        try:
            return self.events.stat().st_size
        except FileNotFoundError:
            return 0

    def reload_pet(self):
        try:
            mtime = state.STATE.stat().st_mtime
        except FileNotFoundError:
            return
        if mtime == self.state_mtime and not (self.threat and time.time() > self.threat_until):
            return                     # (a threat that timed out doesn't touch the state file)
        self.state_mtime = mtime
        i18n.use(None)                 # `bashou language` may have changed it
        s = state.load()
        sprite, stage, name, self.voice = progress.current(s)
        self.sprite, self.size = sprite, state.setting(s, "size")
        self.stage = self.behavior.stage = stage
        self.look = progress.look(s)           # the form drawn; the actions follow `stage`
        threat = fight.active_threat(s)
        if self.threat and not threat:
            self.threat_ended(s)
        self.threat = bool(threat)
        if threat:
            text = fight.announcement(s)
            if threat["challenge"] != self.threat_id and text:
                self.announce(text)    # every terminal says it: a lone ⚠ explained nothing
            self.threat_text, self.threat_id, self.threat_until = text, threat["challenge"], threat["until"]
        self.fights_won = s["fights_won"]

    def threat_ended(self, s):
        """Take the announcement down: it stayed up long after the threat was gone (commands over ssh
        don't count here). Unless you just won, the pet tells you it left."""
        text = self.threat_text or "\0"
        if self.bubble and text in self.bubble[0]:
            self.bubble = None
        self.notes = [n for n in self.notes if text not in n]
        if s["fights_won"] <= self.fights_won:
            self.say_now(f"{_(dialogue.VOICE[self.voice])} {fight.gone(self.threat_id)}")
        self.threat_text = self.threat_id = None

    def announce(self, text):
        if text not in self.notes and not (self.bubble and text in self.bubble[0]):
            self.notes.append(text)

    def last_activity(self):
        """Last command, or last key typed: the kernel updates the terminal's atime on input."""
        try:
            typed = int(os.fstat(1).st_atime * 1000)
        except OSError:
            typed = 0
        return max(self.last_command, typed)

    def laugh_at_typo(self, s, command):
        """`command not found`: a kind joke with the fix, every time, shown right away."""
        line = dialogue.typo(s, self.voice, command)
        if line:
            self.say_now(line)

    def warn_risky(self, command):
        """`curl … | sh`, `chmod 777`…: a safety warning, shown right away (at most once every 5 minutes)."""
        ms = now_ms()
        if ms < self.warn_at:
            return
        line = dialogue.risky(self.voice, command)
        if line:
            self.warn_at = ms + 5 * 60_000
            self.say_now(line)

    def say_now(self, line):
        """Replace the bubble right away (the old one is dropped, not queued behind)."""
        self.notes.insert(0, line)
        self.bubble = None

    def maybe_talk(self, ms):
        """Now and then at the prompt the pet says something, and only once you have stopped typing:
        it waits for a pause instead of cutting into your work (owner). `bashou config talk` sets how
        often (or `off`), `bashou config quiet` how long a pause it waits for. Whoever wants more can
        go and get it: `bashou talk`, `bashou adventure`."""
        if ms < self.talk_at or self.notes or self.bubble or self.behavior.mood == "sleep":
            return
        s = state.load()
        every = state.setting(s, "talk")
        if every == "off":                              # `bashou config talk off`: it keeps quiet
            self.talk_at = ms + 10 * 60_000
            return
        quiet = state.setting(s, "quiet")[0] * 1000
        if ms - self.last_activity() < quiet:
            self.talk_at = ms + quiet                   # still working: ask again after the next pause
            return
        self.talk_at = ms + random.randint(*every) * 60_000
        said = dialogue.line(s, self.voice)
        learn.remember(said)
        self.notes.append(said)

    def check_update(self):
        """Once a day, in the background (git may take a while): a bubble if a new version is out."""
        try:
            if update.due():
                note = update.check()
                if note:
                    self.notes.append(note)
        except Exception:
            log_error()

    def check_threat(self):
        with state.locked() as s:
            note = fight.maybe_threat(s)
        if note:
            self.state_mtime = 0           # reload_pet() announces it and blinks the ⚠

    # --- drawing ----------------------------------------------------------

    def frame(self, ms, poses, z, cols):
        """Escape sequence for one frame, and the sequence that erases it."""
        pet = self.pet
        x = cols - pet.width
        out = [f"{ESC}[{i + 1};{x}H{line}" for i, line in enumerate(render.lines(pet, poses, self.cells, self.look))]
        zr, zc = pet.z_at
        out.append(f"{ESC}[{zr + 1};{x + zc}H{ESC}[38;2;150;190;230m{z:<3}{ESC}[0m")
        erase = render.erase(self.cells, 1, x)

        if self.bubble:
            lines, bw = render.bubble(self.bubble[0], x - 2)
            bx = x - bw
            if bx >= 1:
                out.append(f"{ESC}[1;{bx}H" + " " * bw)     # a scrolled-up copy of the top border
                for i, line in enumerate(lines):
                    out.append(f"{ESC}[{i + 2};{bx}H{ESC}[38;2;150;190;230m{line}{ESC}[0m")
                erase += render.erase([[True] * bw] * (len(lines) + 1), 1, bx)
        return "".join(out), erase

    def update_bubble(self):
        """A bubble stays for a few commands (`bashou config bubble`), 2 at most when another note waits,
        and 3 minutes at most."""
        if self.bubble:
            text, shown, stays = self.bubble
            if shown >= (min(stays, 2) if self.notes else stays) or now_ms() - self.bubble_at > BUBBLE_MS:
                self.bubble = None
        if not self.bubble and self.notes:
            self.bubble = (self.notes.pop(0), 0, random.randint(*state.setting(state.load(), "bubble")))
            self.bubble_at = now_ms()

    def fit(self, cols):
        """The large sprite when asked for and the terminal has room for it, else the small one."""
        pet = creatures.get(self.sprite, self.size)
        if cols < pet.width + 20:
            pet = creatures.get(self.sprite)
        if pet is not self.pet:
            self.pet = pet
            self.cells = render.mask(pet)
            try:
                self.height_file.write_text(str(len(pet.base) // 2))
            except OSError:
                pass

    def draw(self, ms):
        self.update_bubble()

        cols = os.get_terminal_size(1).columns
        self.fit(cols)
        if cols < self.pet.width + 20:
            return
        poses, z = self.behavior.frame(ms, self.pet, self.threat, ms - self.last_activity())
        key = (tuple(poses), z, cols, self.bubble and self.bubble[0], self.pet.id, self.pet.width, self.look)
        if key == self.last_key and self.tick % 8:
            return
        self.last_key = key

        body, erase = self.frame(ms, poses, z, cols)
        out = ESC + "7"
        if self.drawn and self.drawn != erase:
            out += self.drawn          # the pet moved or the bubble closed
        out += body + ESC + "8"
        os.write(1, out.encode())
        if erase != self.drawn:
            self.drawn = erase
            self.erase_file.write_text(ESC + "7" + erase + ESC + "8")

    # --- main loop --------------------------------------------------------

    def step(self):
        if not self.at_prompt():
            self.busy = True
            return
        # A new event (or the prompt's SIGUSR1) means a command ran and PS0 erased us.
        if self.events_size() != self.offset:
            self.busy = True
        if self.busy or self.tick % 4 == 0:
            self.read_events()
            self.reload_pet()
        if self.tick % 120 == 60:
            self.check_threat()
        if self.tick == 80:              # 20 s after the start, not to slow down the first prompt
            threading.Thread(target=self.check_update, daemon=True).start()
        if self.busy:
            self.busy, self.last_key, self.drawn = False, None, None
            self.last_command = now_ms()
        if self.tick % 20 == 10 and self.code_changed():
            self.read_events()
            self.restart()
        self.maybe_talk(now_ms())
        self.draw(now_ms())

    def code_changed(self):
        """True once the source changed and has been quiet for 2 s (not in the middle of a save)."""
        try:
            newest = code_version()
        except (OSError, ValueError):
            return False
        return newest != self.code and time.time() - newest > 2

    HANDOVER = ("offset", "bubble", "bubble_at", "notes", "talk_at", "warn_at", "threat", "threat_text", "threat_id",
                "threat_until", "fights_won")

    def restart(self):
        """Run the new code in this same process (same PID, so the shell still knows us).

        What must survive (events already counted, the bubble on screen, waiting notes) goes
        through the resume file.
        """
        if self.drawn:
            os.write(1, (ESC + "7" + self.drawn + ESC + "8").encode())
        self.save_resume()
        # A handler doesn't survive exec, an ignored signal does: no SIGUSR1 death in between.
        signal.signal(signal.SIGUSR1, signal.SIG_IGN)
        os.execv(sys.executable, [sys.executable, str(SOURCE.parent / "launch.py"), "bashou.companion", str(self.shell)])

    def save_resume(self):
        self.resume_file.write_text(json.dumps({k: getattr(self, k) for k in self.HANDOVER}))

    def resume(self):
        try:
            saved = json.loads(self.resume_file.read_text())
            self.resume_file.unlink()
        except (OSError, ValueError):
            return
        for key in self.HANDOVER:
            if key in saved:
                setattr(self, key, saved[key])
        if self.bubble:
            self.bubble = tuple(self.bubble)

    def run(self):
        state.private(state.CACHE)
        sweep_events()
        errors = 0
        try:
            while self.alive():
                time.sleep(TICK)
                self.tick += 1
                try:
                    self.step()
                    errors = 0
                except Exception:
                    # Never let one bad frame kill the pet: log it and keep going.
                    errors += 1
                    log_error()
                    if errors >= 20:
                        raise
        finally:
            for f in (self.events, self.erase_file):
                try:
                    f.unlink()
                except FileNotFoundError:
                    pass

def sweep_events():
    """Event files of terminals that are gone (a crash, a kill -9) still hold what was typed there:
    remove them. Each pet removes its own when its terminal closes."""
    for f in state.DATA.glob("events.*"):
        try:
            pid = int(f.suffix[1:])
            os.kill(pid, 0)
        except ValueError:
            continue
        except ProcessLookupError:
            f.unlink(missing_ok=True)
        except PermissionError:
            pass                                        # alive, someone else's: not ours to touch


def log_error():
    """Append the traceback to ~/.cache/bashou/errors.log (kept small)."""
    import traceback
    log = state.CACHE / "errors.log"
    try:
        old = log.read_text()[-20000:] if log.exists() else ""
        log.write_text(old + f"--- {datetime.datetime.now():%F %T}\n{traceback.format_exc()}")
    except OSError:
        pass


def main():
    # Started from .bashrc before job control is on, so we'd share the shell's process group
    # and die on every Ctrl+C at the prompt. Leave the group, and ignore SIGINT anyway.
    os.setpgrp()
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    companion = Companion(int(sys.argv[1]))
    # The prompt sends SIGUSR1 after every command: redraw right away.
    signal.signal(signal.SIGUSR1, lambda *_: setattr(companion, "busy", True))
    companion.run()


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, BrokenPipeError, OSError):
        pass
