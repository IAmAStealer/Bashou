"""`bashou swap`: a 4×4 board to pick your active pet, with a live preview."""

import os
import select
import sys
import termios
import tty

from . import achievements, creatures, progress, render, state
from .behavior import ACTIONS
from .creatures import FORM_NAMES, STAGES, STARTERS, roster
from .i18n import _

ESC = "\x1b"
COLS = 4
TILE_W, TILE_H = 18, 2          # 16-character names (Golem de cristal) fit; 4 × 18 fits 80 columns
PREVIEW_SHORT = 9                  # sprite, blank line, name and next stage
DIM, BOLD, RESET, REV = f"{ESC}[2m", f"{ESC}[1m", f"{ESC}[0m", f"{ESC}[7m"
ACCENT = f"{ESC}[38;2;150;190;230m"
KEYS = {"\x1b[A": "up", "\x1b[B": "down", "\x1b[C": "right", "\x1b[D": "left",
        "k": "up", "j": "down", "l": "right", "h": "left", "\r": "enter", "\n": "enter",
        "f": "form", "q": "quit", "\x1b": "quit", "\x04": "quit", "\x03": "quit"}


def hint(s, pet):
    return progress.how_to_unlock(s, pet)


def silhouette(pet):
    return creatures.Pet(pet.id, pet.name, pet.base, {k: (70, 72, 86) for k in pet.palette},
                         stages=pet.stages)


def ladder_line(s):
    """The forms reached so far, then a mystery: what comes next is for you to discover."""
    forms, levels = progress.ladder(s)
    top = progress.starter_form(s)
    shown = [_(FORM_NAMES[f]) for f in forms[:top]]
    if top < len(forms):
        shown.append("? " + _("(level {level})").format(level=levels[top]))
    return " → ".join(shown)


class Board:
    def __init__(self):
        self.s = state.load()
        ids = ["starter"] + [pet for pet, rule in roster(self.s)]   # starter on its own row, then the 4×4 grid
        self.ids = ids
        self.pos = ids.index(self.s["active"]) if self.s["active"] in ids else 0
        self.breath = False
        self.message = ""
        self.top = 0                      # first pet row shown when the grid scrolls

    def rows(self):
        return -(-(len(self.ids) - 1) // COLS)          # the last row may be partly empty

    def tile(self, i):
        if i >= len(self.ids):
            return ["", ""]
        pet = self.ids[i]
        unlocked = pet in self.s["pets"] or pet == "starter"
        if pet == "starter":
            lvl = progress.starter_level(self.s)
            name = progress.current(self.s, "starter")[2]
            top = _("Lv {level}").format(level=lvl) + ("  ●" if self.s["active"] == "starter" else "")
        elif unlocked:
            st = progress.stage(self.s, pet)
            name = progress.current(self.s, pet)[2]
            top = progress.stars(self.s, pet) + ("  ●" if pet == self.s["active"] else "")
        else:
            name, top = "???", "☆☆☆"
        name = name[:TILE_W - 2]
        style = REV if i == self.pos else ("" if unlocked else DIM)
        return [f"{style} {top:<{TILE_W - 2}} {RESET}",
                f"{style} {name:<{TILE_W - 2}} {RESET}"]

    def starter_preview(self):
        s = self.s
        sprite, form, name, voice = progress.current(s, "starter")
        pet = creatures.get(sprite)
        cells = [[True] * pet.width for _ in range(len(pet.base) // 2)]
        out = render.lines(pet, ["inhale"] if self.breath else [], cells, progress.look(s, "starter")) + [""]
        lvl = progress.starter_level(s)
        out.append(f"{BOLD}{name}{RESET}  " + _("level {level}").format(level=f"{lvl}/{progress.MAX_LEVEL}"))
        if lvl < progress.MAX_LEVEL:
            per = progress.ACHIEVEMENTS_PER_LEVEL
            out.append(DIM + _("{n} achievement(s) to level {level}").format(
                n=per - len(s["achievements"]) % per, level=lvl + 1) + RESET)
        out.append(DIM + ladder_line(s) + RESET)
        return out

    def preview(self):
        pet_id = self.ids[self.pos]
        if pet_id == "starter":
            return self.starter_preview()
        unlocked = pet_id in self.s["pets"]
        drawn = pet_id in creatures.PETS
        out = []
        if drawn:
            stage = progress.look(self.s, pet_id) if unlocked else 1
            pet = creatures.PETS[creatures.form(pet_id, stage)]
            shown = pet if unlocked else silhouette(pet)
            cells = [[True] * pet.width for _ in range(len(pet.base) // 2)]
            poses = ["inhale"] if self.breath else []
            out += render.lines(shown, poses, cells, stage)
        else:
            out += ["", "", f"{DIM}   " + _("(art coming soon)") + RESET, "", "", ""]
        out.append("")
        if unlocked:
            st = progress.stage(self.s, pet_id)
            out.append(f"{BOLD}{progress.current(self.s, pet_id)[2]}{RESET}  {'★' * st}{'☆' * (3 - st)}")
            if st < 3:
                out.append(DIM + _("next: {name}, learns to {actions}").format(
                    name=_(STAGES[pet_id][st]), actions=_(ACTIONS[st + 1])) + RESET)
        else:
            out.append(f"{BOLD}???{RESET}")
            out.append(ACCENT + _("unlock: {how}").format(how=hint(self.s, pet_id)) + RESET)
        fam = achievements.family(pet_id)
        earned = set(self.s["achievements"])
        out.append("")
        for a in fam:
            mark = "🏆" if a.id in earned else "· "
            out.append(f"{mark} {_(a.name)}" if a.id in earned else f"{DIM}{mark} {_(a.name)}: {_(a.how)}{RESET}")
        return out

    def layout(self, cols, lines):
        """(grid lines, preview lines, preview on the side?) fitting a cols × lines terminal.
        When it's too short, the preview keeps its sprite and name, and the grid scrolls."""
        head = [f"{BOLD}Bashou{RESET} {DIM}· " + _("{n} pets · arrows/hjkl · Enter: pick · f: form · q: quit").format(
            n=f"{len(creatures.owned(self.s))}/{len(self.ids) - 1}") + RESET, ""] + self.tile(0)
        preview = self.preview()
        side = cols >= COLS * TILE_W + 40
        dim = self.message.startswith(DIM)
        text = self.message.replace(DIM, "").replace(RESET, "")
        width = max(20, (cols - COLS * TILE_W - 6) if side else cols - 2)
        message = [(DIM if dim else "") + part + (RESET if dim else "")
                   for part in render.wrap(text, width, 3)] if text else [""]
        fixed = len(head) + len(message)                              # the message wraps on a few lines
        if side:
            room = lines - fixed
        else:
            if fixed + self.rows() * TILE_H + 1 + len(preview) > lines:
                preview = preview[:PREVIEW_SHORT]
            room = lines - fixed - 1 - len(preview)
        shown = max(1, min(self.rows(), room // TILE_H))
        if self.pos:                                                  # keep the selected row in view
            row = (self.pos - 1) // COLS
            self.top = min(max(self.top, row - shown + 1), row)
        self.top = max(0, min(self.top, self.rows() - shown))
        grid = list(head)
        for row in range(self.top, self.top + shown):
            tiles = [self.tile(1 + row * COLS + c) for c in range(COLS)]
            for line in range(TILE_H):
                grid.append("".join(t[line] if t[line] else " " * TILE_W for t in tiles))
        more = shown < self.rows()
        grid += message if text else [DIM + _("↑↓ more pets") + RESET if more else ""]
        return grid, preview, side

    def draw(self):
        size = os.get_terminal_size()
        grid, preview, side = self.layout(size.columns, size.lines)
        out = [f"{ESC}[H{ESC}[2J"]
        for i, line in enumerate(grid):
            if i < size.lines:
                out.append(f"{ESC}[{i + 1};1H{line}")
        for i, line in enumerate(preview):
            row = i + 3 if side else len(grid) + i + 2
            if row <= size.lines:                          # below the last line the terminal would scroll
                out.append(f"{ESC}[{row};{COLS * TILE_W + 4 if side else 2}H{line}")
        sys.stdout.write("".join(out))
        sys.stdout.flush()

    def switch_form(self, pet):
        """Show the next form this pet has reached (looks only: it keeps every action)."""
        if pet != "starter" and pet not in self.s["pets"]:
            return
        top = progress.reached(self.s, pet)
        if top == 1:
            self.message = DIM + _("Only one form so far: it evolves with achievements.") + RESET
            return
        form = progress.look(self.s, pet) % top + 1
        who = progress.who_of(self.s, pet)
        with state.locked() as s:
            if form == top:
                s.setdefault("looks", {}).pop(who, None)
            else:
                s.setdefault("looks", {})[who] = form
        self.s = state.load()
        self.message = _("{name}: form {n}/{total}").format(name=progress.current(self.s, pet)[2], n=form, total=top)

    def key(self, k):
        n, size = self.pos, len(self.ids)
        last_row = 1 + (self.rows() - 1) * COLS
        if k == "up":
            self.pos = 0 if 1 <= n <= COLS else (n - COLS if n else last_row)
        elif k == "down":
            if n == 0:
                self.pos = 1
            elif n + COLS < size:
                self.pos = n + COLS
            else:                                        # into the partial last row, or back to the starter
                self.pos = size - 1 if n < last_row else 0
        elif k == "left":
            self.pos = (n - 1) % size
        elif k == "right":
            self.pos = (n + 1) % size
        elif k == "enter":
            pet = self.ids[n]
            if pet != "starter" and pet not in self.s["pets"]:
                self.message = DIM + _("Not unlocked yet: {how}").format(how=hint(self.s, pet)) + RESET
                return True
            with state.locked() as s:
                s["active"] = pet
            self.s = state.load()
            return False
        elif k == "form":
            self.switch_form(self.ids[n])
            return True
        elif k == "quit":
            return False
        self.message = ""
        return True

    def run(self):
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        sys.stdout.write(f"{ESC}[?1049h{ESC}[?25l{ESC}[?7l")         # no autowrap: a long line never spills
        try:
            tty.setcbreak(fd)
            running = True
            while running:
                self.draw()
                ready = select.select([fd], [], [], 1.5)[0]
                if not ready:
                    self.breath = not self.breath
                    continue
                data = os.read(fd, 8).decode(errors="ignore")
                running = self.key(KEYS.get(data, ""))
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.write(f"{ESC}[?7h{ESC}[?25h{ESC}[?1049l")
            sys.stdout.flush()
        print("  " + _("{name} is your pet.").format(name=progress.current(self.s)[2]))


def main():
    Board().run()
