import os
import shlex
import signal
import subprocess
import sys
import time
from pathlib import Path

from . import Challenge
from .. import procs


def setup(work, rng):
    name = f"phantom-{rng.randrange(16 ** 4):04x}"
    # Detached from Python; cleanup() kills it when the arena closes.
    # python3, not sleep: on RHEL 9 sleep is a coreutils shebang script, and the new name got lost.
    # macOS (no /proc) the other way round: its python3 starts another program (Python.app), /bin/sleep doesn't.
    nap = f"{shlex.quote(sys.executable)} -c 'import time; time.sleep(3600)'" if procs.PROC else "/bin/sleep 3600"
    out = subprocess.run(["bash", "-c", f"(exec -a {name} {nap}) </dev/null >/dev/null 2>&1 & echo $!"],
                         capture_output=True, text=True)
    pid = int(out.stdout)
    # `$!` comes back before the subshell has exec'd: wait until the process shows its name.
    for _ in range(100):
        if procs.command(pid).startswith(name):
            break
        time.sleep(0.02)
    return {"args": {"name": name}, "answer": pid, "pid": pid}


def cleanup(meta):
    try:
        os.kill(meta["pid"], signal.SIGTERM)
    except (OSError, KeyError):
        pass


CHALLENGE = Challenge(
    level=2, id="ps_phantom", pet="ghost", tools=("ps", "pgrep", "pidof"), threat="Process Phantom",
    task="A Process Phantom named {name} haunts this machine.\nWhat is its PID?",
    help="Here, find how to see every process, not only yours.",
    hints=["`ps aux` lists every process with its PID in the 2nd column. pgrep -f finds one by its command line.",
           "Try: pgrep -f phantom   (ps aux | grep phantom also lists the grep itself)"],
    setup=setup, cleanup=cleanup, requires=["ps"],
)
ALL = [CHALLENGE]
