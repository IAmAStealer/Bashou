# Changelog

Every release has a section here, written for players. CI refuses to tag a release without one
(`python3 tools/changelog.py v1.2.3` prints the section it will publish).

## v0.12.2 — 2026-11-05

### Changes

- Rocky Linux 9 can install Bashou from `dnf` again: the 0.12.1 package carried a signature its `rpm` can't read, so `dnf` called it unsigned and refused it.
- The Turtle, Slime, Mushroom, Octopus, Kraken, Dragon, Owl, Beanbag, Fennec, Mole, Ghost, Snake, Ant, Honey badger, Axolotl, Gremlin and Snail families are redrawn or retouched, most with a fidget of their own. Their old looks stay one key away: press `s` on the pet board, or use `bashou config style`.
- The JSON Jinn, Base64 Banshee, Percent Poltergeist, Token Trickster, Subnet Sprite and Six Serpent are now won by a program: finish `solve.py`, then `verify`. It is also run on a changed copy, so a hardcoded answer is refused.
- Pets no longer lose a pixel when breathing and fidgeting at once.

### Breaking changes

- Breaking change: a pony watched the new Snail stretch its eye stalks, tried the same with its neck and is now looking at you from over the next hill. Bring it home with `bashou pony hoof`.

## v0.12.1 — 2026-11-02

### Changes

- Three new Logic lessons, each with a fight and a chest: how much work a loop costs (the Square Spider), shaping data once into a table (the Parse Parrot), and codes that find and fix flipped bits (the Bitflip Banshee). 15 new questions, 503 in all.
- The Star, Sprout, Pebble, Bat and Frog families are redrawn. Their old looks stay one key away: press `s` on the pet board, or use `bashou config style`.
- In fights, only a wrong `answer` costs a heart: running your script, a failed command and `verify` are free.
- Boss questions give 35 to 50 seconds.
- Python fights accept counts of zero, and a failed `verify` shows one test your code fails. The Except Eel says why it refuses your script, such as a bare `except:` left in it.
- The Group Gremlin asks about another account's main group, not yours, since yours is nearly always your own name.
- The Amethyst golem now comes before the Jade golem.
- Rust lessons, hints and projects were corrected after a full recheck, and every Rust fight's last hint is now built and run by the tests.

### Breaking changes

- Breaking change: a pony heard that only a wrong answer costs a heart, answered everything wrong to check and left with none. Bring it home with `bashou pony hoof`.

## v0.12.0 — 2026-10-30

### Changes

- New lessons on SSH and firewalls, with two fights: the Key Kraken (fix the rights of `~/.ssh`) and the Drop Dragon (find the nftables rule that drops a client).
- New lessons on Python errors and exit codes (the Except Eel), SQL's NULL (the Null Newt) and Rust ownership and borrowing (the Borrow Badger and the Vector Viper).
- The git lesson now covers conflicts, stash and undo, in seven pages, with the Revert Revenant.
- Every lesson ends on a quiz of its own questions, and three right answers open the lessons after it. 44 new questions, 488 in all.
- Boss questions give 25 to 40 seconds, more when the question and its choices take longer to read.
- The lesson library shows its two views as tabs under the title; `f` switches.
- The Stowaway Stoat is fought with `dpkg` and the Autoremove Adder with `apt-mark`, the commands their answers need.
- Lessons, questions and fights on Rust, C, git, networks, packages, CI/CD, logic, AI and Linux were reviewed against the official docs, man pages and release notes: Mac commands next to Linux ones, Debian 13's missing `last`, logs per system, EPEL with CRB, script injection that really injects, and many more.
- Several pets are lit from the top left, the Resolver Rook is redrawn as a chess tower, and the Snakelet and the Snake get the drawings they should have had in 0.11.0.
- The README opens on four pictures and the install.

### Breaking changes

- Breaking change: a pony was given 40 seconds to answer a boss, spent 39 reading the choices and bolted at the last one. Bring it home with `bashou pony hoof`.

## v0.11.0 — 2026-10-27

### Changes

- The lesson library opens on your path: the ten lessons to take next, each with its section, and the locked ones about to open. Press `f` for the whole library, where each section now shows once (git has its own).
- Lessons open by difficulty: the first steps open once you've read the lesson before, most lessons once you've practiced it, and hard ones (C pointers, gdb, Rust, awk and sed, SQL joins, running a CA…) only once you've mastered what comes before.
- systemd is part of the Linux skill now, Linux only, with its lesson, fight and questions. If you had picked systemd, you now learn Linux; your adventure on the systemd road goes on on the Linux one.
- The Snail family is redrawn: a slug builds its shell in a hard hat and hi-vis jacket, brick by brick, until it becomes Gary. Your snail keeps its place in the chain.
- The Snakelet is redrawn as a round-headed baby snake with big eyes.
- Python lessons, questions, fights and projects were reviewed against the official Python docs: files opened with `with` and an encoding, true facts for Python 3.9, programs run inside their virtual environment, safer hints.
- Keys you type right after Enter, or a half-typed command on a Mac, are no longer lost while the pet makes its room, and Ctrl+C there leaves the terminal as it was.
- In `bashou spot`, the answers beside a long string stay inside an 80-column terminal.
- A progress file exported with an older Bashou can't be imported any more: update Bashou on both computers, then export again.

### Breaking changes

- Breaking change: a pony was told it had to master the lesson before, galloped off to find a teacher and never came back. Bring it home with `bashou pony hoof`.

## v0.10.6 — 2026-10-25

### Changes

- Certificates join the Network skill: six lessons, from reading a certificate and checking its names and dates to running your own CA (basicConstraints, path length, key usage), finding and reading `openssl.cnf`, and revoking a certificate with a CRL. With 25 new questions, two owl lessons and their chests.
- Ten certificate fights: an expiring certificate, a missing name, a key that doesn't match, a chain in the wrong order, a script that turned off checking with `-k`, a request to fill in, an intermediate that signs too deep, an impostor CA, a config section Bashou signs with, and a certificate to revoke. Where a Mac's LibreSSL differs, the lessons give its line too.
- A new pet, the Seal, grows through five forms with eleven certificate achievements, up to the Sea otter keeping its wax seal in its pouch.
- SQL lessons and questions follow written rules now, and every statement you're shown is run in the tests: name the columns of an INSERT, ORDER BY before LIMIT, transactions that a failed statement leaves open, safe copies with `.backup`.
- Hidden notes in fights say just "answer <word>", so it's clear what to type.
- Bashou no longer prints `^[[30;120R` on the screen, and Enter no longer makes the screen flicker.
- The pet no longer suggests a command that isn't installed when you mistype one.

### Breaking changes

- Breaking change: a pony read about revocation, put its own horseshoe on the CRL and galloped off unshod. Bring it home with `bashou pony hoof`.

## v0.10.5 — 2026-10-22

### Changes

- Bash scripts are a skill of their own, next to Bash at the prompt. Typing a quick command and writing a script that runs alone later are different jobs: the new lessons teach the second one (errors, file names, data, cleanup), from a small script template. If you had picked Bash, Bash scripts is added to your skills.
- Eight new script fights: Bashou runs your fixed script on its own hostile files (a name starting with -, a folder with no match, a name with a newline…), so a fix that only works on the files you see doesn't win. With 24 new questions, two road lessons and their chests, and a new boss, the Errexit Ogre.
- The bash shown everywhere was reviewed line by line against the r/bash references (BashFAQ, BashPitfalls): checked failures (`|| exit 1` after reading a password), notes where a Mac differs (`sed -i ''`, `wc`, `pgrep`), whole-name `grep -qxF --` in conditions, and lessons that say when a habit is fine at the prompt but not in a script.
- Losing or fleeing a fight sends the threat away for a while instead of letting you retry at once.
- A lost or fled review keeps your earlier wins and comes back sooner instead of starting over.
- New art for the Bash Beast and for the script enemies.
- When a new version is out, every terminal's pet tells you, and says it again every two hours until you run `bashou update`. Before, only one terminal said it, once a day.
- A progress file exported with an older Bashou can't be imported any more: update Bashou on both computers, then export again.

### Breaking changes

- Breaking change: a pony read `set -e`, tripped over its own `((hooves++))` at zero and stopped right there in the field. Bring it home with `bashou pony hoof`.

## v0.10.4 — 2026-10-21

### Changes

- Once you flee a fight (or lose it), your pet stops reminding you of that threat every half hour. It still waits for you with `bashou fight` until midnight.
- Gary looks like the real Gary: yellow-green eyes with red pupils and a green belly.

### Breaking changes

- Breaking change: a pony saw Gary's new green belly, decided it was grass and trotted off to graze somewhere quieter. Bring it home with `bashou pony hoof`.

## v0.10.3 — 2026-10-20

### Changes

- A threat now waits for you until midnight (2 hours at least) instead of 30 minutes, and your pet repeats its warning every half hour, so a day's fight is no longer missed when the bubble goes by.
- Experienced players get up to 2 threats a day instead of 1.
- Homebrew installs run on Homebrew's own Python 3.15 and no longer use whichever `python3` comes first on your PATH.

### Breaking changes

- Breaking change: a pony waited all day for a threat that never showed up, got bored and went to watch the sunset. Bring it home with `bashou pony hoof`.

## v0.10.2 — 2026-10-18

### Changes

- An opened chest stays opened: quitting the adventure right after a chest no longer brings it back.
- The same chest never comes twice in one run of an adventure path. Replaying from a checkpoint is a new run, so its chests can come back.

### Breaking changes

- Breaking change: a pony found the chest that kept coming back, emptied it for good and trotted off with the loot. Bring it home with `bashou pony hoof`.

## v0.10.1 — 2026-10-17

### Changes

- Each release now reaches Homebrew by itself: `brew upgrade` on a Mac gets new versions of Bashou on the day they come out.

### Breaking changes

- Breaking change: a pony learned to pour its own hay cider and no longer waits for anyone. Bring it home with `bashou pony hoof`.

## v0.10.0 — 2026-10-17

### Changes

- Bashou runs on macOS: install it with Homebrew (`brew install iamastealer/bashou/bashou`, then `bashou on`), and `brew upgrade` keeps it up to date. On a Mac, the questions and lessons follow your system: Linux-only ones are left out, and `bashou config os both` brings them back if you also work on Linux servers.
- New `bashou export` and `bashou import`: carry your progress to another computer in a small text file you can mail to yourself.
- A new AI tools skill: two lessons on context, memory and planning when you work with an AI assistant, with questions you answer on the adventure road or at the end of the lesson.
- New `bashou changelog`: what changed in each release, newest first.
- Every pet family now grows with its achievements: the first one brings the pet, each new count of a command is another, and five new forms wait to be reached.
- `bashou swap` works with the mouse, lists each pet's forms with their stars next to the preview, and no longer flickers. The ponies share one tile: `f` shows the next pony you found.
- Adventure bosses are drawn with square pixels at every size, so they no longer look stretched.
- In `bashou spot`, 5 wrong answers end the game, so holding one arrow key no longer wins.
- The Clutter Critter can be beaten with `mkdir` and `mv` on separate lines, and fights that want a loop or a pipeline now say so.

### Breaking changes

- Breaking change: a pony tried Homebrew, brewed a barrel of hay cider and trotted off to share it. Bring it home with `bashou pony hoof`.

## v0.9.0 — 2026-10-12

### Changes

- Bashou now works in zsh: your pet, Tab completion, `bashou on` and `bashou off`, and fights that happen in your own shell. Installing Bashou in bash sets it up in zsh too.
- A new lesson, "bash and zsh", shows where the two shells read the same line differently, with a new fight, the Index Imp, a chest on the adventure road and new questions. If you use zsh, a few lessons get an extra page about what changes for you.
- `bashou on` and `bashou off` always say what happened, even when your pet is already there.
- Finishing a lesson now tells you that reading it isn't enough to open the next one, and how to practice it.
- The Flag Phantom now asks for `sort -h` on folder sizes: plain `sort` already ignores capitals on most systems, so `-f` taught nothing.

### Breaking changes

- Breaking change: a pony switched to zsh, started counting its hooves from 1, and wandered off looking for the missing one. Bring it home with `bashou pony hoof`.

## v0.8.6 — 2026-10-11

### Changes

- Locked lessons in the Sage Owl's library now say which lesson they wait for. Select one to see how to open it, and press Enter to jump to the lesson to practice first.
- Fights are kinder: a typo or a `find` never costs a heart, and in fights where you fix a file, checking your work (with `grep`, `diff` or a backup copy) is free.
- Pipeline fights have a new `check` command: it reads your YAML the way `verify` will, says which line is wrong (a tab, for example), and runs `yamllint` if you have it.
- Logic fights come with a small test script: run it, then add your own cases.
- When you pick your skills, each one shows the programs it uses, what they are for, and how to install a missing one.
- Something wild that watches winners now counts the last 24 hours, not the calendar day: a late-night streak counts too.

### Breaking changes

- Breaking change: a pony read the new test scripts, added a case of its own and galloped off to run it. Fetch it with `bashou pony hoof`.

## v0.8.5 — 2026-10-10

### Changes

- A new secret pet waits for players who know one of the oldest jokes in the terminal. Mistyping is not enough.
- Two more friends from the herd hide where people report bugs. Look closely, and don't skip what's closed.
- Win a few fights in one day and you may feel something wild watching you.

### Breaking changes

- Breaking change: a pony chewed through the release notes and escaped again. Bring it home with `bashou pony hoof`.

## v0.8.4 — 2026-10-10

### Changes

- Curious players may meet new friends hiding in and around Bashou. We won't say where: look around.

### Breaking changes

- Breaking change: a pony kicked down its stable door and ran away. Catch it with `bashou pony hoof`.

## v0.8.3 — 2026-10-07

- Bashou speaks French on the web too: there is a French README (`README.fr.md`) and a French home page at
  `/fr`. Search engines know which page is for which language. You can report a bug or suggest an idea in
  French with the new French forms, and the contributing guide has a French version too.
- Bashou is on for every user right after `apt install` or `dnf install`: open a new terminal and your pet
  is there. `bashou off` now keeps it off in new terminals, until you run `bashou on` again.
- The Squab has a new look: no more horns, its wing lifts when it breathes, and its beak opens like the
  duckling's.
- Bashou no longer leaves `^[[30;120R` on the screen when the terminal is slow to answer.
- The README shows how to install right after the introduction, in shorter sentences.

## v0.8.2 — 2026-10-04

- `bashou spot` has three new kinds of strings to recognise: a Linux password hash (`$1$…`, as in old
  `/etc/shadow` files and `openssl passwd -1`), a CSRF token in a form (`_csrf=…`), and OAuth2 (the
  `?code=…&state=…` that comes back after a login, or a `Bearer` token). Each is made the real way, so what
  you learn to spot here is what you meet in logs and configs.
- The website's home page now says what Bashou teaches, with screenshots, and search engines get a sitemap.
  Share cards stay out of search results.
- Your starter grows further: four new forms for each line, drawn in pixel art. The Star goes on to a Nebula,
  a Black hole, a Galaxy and the whole Universe; the Seedling to an Old oak, a Blossom tree, a Forest and the
  World tree; the Pebble to Amethyst, Ruby and Diamond golems, and at last a Pet rock in its box. The 11 forms
  are spread over the 20 levels, and you keep every form you already reached.
- A second secret pet hides in the game, for players who like a good fight. Once it's yours, it doesn't wait
  for threats: leave the terminal alone for a while and it picks one itself, and the arena opens right after
  your next command (twice a day at most). Choose another pet with `bashou swap` when you want peace.

## v0.8.1 — 2026-10-03

- `bashou share`: the card now shows your best `bashou spot` score, and a row of your rare pets at the
  bottom: the pets you grew to their last form first, then the hardest to meet (the secret Hacker cat,
  the Spider, the Whale and the Leopard). Before the QR code, Bashou lists them with the rest. When there
  are many, only the first ones go in the link, so the QR code stays small enough to scan.
- The card is no longer jagged on a phone: the image is smoothed when the screen shows it smaller.
- Links from older versions still open, without these new parts.
- The README shows what's new in 0.8.0 and 0.7.0, with `bashou spot` and `bashou here`.

## v0.8.0 — 2026-10-03

- New: `bashou project`. You want to practise a language but don't know what to program? 13 real
  projects to build, in Python, Shell, C and Rust, from very easy to hard: merge or split PDFs, sort your
  photos into folders by date, a web page of your budget, a backup script, a daily report from a log, a
  Pomodoro timer, an electricity or fuel tracker, a contact book, a todo list, an internet outage logger,
  a shopping list from your weekly menu, and a sorter for your administrative papers.
- One small step at a time: each step says what to do and when it's done, never how, because searching
  is part of learning. Type `bashou project next` when it's done: Bashou explains what that step taught
  you, then shows the next one. Stuck? `bashou project hint` gives you a nudge, never the answer. Each
  project remembers its own step, so you can switch between them.
- A new pet grows with your projects: the Landscape. It starts as a small hill with a tree, and becomes a
  cabin, a garden, a river, a waterfall, a mill, mountains, a village, a port with its lighthouse, and a
  town under the stars. 32 new achievements come with it, often at first: the first step, 3 steps, 5
  steps, then each finished project and each language. Finishing the projects of one language is enough
  to reach the town.
- Your pet sometimes reminds you of the project you started, and where you stopped.
- New game: `bashou spot`. A string shows in the middle of the screen: an IPv4 or IPv6 address, a MAC, a
  UUID, base64, a hash, something encrypted, a JWT, HTTP Basic auth, an email, a URL, a regex, a date, a
  timestamp, or a line of Python, Rust, C, Bash or SQL. Say what it is with the arrow keys, as many times as
  you can in 25 seconds. A wrong answer puts that kind back in the bag, so you meet it again. `r` starts over.
- A new pet comes with it, for sharp eyes and speed: the Chameleon, then the Mantis, the Cheetah, the Falcon
  and the Eagle. 8 achievements: your first game, 5, 10, 15 and 20 good answers in a game, every kind
  recognised once, 10 games, and 10 good answers without a mistake. The end of a game shows the ones you earned.
- `bashou achv` and `bashou achievement` show your achievements, like `bashou achievements`.
- `bashou here` brings your pet to the terminal you type it in. It lives in one terminal at a time; the
  commands you type in the others still count, and none is counted twice when it moves.
- Ctrl+L in a terminal without the pet no longer leaves empty rows at the top.
- New lesson in the Sage Owl's library, after "Your first script": command substitution, `$( )`. How
  the shell runs the inside first, the old backticks you'll meet in old scripts, why it goes in double
  quotes, the newline it removes, the exit code that `set -e` sees or loses, and how a script reads a
  password from `pass` without ever holding it. 4 new Bash questions in the adventure go with it.
- The Paradox Sphinx's question about the index of a list's last item had two choices that were valid
  indexes. It now asks for the index of the 5th item, and only one choice is right.

## v0.7.0 — 2026-10-02

- In a very small window, the commands that draw a screen (`bashou evolve`, `swap`, `lesson`,
  `adventure`, `start` and `share`) tell you the window is too small and the size they need, instead of
  drawing a broken screen that can look stuck. `bashou share` needs room for the whole QR code, or
  your phone can't scan it.
- In a narrow window, the progress bar of `bashou` is shorter, so it stays on one line.
- With several terminals open, your pet lives in only one of them, the first you opened, instead of
  one pet (and one background process) in each. The commands you type in the other terminals still
  count for it. When you close its terminal, the pet moves to the next terminal where you press Enter.
- The Sage Owl's library is now a path. Each lesson opens once you've passed the lessons that come
  before it: win one of their fights, earn one of their achievements, or earn enough achievements in
  all. Paths cross themes where one idea needs another: Python and C wait for shell scripts, loops and
  logic, and SQL waits for the text tools. Commands alone no longer open lessons. The lessons you
  already opened stay open, and a lesson from a skill you don't learn never blocks you.
- A new Logic lesson explains how a program decides: yes or no answers, `if`, `!` (not), `&&` (and)
  and `||` (or). Two new fights put it into practice: the Negation Gnome turns a party door's guard
  around, and the Coin Wraith, heads or tails, makes a backup script copy when only half of what it
  needs is there. The Sage Owl teaches it on the adventure's Logic road too, with a chest to open and
  new questions.
- Three new lessons fill gaps at the start of the path. "Help yourself" shows how to read `--help`,
  `man` and an error message, so you're never stuck for long. "Editing a file in the terminal"
  teaches nano or vi: Bashou asks which one when you start (`bashou config editor` changes it), and
  the hints of the fights where you fix a file show that editor's keys. "Patterns" is a gentle first
  taste of regular expressions, just what `awk` and `sed` need next.
- Logic now comes before quotes and scripts, since scripts are full of `if` and `&&`, and git comes
  after scripts.
- The first time you open a lesson, the Sage Owl warms you up with two questions about the lessons
  just before it, with the explanation either way. Esc skips it.
- Five new first fights for the start of the path, each with its lesson: the Flag Phantom makes you
  find the option that ignores capitals in `sort --help`, the Typo Troll leaves a typo to fix in your
  editor, the Clutter Critter scatters photos and documents to tidy into folders with `mkdir` and `mv`,
  the Glob Goblin piles up reports to remove with one wildcard (and only the right ones), and the Core
  Counter asks how many processors your computer has (`nproc`). On the adventure, the Sage Owl teaches
  "Files and editing" and "Help and wildcards" on the road, each followed by a chest, and new questions
  join the quiz.
- A lesson also opens the ones after it when you use its command and it works: once for the lessons
  many others wait for (like `man` for "Help yourself", `nano` or `vi` for the editor, `mv` for files),
  three times for the others: `grep`, `find`, `tar`, `git`, `chmod`, `ps`, `gcc`, `dig` and many more.
  A command counts inside a pipe too (`cat app.log | grep error | sort` counts for grep and sort), as
  long as the whole line works. The Sage Owl lists these commands among the ways to pass a lesson.
- Five new shell fights, one for each lesson they practise: the Stderr Stalker hides error lines among
  normal ones until you catch them with `2>`, the Space Sprite slips a space into a file name (quotes
  save you), the Shebang Shade breaks a script's first line and its right to run, the Rename Rat
  needs a `for` loop to rename every photo, and the Pattern Pixie mixes fake parcel codes that only a
  precise `grep -E` pattern sees through. On the adventure, the Sage Owl teaches "Streams and scripts"
  on the road, with a chest, and new questions join the quiz.
- Six new Linux fights: the Group Gremlin asks which group you belong to (`id`), the Padlock Pest
  mixes up the rights of two files, the Bloat Blob fills folders until only `du` tells which one is
  the biggest, the Tar Tortoise sits on an archive to unpack into the right folder, the Unit Imp
  swaps two lines of a service's unit file, and the Header Hound guards a web server that only
  `curl -I` gets the size from.
- Three new git fights, each in its own small repository: the Commit Crowd wants into your next
  commit (only one file should go), the Branch Bramble grows an idea that belongs on a branch, and the
  Conflict Chimera leaves a merge stopped on a conflict for you to settle.
- On the adventure, the Sage Owl teaches "Rights, disk and archives", "Services and unit files" and
  "git: commits, branches, merges" on the road, each with a chest, and new questions join the quiz.

## v0.6.5 — 2026-09-29

- C fights no longer refuse a correct fix at random. On some systems (gcc 12, as on Debian 12, with a
  recent kernel, WSL included), a program built with AddressSanitizer could freeze when it started,
  about one time in three, and the check gave up. Bashou now runs your program with address
  randomization turned off, which prevents that. Where that isn't allowed, it builds without the
  sanitizer, and the two memory fights that need it wait for a system that can run them.
- A save damaged inside (one wrong byte on disk, or a hand edit) no longer makes your pet crash over
  and over. The damaged entry is dropped and everything else in your save is kept. If the starter
  itself can't be read, Bashou asks you to choose it again.
  A setting damaged the same way (a bubble range that isn't one) is set back to its default too.
- Your pet's tips follow a path now. Each family's achievements lead one to the next (`grep -r`, then
  `grep -E`, then `grep -C`), and your pet suggests the next one on the path, the same one until you
  earn it, instead of a random easy one each time.
- The pet board, the library and the first-launch screens fit a narrow (portrait) terminal: the
  board shows fewer pets per row, and the keys (q: quit…) go on their own line instead of being cut off.
- In the adventure, your pet stays in view when a monster, a boss or a chest asks you something: the
  question box sits between you and what you meet, instead of hiding your pet. On an 80×24 terminal
  your pet is drawn smaller so everything fits.
- In the adventure, the paths at a fork keep the same thickness all along, instead of jumping
  between one and two pixels from line to line.
- The adventure looks right in a tall, narrow (portrait) terminal. The status line at the bottom was
  cut off, hiding your chapter, hearts and meters: when it doesn't fit, it now takes two lines. And
  between forks your pet walked under an empty sky: a road now runs ahead of it to the horizon, and
  what waits for you comes down that road.
- For contributors: the code was reworked toward a data-driven program. The save, the commands, the
  achievement chains, the skills and the settings are each described in one place, instead of several
  copies that had to agree. That removes a whole kind of bug, where one copy was updated and another
  was not.

## v0.6.4 — 2026-09-28

- The Pebble's last evolution, at level 20, really changes your pet now: the Jade golem was only a
  green Crystal golem, so it said it was evolving and looked the same. It's now a carved jade pendant
  with a grinning face, hanging from its cord.
- Stars now count forms: one star per form, filled up to the one your pet has reached (★★☆ for a Bat,
  ★★★★★★★☆☆☆ for a Packet at its 7th form). The pet screen and the board used to disagree, and pets with
  many forms stopped saying what comes next after their third.
- The Hacker cat stays once a secret brings it. It used to leave at every load, then say "New pet:
  Hacker cat!" again after each command. Its picture also shows on the pet screen now.
- Two pairs of achievements shared a name inside the game, so earning one counted as both: the Snail's
  and the Spark's **Scholar**, and the Axolotl's and a secret **Mapper**. Using `jq 'map(...)'` could
  bring the secret Hacker cat without finding any secret. Each now counts on its own. A Hacker cat you
  already have stays.
- For contributors: a new pet, or a new form, is now only JSON files. Each pet has a family file (name,
  place on the board, how it's unlocked, what it says), and each form names the form it evolves into and
  what it takes. The tests check every pet from these files (see `doc/contributing/pixel-art.md`).

## v0.6.3 — 2026-09-28

- If you installed the apt or dnf package but your `~/.bashrc` still loaded an old git copy of Bashou,
  your terminal kept running that old copy, which the package manager never updates (so `bashou share`
  was missing, for example). Now the package moves those terminals to itself when they open. It works
  in every terminal on Fedora and Rocky, and in login shells on Debian and Ubuntu. `bashou update` in
  a git copy also updates it again, instead of offering the package you already have. If a terminal
  still shows an old version, run `bashou update --version v0.6.3` once, then open a new terminal.
- The pet and its speech bubble no longer hide or eat lines of text. Before, they were drawn over the
  top of the screen, and when you scrolled up, a long output like `--help` had holes where they had
  been. Now Bashou moves those top lines up (where scrolling finds them, untouched) before drawing the
  pet, and removes the empty space again when your next command starts. Terminals that can't say
  where the cursor is keep the old behavior. The fight panel in the arena makes room the same way, and
  pressing Enter on an empty line no longer stacks copies of the pet one under the other.
- In a terminal opened before this update, the pet can't make room yet: it tells you once to open a
  new terminal (or type `exec bash`) instead of drawing over your text.
- The Bat's night achievement is now called **Night shift** (it was "Night owl", and players looked for
  an Owl to unlock). Every achievement note now says which pet family it grows: "🏆 Night shift (Bat
  family): …".
- A shorter `bashou --help`, with one command per job:
  - `bashou explain` is gone: the lessons explain the same things better, with drawings. In a code,
    Rust or network fight, type `lesson` to open the one that explains it.
  - `bashou on` also does what `bashou setup` did: after installing the apt or dnf package, `bashou on`
    adds Bashou to your `~/.bashrc`.
  - The language and the skills live in `bashou config`: `bashou config language` (or
    `bashou config language fr`), `bashou config skills`. `bashou config list` shows them too.
  - The old names (`bashou setup`, `bashou language`, `bashou skills`) still work.
- The IPv4 addresses lesson mentions `ipcalc`, which does the network math in one command.
- **`bashou arena`**: come and fight when you want, without waiting for a threat. Pick a timed
  fight (hearts and a clock shown in the prompt: 5, 8 or 12 minutes by level) or a security
  investigation (no clock). Lose, run out of time or flee, and the arena closes for an hour;
  threats your pet announces can still be fought with `bashou fight`. The security investigations
  moved here: `bashou arena security 3` (the old `bashou security` leads there too).
- `bashou help` (and `bashou --help`) lists the commands by what they're for: your pet, learn, play,
  settings. In French too.
- `bashou learn` is easier on the eye: the command in color (commands, options, arguments and
  operators each in their own color), then each command as a numbered step with one line per option
  (`-czf` becomes `-c`, `-z`, `-f`), in normal text instead of grey.
- `bashou learn` now knows grep's `-v`, `-i`, `-l`, `-c`, `-o`, `-w` and `-F`, and after
  `find … -exec grep -l …` the `-l` is grep's, not find's.

## v0.6.2 — 2026-09-26

- `bashou share` asks for a nickname the first time and puts it on every card, so the banner never
  needs your real name (`bashou share --name` changes it).
- The banner also shows your starter at its latest form, and speaks English or French: it follows your
  browser's language, and two buttons switch it before you share.
- The Ember is redrawn cleaner: a symmetric flame on a smooth bed of charcoal.
- The README shows a sample banner and says it plainly: Bashou collects nothing, you are not the
  product.
- Each release now carries its `.deb` and `.rpm` with signed checksums and a build provenance
  attestation, so you can check a download came from this repository (see the guide).

## v0.6.1 — 2026-09-25

- The Ember lost the stray pixel floating at its top right.

## v0.6.0 — 2026-09-25

- **New skill: Network.** Tick it in `bashou skills` to learn IPv4, IPv6, DNS and TCP with real tools.
  - Six lessons in the Sage Owl's library, from what `192.168.1.20/24` means to a troubleshooting
    ladder that goes from the cable up to the application, one command per step.
  - Ten fights against network creatures: find the port a listener hides on with `ss`, your own address
    and route with `ip`, which hosts sit in a /22, what `getent` returns against DNS, and, in saved
    captures read with `tcpdump -r`, the handshake that never finished, the refused connection and the
    name that got NXDOMAIN. Their little servers listen on 127.0.0.1 or ::1 only: nothing leaves your
    machine. On the adventure road, a new chest opens with `ss` on IPv6.
  - 37 adventure questions in a new topic, guarded by the Latency Kraken.
- **New pet: the Packet**, from a single Bit to a Constellation of satellites, in ten forms. It comes
  after ten uses of `ip`, `ss`, `ping`, `getent` and friends, and grows with twelve network achievements.
- The Rocky Linux path starts gentler: level 1 asks about installing, removing, searching and updating
  with `dnf`, and SELinux, EPEL and automatic updates come at level 2, once the basics are known.
- **New: `bashou share`.** It shows a QR code; scan it and your phone draws a banner of your pet, level
  and progress, with a Share button for Signal, WhatsApp or any app. Before the QR code, it lists
  exactly what the card contains. The data travels in the link after the `#`, which browsers never
  send to a server, and `--name` adds a short nickname if you want one.
- `bashou learn` now explains `ip`, `ss`, `ping`, `getent`, `host`, `resolvectl`, `tracepath`,
  `traceroute`, `nc` and `tcpdump`, and `bashou explain network` has notes on CIDR, IPv6, DNS and TCP.
- On Rocky, Fedora and Red Hat, `bashou update` now runs `sudo dnf upgrade --refresh bashou`: plain
  `dnf upgrade` could say "Nothing to do" for two days after a release, because dnf keeps its list of
  packages that long. The Bashou repository file now asks dnf to check it every 6 hours.

## v0.5.0 — 2026-09-25

- **New: `bashou lesson`, the Sage Owl's library.** Hints tell you what to type; lessons show how things
  work. Each lesson is a few short pages with a drawing that grows from one page to the next, and the owl
  points its wing at what matters: how the shell reads a command line, what the CPU and the RAM do, the
  file tree, stdout and stderr, pipes step by step, permissions, processes and signals, packages and
  their signatures, systemd services, how gcc compiles a program, the stack and the heap in C, pointers and strings, Python names, Rust variables, SQL joins,
  public and private keys, CI pipelines. Lessons unlock with your fights and achievements, each one
  preparing your next step, and the locked ones tell you what opens them. The lessons that make you
  progress now are green; once your fights and achievements show you've mastered one, it turns white.
  Your pet mentions it when a new one is waiting.
- **A new pet: the Spark, born from the library.** Fire, for the Library of Alexandria that burned and for
  the books still destroyed today: what you learn, nobody can burn. Read a lesson to the end and a few
  Sparklings twinkle next to you. They grow with each lesson achievement (read 3, 6, 12 and 20 lessons,
  master 1, 5 and 10, three skills) through Spark, Ember, Candle, Lantern, Torch, Campfire, Beacon and
  Blaze, and become a Phoenix when you've read every lesson of your skills. Learning only one skill? The
  counts stop at what your skills offer, so the Phoenix stays within reach.
- **Fifteen short lessons for the basics**, each building on the one before: files (mkdir, cp, mv, rm),
  reading files (cat, less, head, tail -f), wildcards, shell variables, quotes, grep, users and sudo, disk
  space, archives with tar, your first script, loops, addresses and ports, git snapshots and branches,
  your first Python script and your first SQL SELECT. Every lesson is in French too.
- **gcc and gdb get their own fights and lessons.** Four new C fights: the Linker lynx (a program in two
  files), the Warning wraith (a bug only `-Wall` shows), the Segfault salamander (find the crashing line
  with gdb's backtrace) and the Breakpoint beetle (stop a loop at the right month with a conditional
  breakpoint). Two library lessons, "Using gcc" and "Debugging with gdb", a Sage Owl road lesson and a gdb
  chest, 8 new C questions, and `bashou explain c link`, `warnings` and `gdb`.
- **Modern tools where it helps**: the compilation lesson now shows clang, sanitizers, clang-tidy and
  cargo/go, the gcc lesson CMake, Meson and Ninja, the gdb lesson lldb, rr and editor debuggers.
- **Every fight now has a lesson.** Eight new lessons fill the gaps: wc, sort, cut and uniq; awk and sed;
  find; Python loops, dicts and recursion; reading JSON, base64 and %XX safely in Python; package
  repositories on Debian and Rocky; SQL CREATE, INSERT, UPDATE and upsert; and pass. As soon as you meet a
  fight, its lesson opens, and typing `lesson` in the arena reads it without leaving the fight.

## v0.4.3 — 2026-09-24

- The Seedling is now a little seed with one shoot, so you can tell it apart from the Sprout.
- A speech bubble closes as soon as you run the command it suggests (`bashou fight`,
  `bashou evolve`…), and never stays more than 3 minutes.
- **A new pet: the Snow leopard.** A shy cat that keeps secrets: use gpg or pass 5 times and the Snow cub
  joins you, then grows into a Snow leopard and a Mountain ghost as you encrypt files, make a key, start a
  password store and hand passwords to commands with `$(pass show …)`. No gpg or pass yet? Your pet tells
  you how to install them.
- **Two new Slime forms.** At 3,500 commands your Slime freezes into an Ice slime, a little crystal
  cluster, and at 7,500 it becomes a Thunder slime, a grumpy storm cloud. A Cat or King slime you
  already have stays what it is.
- **A new pet: the Duck.** Debug like a programmer with a rubber duck: explain a command with
  `bashou learn`, trace a script with `bash -x`, check it with `bash -n` or read `echo $?`, and a
  Duckling waddles in. Each new habit brings a new form: a Duck, a White duck, and at last a Mandarin
  duck (with `shellcheck` too, if you have it).
- **Learn SQL with SQLite.** A new skill and adventure path: the Sage Owl explains databases, SELECT,
  JOIN, CREATE TABLE, INSERT, UPDATE (always with a WHERE) and INSERT … ON CONFLICT DO UPDATE, with a
  chest to open and 22 questions. Six new threats hand you a database to query or fix, from the Query
  Quokka to the Upsert Unicorn. SQLite keeps a whole database in one file, so nothing is left behind:
  delete the file and it's gone. No sqlite3 yet? Your pet tells you how to install it.
- **Keep secrets with gpg and pass.** The Sage Owl explains locking files, key pairs, signatures and
  the pass password store, with a chest to open and 6 new Linux questions. Five new threats: lock a file
  (Plaintext Pixie), open one (Cipher Crow), tell a genuine download from a forged one with gpgv (Forger
  Ferret), read a password store (Vault Vole) and take a password out of a script with
  `$(pass show …)` (Cleartext Cricket). The fights bring their own practice key and store: your keys
  and passwords are never touched. In fights, gpg now asks for passphrases right in the terminal.
- **`bashou update` helps you move to apt or dnf.** On a git install on Debian, Ubuntu or the Red Hat
  family, it offers once to switch to Bashou's signed repository: it shows every command first (key,
  repository file, install), asks, runs them in front of you and updates your `~/.bashrc` (with a backup).
  Later: `bashou update --packages`. On a package install, it shows the apt or dnf command and offers
  to run it. The README now shows the apt and dnf install first.
- **What you type stays private.** Bashou's folders were readable by other accounts on systems where
  home folders are (Debian's default): they are now yours only, and existing ones are tightened. Events
  left by terminals that closed badly are removed. `.github/SECURITY.md` lists everything Bashou writes.
- On Rocky, Alma and RHEL, the Process Phantom could not be found (its name got lost), so that fight
  couldn't be won. It shows up in `ps` again.
- The Leak Lurker and the Fencepost Fiend only come where gcc can use AddressSanitizer: without it, their
  bug was invisible and the fight was won before it started.
- CI now also runs every test on Rocky Linux 9, and installs the .rpm there.
- Pets and fights no longer slow down when many tools are missing (on WSL, looking for a missing
  command searched every Windows folder).

## v0.4.2 — 2026-09-23

- **Install with apt or dnf.** Bashou now has its own signed repositories for Debian, Ubuntu, Rocky,
  Alma, RHEL and Fedora: add the repository once, then `apt install bashou` or `dnf install bashou`,
  and updates come with the rest of the system. Each user who wants a pet runs `bashou setup`.
- **Choose what you learn.** At the first launch, pick a bit of everything or tick your skills
  (Bash, Linux, systemd, Debian, Rocky, Python, C, Rust, Logic, CI/CD): threats and adventure paths
  follow. `bashou skills` changes it any time.
- `bashou config` asks you a few questions and saves the answers (bubble length, pet size, how often
  your pet talks, updates, skills, language). `bashou config list` still lists everything.
- **Learn to read `--help`.** For your first 5 wins, a fight's first hint shows how to ask the tool
  itself (`wc --help`), how to read the Usage line and the options, and what to look for this time.
  `--help` and `man` are free moves in a duel.
- Bashou no longer runs a `bashou` folder found in the directory you're in instead of its own code.
- **Your progress is safer.** If your save gets damaged, Bashou keeps it aside
  (`state.json.broken-…`) and brings back the last good copy (it keeps one a day) instead of
  crashing or starting over. Saves from every earlier version still load.
- Very old installs (from before 0.1.0) whose `bashou update` stops with "Not possible to
  fast-forward" can't update themselves. Move them to this release once:
  `git -C ~/.bashou fetch --tags && git -C ~/.bashou checkout v0.4.2`. Your progress is kept.
- The starter screen no longer shows a line of question marks under each starter.
- **`verify` or `answer`, never both.** Fights and chests where you do the job (fix a file, make a
  folder…) end with `verify`: Bashou checks your work. Those that ask a question end with
  `answer <value>`. Each screen shows only the one that applies, and typing a command after `answer`
  tells you to run it at the prompt instead.
- After an update, your save is upgraded to the new format on disk, and a copy of the old one is
  kept next to it.
- **Adventure answers that teach.** After each question, the right answer now stands on its own line,
  followed by a real explanation in plain words: why it's right, what the tempting wrong answer
  does, and what to do next. All the questions, in English and French; many questions also give
  more context.
- **Why sort comes before uniq.** uniq only merges identical lines that follow each other, so
  `cut … | uniq -c` counted the same city several times. The Sage Owl's pipe lesson now says so, the
  cities chest explains it in its hints, and the arena tells you once when you run uniq without sort.
- **sort, taught at last.** The Sage Owl has a new lesson on sort (alphabetical, -n for numbers,
  -rn | head for a top list, and why sort comes before uniq), two chests to practice it, and new
  questions on sort and uniq.
- The Slug has a new look: olive green, big eyes on stalks, pink cheeks and a smile.
- During a boss fight, the pet no longer flashes under the question box.
- Moving on the swap board no longer leaves pieces of text behind.
- **CI/CD fights.** Five new threats hand you a pipeline file to fix: a GitHub Actions workflow with a
  line indented wrong (Indent Imp), a token written in clear (Secret Sprite), a deploy that neither
  waits for the tests nor stays on main (Needs Newt); a .gitlab-ci.yml with a stage that doesn't
  exist (Stage Specter) or a production deploy that should wait for a click (Manual Mole). The
  Sage Owl teaches pipeline files on the CI/CD path, with a chest to practice, and six new CI/CD
  questions go with them.
- **The road splits.** At a fork, the road now divides in front of your pet into two or three paths
  fading into the distance, each with its name written at its end; the one you pick lights up.

## v0.4.1 — 2026-09-23

- **Beaten fights come back, so you keep what you learned.** A fight you win returns the next day,
  then 7 days later, then 30 days later; win that one and the tool is acquired. Your pet says when a
  threat is a review, and a lost review starts over the next day. Fights you had already won are
  spread over the coming days. The guide explains why (spaced repetition).
- **Rust fights**, where `rustc` is installed: a counter that isn't `mut`, a `const` without its
  type, text that should become a number (shadowing, since `mut` can't change a type), and a `u8`
  total that overflows. Each file says what it must print and how to build it (`rustc counter.rs`).
- `bashou explain rust mut` (or shadowing, const, integers).
- **A Logic path in `bashou adventure`**, for beginners in any language: what a variable holds
  after a few lines, `and` / `or` / `not`, how many times a loop runs, where a counter starts, indexes
  from 0, `return` versus `print`, then loops that never end, off-by-one, short-circuits and De Morgan.
  30 questions and a Paradox Sphinx.
- **Automatic security updates** in the Debian and Rocky questions: turning on unattended-upgrades
  and dnf-automatic, keeping them to security fixes, a dry run, their timers, keeping one package
  out, and what's still left to do after they ran (restarting services, rebooting, going back with
  `dnf history undo`). Rocky gets its first level 3 questions.
- Four new first-level Rust questions in `bashou adventure`: `mut`, shadowing, `const`, overflow.
- Once you have 15 achievements and no Rust yet, your pet sometimes offers to start: it gives the
  install command for your system (`apt`, `dnf`, or rustup, read before you run it).

## v0.4.0 — 2026-09-23

- **Code fights.** Fifteen new threats, in Python and C. Most hand you a small broken file whose
  first lines say what goes in, what should come out and how to run it; fix it, and Bashou runs its
  own tests on your version. The first ones only ask to make the code compile (a missing `:` in
  Python, a missing `;` in C). Then lists, dicts, loops and recursion in Python, and memory, arrays,
  recursion and a buffer overflow in C, checked with AddressSanitizer. Others take a `python3 -c`
  one-liner: read a JSON config, decode base64, decode a URL-encoded attack, read what a JWT says.
  One more asks you to stop a shell injection.
- **Package fights, on your own machine.** On Debian and Ubuntu: which version of a package is
  installed (`apt list --installed`), which version apt would install (`apt search`, `apt policy`),
  which package put a file in /usr/bin (`dpkg -S`), and whether a package is marked manual or auto
  (what `apt autoremove` looks at). On Rocky, Alma, Fedora and Red Hat: the installed version
  (`rpm -q`), which package owns a file (`rpm -qf`), how many packages are installed. Bashou reads
  /etc/os-release and only sends the ones for your system.
- **Repository fights.** Fix a `debian.sources` (or a Rocky `.repo`) with three planted mistakes:
  look the right values up online or in your own /etc. On Red Hat, the Enabled Ettin asks for one
  dnf command limited to a single repository: `--disablerepo='*' --enablerepo=<id>`.
- `python3 -m bashou.creatures show <pet or fight id>` draws a fight's enemy with all its poses.
- `bashou explain python list` (or dict, loop, recursion, json, url, base64, subprocess;
  `bashou explain c malloc`, array, string, recursion, asan) gives a short note with an example,
  offline.
- Opening a text editor in the arena no longer costs a heart.
- The quiz questions of `bashou adventure` were rewritten to teach habits that last in automation
  and security (what goes wrong, what to check first, what an output means) instead of trivia.
  New: a systemd topic about writing units, and level 3 questions for Debian and Linux.
- Your pet waits for a pause in your work before it talks, about every 10 to 20 minutes.
  `bashou config talk` and `bashou config quiet` change that.
- The start and the forks of `bashou adventure` no longer cover the road with a box: the chapter or
  the ways you can go sit on the top line, the keys (Enter, ←/→) on the bottom line.
- Fixed: a question with a `%` in it crashed the adventure.

## v0.3.1 — 2026-09-22

- **Ten new fights, and the easy ones come first.** Your first threats now ask for one command with
  at most one option: count the lines of a file (`wc`), print a column (`cut`), sort names, read the
  end or the start of a file (`tail`, `head`), find someone in a list (`grep`), list a folder (`ls`),
  print one line (`sed -n`). The tool fights (grep, awk, find, uniq, sed, ps) only come once you have
  met their tool, and the Knot Eel's pipeline stays last.
- The first hint of every new fight points at the help: `bashou learn <command>` and `--help`.
- Each new threat has its own look: Line Moth, Column Crab, Jumble Sprite, Last-word Wisp,
  First-line Imp, Needle Gnat, Field Wasp, Dust Bunny, Verse Viper and Peak Harpy.
- `bashou learn` explains `uniq -u` and `uniq -d`, and says that uniq only compares neighbouring
  lines, so you sort first.
- The Sand grain rides a pale blue gust that curls into a spiral, and no longer shows twice when the
  wind catches it mid-breath.
- The Leaf slime is a leaf: veins from the foot of its midrib to the sides, a pointed tip, and it
  breathes out an O2 bubble instead of flapping.

## v0.3.0 — 2026-09-22

- Every starter now has **7 forms** and grows to level 20 (one level per 5 achievements). New shapes
  at levels 3, 5, 8, 11, 15 and 20; what your pet becomes is a surprise, and a form once reached is
  never lost.
- Pets come from what they stand for. Your command count grows a Droplet that changes shape 6 times
  on the way to 10,000 commands, while the other pets come from your first programs, your own
  scripts, walks and right answers in the adventure, and fights won or lost. Pets you already have
  stay yours.
- Secret achievements. Nothing tells you what they are; they show up when they show up, and the
  first one brings a pet that isn't on the board.
- The Slime's old achievements (`$( )`, heredocs…) join the Mushroom, which is about scripting.
- No spoilers: the swap board, the starter choice and `bashou level` show only what you've reached,
  and the level of the next form.
- Sprite fixes: the Droplet, the Orc's tusk and the Snakelet are symmetric again.

## v0.2.3 — 2026-09-22

- Every threat of `bashou fight` has its own look: the Log Hydra, the Ledger Golem, the Maze Wraith,
  the Echo Swarm, the Typo Serpent, the Process Phantom and the Knot Eel.

## v0.2.2 — 2026-09-22

- `bashou version` says which version you have, and if a newer one is out.
- `bashou update` lists what's new, one entry per line.
- Ctrl+L starts the prompt below your pet too, like `clear` does.
- `bashou fight` is a duel: the task, your pet with 3 hearts and the enemy are drawn at the top, where
  your pet lives. A successful command with the fight's tool hits the enemy, which flashes; looking
  around (`ls`, `cat`, `cd`…) is free; any other command, or a failed one, costs a heart and your pet
  flashes red. At 0 hearts you're knocked out and the threat comes back later.
- The adventure no longer crashes when the Sage Owl comes to teach you.

## v0.2.1 — 2026-09-22

- `bashou learn` takes a command apart and explains each piece: the command, every option, the
  arguments, pipes and redirections. With no command, it explains the last one your pet suggested.
- The prompt starts below your pet, at startup and after `clear`, so the first commands' output
  no longer hides under it.
- `bashou update` shows what's new from this changelog, and `bashou update --version v0.2.0`
  installs a given release, older ones too.
- Pets switch to new sprites and translations right after an update.
- Achievements that need a tool stay hidden in tests on machines that have it (fixes the first
  0.2.0 release run).
- In French, the Star line starts as "Poussière", which fits the pet board.

## v0.2.0 — 2026-09-22

### Evolutions
- Every pet now changes shape at each of its 3 stages, with new names: Tadpole → Tree frog → Toad,
  Fennec → Fox → Kitsune, Hatchling → Turtle → Sea turtle, Kit → Beaver → Platypus, and 21 more.
- `bashou evolve` plays the evolution you earned (skip with `s`). In `bashou swap`, `f` shows an
  earlier form of a pet, just for the looks.
- The Kitten starter is now Stardust, which grows into a Planet, then a Star. Saves with the
  Kitten keep their level.
- The tadpole swims instead of breathing, slowly, one stroke at a time.
- `bashou config size large` shows big pixel art where a pet has some: first, a 48-pixel Tarantula.

### New pets and achievements
- Seven new tool pets: Beaver (git), Squirrel (archives), Pigeon (network), Hedgehog (permissions),
  Bee (systemd), Whale (kubectl) and Meerkat (monitoring), with 30 new achievements.
- The Whale only shows up if `kubectl` is installed, and hints and fights only suggest tools you
  have. Adventure questions can still teach tools you don't have yet.
- Pet hints say which achievement they lead to: `(achv: name)`.
- The pet board is more compact and scrolls, so it fits small terminals.

### Languages
- Bashou speaks French: the whole interface, the pets, the achievements and the 166 adventure
  questions (`bashou language`).
- Settings are translated too (`bashou config`).

### Contributing
- Pets, translations and adventure questions are plain JSON files: see `doc/contributing/`.
- The README explains how AI is used in Bashou: to help you learn, not to do it for you.
- Translating with an AI agent: `doc/agents/translation.md` tells it how to work with a native speaker.

## v0.1.0 — 2026-09-22

First release: a pet that lives next to your prompt and grows as you learn bash. Starters, pets
unlocked by commands and tools, achievements, fights in a sandbox, security challenges, an adventure
with bosses and questions, and updates from GitHub releases.
