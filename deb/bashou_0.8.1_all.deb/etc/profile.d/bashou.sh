# Bashou: a ~/.bashrc that loads an old git copy of Bashou gets this package's instead.
if [ -n "${BASH_VERSION:-}" ] && [ -r /usr/share/bashou/bashou/handover.bash ]; then
  case $- in *i*) . /usr/share/bashou/bashou/handover.bash ;; esac
fi
