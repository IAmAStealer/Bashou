# Bashou: the pet in every interactive bash (`bashou off` to hide it), from this package.
if [ -n "${BASH_VERSION:-}" ] && [ -r /usr/share/bashou/bashou/handover.bash ]; then
  case $- in *i*) . /usr/share/bashou/bashou/handover.bash ;; esac
fi
