"""Per-terminal background process: animates the pet, counts commands, shows speech bubbles.

Started by bashou.bash as `python3 launch.py bashou.companion <shell pid>` with stdout on the terminal.
"""

import datetime
import json
import os
import random
import re
import signal
import sys
import threading
import time
from pathlib import Path

from . import creatures, dialogue, fight, i18n, learn, pony, procs, progress, render, state, update
from .behavior import Behavior
from .analyze import parse_log
from .i18n import _
from .render import ESC

TICK = 0.25
FIRST_TALK = (3, 8)         # minutes before the first spontaneous line
SOURCE = Path(__file__).resolve().parent


def code_version():
    """Newest mtime of our code and data (sprites, translations): it changes on an update or an edit."""
    return max(p.stat().st_mtime for pattern in ("*.py", "*.json") for p in SOURCE.rglob(pattern))


def now_ms():
    return int(time.time() * 1000)


BUBBLE_MS = 3 * 60_000     # a bubble never stays longer, however few commands you run
REMIND_MS = 30 * 60_000    # a waiting threat's warning comes back this often (owner, 2026-10-20)
UPDATE_REMIND_MS = 2 * 3600_000   # a new release's bubble comes back this often, in every terminal (owner, 2026-10-22)
BUBBLE_ROWS = 7            # a bubble of 4 lines covers the top 7 rows (see frame)


def answers(text, command):
    """The bubble says `→ bashou fight`, `bashou evolve`…: running that command is its answer."""
    words = command.split()
    return (len(words) > 1 and os.path.basename(words[0]) == "bashou"
            and re.search(rf"\bbashou {re.escape(words[1])}\b", text) is not None)


class Companion:
    def __init__(self, shell):
        self.shell = shell
        self.events = state.DATA / f"events.{shell}"
        self.erase_file = state.CACHE / f"erase.{shell}"
        self.resume_file = state.CACHE / f"resume.{shell}"
        self.height_file = state.CACHE / f"height.{shell}"     # lines the pet covers, for the loader
        self.room_file = state.CACHE / f"room.{shell}"         # 1 once the loader emptied those lines
        self.fight_file = state.CACHE / f"fight.{shell}"       # the Honey badger's fight: the loader opens it
        self.height = None
        # A terminal opened before this version runs the old loader, which never writes the room file
        # (the pet updates itself, open shells don't): there the pet draws as it always did. The new
        # loader writes the file before starting the pet.
        self.managed = self.room_file.exists()
        self.old_loader_told = False
        self.offset = 0            # bytes of the events file already counted
        self.guests = {}           # the same for other terminals' guest.<pid> files, by name
        self.left = False          # `bashou here` moved the pet to another terminal
        self.code = code_version()
        self.notes = []            # notifications waiting for the bubble
        self.bubble = None         # (text, commands run since shown, commands it stays)
        self.bubble_at = now_ms()  # when it was shown
        self.drawn = None          # (erase sequence of what is on screen)
        self.last_key = None
        self.tick = 0
        self.busy = True
        self.state_mtime = 0
        sprite, self.voice = progress.current(state.load())[::3]
        self.sprite, self.size = sprite, "small"
        self.pet = creatures.get(sprite)
        self.cells = render.mask(self.pet)
        self.stage = 1
        self.look = 1
        self.threat = False
        self.threat_text = self.threat_id = None     # the waiting threat's announcement
        self.threat_until = 0.0
        self.threat_said = 0           # when its warning was last queued (ms)
        self.update_tag = ""           # a release out and not installed (from the state file)
        self.update_said = 0           # when its bubble was last queued (ms): 0, so a new terminal says it
        self.fights_won = self.fights_lost = 0
        self.behavior = Behavior(now=now_ms())
        self.last_command = now_ms()
        self.talk_at = now_ms() + random.randint(*FIRST_TALK) * 60_000
        self.warn_at = 0
        self.resume()
        if not self.managed and not self.old_loader_told:
            self.announce(_("This terminal was opened before my last update, so I may draw over your text. "
                            "Type exec bash (or open a new terminal) to load the new version."))
            self.old_loader_told = True

    # --- shell ------------------------------------------------------------

    def alive(self):
        try:
            os.kill(self.shell, 0)
            return True
        except OSError:
            return False

    def at_prompt(self):
        """True when the shell itself owns the terminal (no command running)."""
        return procs.at_prompt(self.shell)

    # --- events -----------------------------------------------------------

    def home(self):
        """True when this is the pet of all terminals (bashou.bash writes its shell in the pet file)."""
        try:
            return int((state.CACHE / "pet").read_text()) == self.shell
        except (OSError, ValueError):
            return False

    def guest_files(self):
        return sorted(state.DATA.glob("guest.*")) if self.home() else []

    def moved(self):
        """True when another open terminal took the pet (`bashou here`)."""
        try:
            pid = int((state.CACHE / "pet").read_text())
        except (OSError, ValueError):
            return False
        return pid != self.shell and pid_alive(pid)

    def leave(self):
        """Count this terminal's last commands, take the drawing down and stop: the shell becomes a guest
        at its next prompt."""
        self.read_events()
        if self.drawn:
            os.write(1, (ESC + "7" + self.drawn + ESC + "8").encode())
            self.drawn = None
        self.left = True

    def read_file(self, path, offset):
        """(new offset, text of the whole lines written after offset)."""
        try:
            with open(path, "rb") as f:
                f.seek(offset)
                data = f.read()
        except FileNotFoundError:
            return offset, ""
        end = data.rfind(b"\n") + 1
        return offset + end, data[:end].decode(errors="replace")

    def read_events(self):
        self.offset, text = self.read_file(self.events, self.offset)
        # Commands typed in the terminals without a pet count too. A closed one's file goes once read, and
        # so does this terminal's own, from when it was a guest.
        before, counted = dict(self.guests), None
        for path in self.guest_files():
            if path.name not in self.guests:
                # A pet that just moved here starts where the old one stopped: no command counted twice.
                counted = counted if counted is not None else read_guest_offsets()
                self.guests[path.name] = counted.get(path.name, 0)
            gone = not pid_alive(path.suffix[1:]) or path.suffix[1:] == str(self.shell)
            self.guests[path.name], more = self.read_file(path, self.guests[path.name])
            text += more
            if gone:
                path.unlink(missing_ok=True)
                del self.guests[path.name]
        if self.guests != before:
            write_guest_offsets(self.guests)
        records = parse_log(text)
        if not records:
            return
        now = datetime.datetime.now()
        with state.locked() as s:
            for status, command in records:
                if self.bubble and answers(self.bubble[0], command):
                    self.bubble = None
                elif self.bubble:
                    self.bubble = (self.bubble[0], self.bubble[1] + 1, self.bubble[2])
                self.notes += progress.record(s, status, command, now.date().isoformat(), now.hour)
                came = pony.joke(s, command)            # cowsay, apt moo, :wq…: a hidden pony comes
                if came:
                    self.say_now(came[0])
                    self.notes += came[1:]
                elif status == 127:
                    self.laugh_at_typo(s, command)
                self.warn_risky(command)

    def events_size(self):
        try:
            return self.events.stat().st_size + sum(f.stat().st_size for f in self.guest_files())
        except FileNotFoundError:
            return 0

    def reload_pet(self):
        try:
            mtime = state.STATE.stat().st_mtime
        except FileNotFoundError:
            return
        if mtime == self.state_mtime and not (self.threat and time.time() > self.threat_until):
            return                     # (a threat that timed out doesn't touch the state file)
        self.state_mtime = mtime
        i18n.use(None)                 # `bashou config language` may have changed it
        s = state.load()
        sprite, stage, name, self.voice = progress.current(s)
        self.sprite, self.size = sprite, state.setting(s, "size")
        self.stage = self.behavior.stage = stage
        self.look = progress.look(s)           # the form drawn; the actions follow `stage`
        threat = fight.active_threat(s)
        if self.threat and not threat:
            self.threat_ended(s)
        self.threat = bool(threat)
        if threat:
            text = fight.announcement(s)
            if (threat["challenge"] != self.threat_id or text != self.threat_text) and text:
                self.announce(text)    # every terminal says it: a lone ⚠ explained nothing
            self.threat_text, self.threat_id, self.threat_until = text, threat["challenge"], threat["until"]
        self.fights_won, self.fights_lost = s["fights_won"], s.get("fights_lost", 0)

    def threat_ended(self, s):
        """Take the announcement down: it stayed up long after the threat was gone (commands over ssh
        don't count here). Unless you just fought it, the pet tells you it left."""
        text = self.threat_text or "\0"
        if self.bubble and text in self.bubble[0]:
            self.bubble = None
        self.notes = [n for n in self.notes if text not in n]
        if s["fights_won"] <= self.fights_won and s.get("fights_lost", 0) <= self.fights_lost:
            self.say_now(f"{_(creatures.FAMILIES[self.voice].voice)} {fight.gone(self.threat_id)}")
        self.threat_text = self.threat_id = None

    def announce(self, text):
        if text not in self.notes and not (self.bubble and text in self.bubble[0]):
            self.notes.append(text)
        self.threat_said = now_ms()

    def remind_threat(self, ms):
        """The ⚠ bubble goes after a few commands; the threat waits till midnight: say it again now and then."""
        if self.threat and self.threat_text and ms - self.threat_said > REMIND_MS \
                and not self.notes and not self.bubble:
            self.announce(self.threat_text)

    def see_update(self):
        """The release the daily check found (any terminal may have run it), unless updates are off."""
        s = state.load()
        self.update_tag = s["update_available"] if state.setting(s, "updates") == "on" else ""

    def remind_update(self, ms):
        """The daily check said it in one terminal, once: say it in every terminal, and again every few hours."""
        if self.update_tag and ms - self.update_said > UPDATE_REMIND_MS and not self.notes and not self.bubble:
            self.notes.append(update.note(self.update_tag))
            self.update_said = ms

    def last_activity(self):
        """Last command, or last key typed: the kernel updates the terminal's atime on input."""
        try:
            typed = int(os.fstat(1).st_atime * 1000)
        except OSError:
            typed = 0
        return max(self.last_command, typed)

    def laugh_at_typo(self, s, command):
        """`command not found`: a kind joke with the fix, every time, shown right away."""
        line = dialogue.typo(s, self.voice, command)
        if line:
            self.say_now(line)

    def warn_risky(self, command):
        """`curl … | sh`, `chmod 777`…: a safety warning, shown right away (at most once every 5 minutes)."""
        ms = now_ms()
        if ms < self.warn_at:
            return
        line = dialogue.risky(self.voice, command)
        if line:
            self.warn_at = ms + 5 * 60_000
            self.say_now(line)

    def say_now(self, line):
        """Replace the bubble right away (the old one is dropped, not queued behind)."""
        self.notes.insert(0, line)
        self.bubble = None

    def maybe_talk(self, ms):
        """Now and then at the prompt the pet says something, and only once you have stopped typing:
        it waits for a pause instead of cutting into your work (owner). `bashou config talk` sets how
        often (or `off`), `bashou config quiet` how long a pause it waits for. Whoever wants more can
        go and get it: `bashou talk`, `bashou adventure`."""
        if ms < self.talk_at or self.notes or self.bubble or self.behavior.mood == "sleep":
            return
        s = state.load()
        every = state.setting(s, "talk")
        if every == "off":                              # `bashou config talk off`: it keeps quiet
            self.talk_at = ms + 10 * 60_000
            return
        quiet = state.setting(s, "quiet")[0] * 1000
        if ms - self.last_activity() < quiet:
            self.talk_at = ms + quiet                   # still working: ask again after the next pause
            return
        self.talk_at = ms + random.randint(*every) * 60_000
        said = dialogue.line(s, self.voice)
        learn.remember(said)
        self.notes.append(said)

    def check_update(self):
        """Once a day, in the background (git may take a while): a bubble if a new version is out."""
        try:
            if update.due():
                note = update.check()
                if note:
                    self.notes.append(note)
                    self.update_said = now_ms()
        except Exception:
            log_error()

    def check_threat(self):
        with state.locked() as s:
            note = fight.maybe_threat(s)
            badger = not note and fight.badger_fight(s, now_ms() - self.last_activity())
        if badger:
            try:
                self.fight_file.write_text("1\n")
            except OSError:
                pass
        if note or badger:
            self.state_mtime = 0           # reload_pet() announces it and blinks the ⚠

    # --- drawing ----------------------------------------------------------

    def frame(self, ms, poses, z, cols):
        """Escape sequence for one frame, and the sequence that erases it."""
        pet = self.pet
        x = cols - pet.width
        out = [f"{ESC}[{i + 1};{x}H{line}" for i, line in enumerate(render.lines(pet, poses, self.cells, self.look))]
        zr, zc = pet.z_at
        out.append(f"{ESC}[{zr + 1};{x + zc}H{ESC}[38;2;150;190;230m{z:<3}{ESC}[0m")
        erase = render.erase(self.cells, 1, x)

        if self.bubble:
            lines, bw = render.bubble(self.bubble[0], x - 2)
            bx = x - bw
            if bx >= 1:
                out.append(f"{ESC}[1;{bx}H" + " " * bw)     # a scrolled-up copy of the top border
                for i, line in enumerate(lines):
                    out.append(f"{ESC}[{i + 2};{bx}H{ESC}[38;2;150;190;230m{line}{ESC}[0m")
                erase += render.erase([[True] * bw] * (len(lines) + 1), 1, bx)
        return "".join(out), erase

    def update_bubble(self):
        """A bubble stays for a few commands (`bashou config bubble`), 2 at most when another note waits,
        and 3 minutes at most."""
        if self.bubble:
            text, shown, stays = self.bubble
            if shown >= (min(stays, 2) if self.notes else stays) or now_ms() - self.bubble_at > BUBBLE_MS:
                self.bubble = None
        if not self.bubble and self.notes:
            self.bubble = (self.notes.pop(0), 0, random.randint(*state.setting(state.load(), "bubble")))
            self.bubble_at = now_ms()

    def fit(self, cols):
        """The large sprite when asked for and the terminal has room for it, else the small one."""
        pet = creatures.get(self.sprite, self.size)
        if cols < pet.width + 20:
            pet = creatures.get(self.sprite)
        if pet is not self.pet:
            self.pet = pet
            self.cells = render.mask(pet)
        height = max(len(pet.base) // 2, BUBBLE_ROWS)
        if height != self.height:
            try:
                self.height_file.write_text(str(height))
                self.height = height
            except OSError:
                pass

    def room(self):
        """The loader emptied the top rows for this prompt (bashou.bash, _bashou_make_room)."""
        try:
            room = self.room_file.read_text().strip() == "1"
        except OSError:
            return not self.managed
        self.managed = True
        return room

    def draw(self, ms):
        self.update_bubble()

        cols = os.get_terminal_size(1).columns
        self.fit(cols)
        if cols < self.pet.width + 20 or not self.room():
            return
        poses, z = self.behavior.frame(ms, self.pet, self.threat, ms - self.last_activity())
        key = (tuple(poses), z, cols, self.bubble and self.bubble[0], self.pet.id, self.pet.width, self.look)
        if key == self.last_key and self.tick % 8:
            return
        self.last_key = key

        body, erase = self.frame(ms, poses, z, cols)
        out = ESC + "7"
        if self.drawn and self.drawn != erase:
            out += self.drawn          # the pet moved or the bubble closed
        out += body + ESC + "8"
        os.write(1, out.encode())
        if erase != self.drawn:
            self.drawn = erase
            self.erase_file.write_text(ESC + "7" + erase + ESC + "8")

    # --- main loop --------------------------------------------------------

    def step(self):
        if self.tick % 4 == 0 and self.moved():
            self.leave()
            return
        if not self.at_prompt():
            self.busy = True
            return
        # A new event (or the prompt's SIGUSR1) means a command ran and PS0 erased us.
        if self.events_size() != self.offset + sum(self.guests.values()):
            self.busy = True
        if self.busy or self.tick % 4 == 0:
            self.read_events()
            self.reload_pet()
        if self.tick % 120 == 60:
            self.check_threat()
            self.see_update()
        if self.tick == 80:              # 20 s after the start, not to slow down the first prompt
            threading.Thread(target=self.check_update, daemon=True).start()
        if self.busy:
            self.busy, self.last_key, self.drawn = False, None, None
            self.last_command = now_ms()
        if self.tick % 20 == 10 and self.code_changed():
            self.read_events()
            self.restart()
        self.remind_threat(now_ms())
        self.remind_update(now_ms())
        self.maybe_talk(now_ms())
        self.draw(now_ms())

    def code_changed(self):
        """True once the source changed and has been quiet for 2 s (not in the middle of a save)."""
        try:
            newest = code_version()
        except (OSError, ValueError):
            return False
        return newest != self.code and time.time() - newest > 2

    HANDOVER = ("offset", "guests", "bubble", "bubble_at", "notes", "talk_at", "warn_at", "threat", "threat_text", "threat_id",
                "threat_until", "threat_said", "update_tag", "update_said", "fights_won", "fights_lost", "old_loader_told")

    def restart(self):
        """Run the new code in this same process (same PID, so the shell still knows us).

        What must survive (events already counted, the bubble on screen, waiting notes) goes
        through the resume file.
        """
        if self.drawn:
            os.write(1, (ESC + "7" + self.drawn + ESC + "8").encode())
        self.save_resume()
        # A handler doesn't survive exec, an ignored signal does: no SIGUSR1 death in between.
        signal.signal(signal.SIGUSR1, signal.SIG_IGN)
        os.execv(sys.executable, [sys.executable, str(SOURCE.parent / "launch.py"), "bashou.companion", str(self.shell)])

    def save_resume(self):
        self.resume_file.write_text(json.dumps({k: getattr(self, k) for k in self.HANDOVER}))

    def resume(self):
        try:
            saved = json.loads(self.resume_file.read_text())
            self.resume_file.unlink()
        except (OSError, ValueError):
            return
        for key in self.HANDOVER:
            if key in saved:
                setattr(self, key, saved[key])
        if self.bubble:
            self.bubble = tuple(self.bubble)

    def run(self):
        state.private(state.CACHE)
        sweep_events()
        errors = 0
        try:
            while self.alive() and not self.left:
                time.sleep(TICK)
                self.tick += 1
                try:
                    self.step()
                    errors = 0
                except Exception:
                    # Never let one bad frame kill the pet: log it and keep going.
                    errors += 1
                    log_error()
                    if errors >= 20:
                        raise
        finally:
            for f in (self.events, self.erase_file, self.room_file, self.height_file, self.fight_file):
                try:
                    f.unlink()
                except FileNotFoundError:
                    pass

def pid_alive(pid):
    try:
        os.kill(int(pid), 0)
    except ValueError:
        return True                                     # not a shell's file: left alone
    except ProcessLookupError:
        return False
    except PermissionError:
        pass
    return True


GUEST_OFFSETS = "guests.json"      # in the cache: what the pet already counted of each guest file


def read_guest_offsets():
    try:
        saved = json.loads((state.CACHE / GUEST_OFFSETS).read_text())
        return {k: v for k, v in saved.items() if isinstance(v, int)}
    except (OSError, ValueError, AttributeError):
        return {}


def write_guest_offsets(offsets):
    path = state.CACHE / GUEST_OFFSETS
    tmp = path.with_suffix(f".{os.getpid()}")
    try:
        tmp.write_text(json.dumps(offsets))
        tmp.replace(path)
    except OSError:
        pass


def sweep_events():
    """Event files of terminals that are gone (a crash, a kill -9) still hold what was typed there:
    remove them. Each pet removes its own when its terminal closes."""
    for f in state.DATA.glob("events.*"):
        try:
            pid = int(f.suffix[1:])
            os.kill(pid, 0)
        except ValueError:
            continue
        except ProcessLookupError:
            f.unlink(missing_ok=True)
        except PermissionError:
            pass                                        # alive, someone else's: not ours to touch


def log_error():
    """Append the traceback to ~/.cache/bashou/errors.log (kept small)."""
    import traceback
    log = state.CACHE / "errors.log"
    try:
        old = log.read_text()[-20000:] if log.exists() else ""
        log.write_text(old + f"--- {datetime.datetime.now():%F %T}\n{traceback.format_exc()}")
    except OSError:
        pass


def main():
    # Started from .bashrc before job control is on, so we'd share the shell's process group
    # and die on every Ctrl+C at the prompt. Leave the group, and ignore SIGINT anyway.
    os.setpgrp()
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    companion = Companion(int(sys.argv[1]))
    # The prompt sends SIGUSR1 after every command: redraw right away.
    signal.signal(signal.SIGUSR1, lambda *_: setattr(companion, "busy", True))
    companion.run()


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, BrokenPipeError, OSError):
        pass
